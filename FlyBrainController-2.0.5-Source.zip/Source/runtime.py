"""Fail-closed Android observation/action loop and manual demonstration recording."""
from dataclasses import asdict
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import time
import cv2
import numpy as np
from android.screenshot import save_image
from game.moves import Move
from game.rules import get_legal_moves
from game.simulator import apply_move
from vision.board_detector import VisionError
from vision.debug_view import annotate
from settings import resolve


def append_jsonl(path: Path, record: dict) -> None:
    path.parent.mkdir(parents=True,exist_ok=True)
    with path.open("a",encoding="utf-8") as stream:
        stream.write(json.dumps(record,ensure_ascii=False,allow_nan=False)+"\n")
        stream.flush()
        os.fsync(stream.fileno())


def utc_stamp() -> str:
    return datetime.now(timezone.utc).isoformat()


def wait_until_board_stable(android, cfg, check_screen=lambda frame:None):
    deadline = time.monotonic()+cfg["animation_timeout"]
    earliest = time.monotonic()+cfg["animation_min_wait"]
    previous, stable = None, 0
    while time.monotonic() < deadline:
        frame = android.screenshot()
        check_screen(frame)
        x1,y1,x2,y2 = cfg["board_roi"]
        if not (0 <= x1 < x2 <= frame.shape[1] and 0 <= y1 < y2 <= frame.shape[0]):
            raise VisionError("Invalid board_roi")
        patch = frame[y1:y2,x1:x2]
        if previous is not None and patch.shape != previous.shape:
            raise VisionError("Resolution changed while waiting")
        difference = float(np.mean(cv2.absdiff(patch,previous))) if previous is not None else float("inf")
        stable = stable+1 if difference < cfg["animation_threshold"] else 0
        if stable >= cfg["animation_stable_frames"] and time.monotonic() >= earliest:
            return frame
        previous = patch.copy()
        time.sleep(cfg["animation_interval"])
    raise TimeoutError("Board animation did not settle before timeout")


def observed_equal(a,b) -> bool:
    """Compare observable colors only; screenshot reader does not infer reward/score."""
    return a.board == b.board and a.slots == b.slots


class GameLoop:
    def __init__(self, android, vision, agent, rules, cfg):
        self.android,self.vision,self.agent,self.rules,self.cfg = android,vision,agent,rules,cfg

    def _read(self, frame):
        state = self.vision.read_state(frame)
        if not state.confident: raise VisionError(f"Uncertain observation: {state.confidence:.3f}")
        if not any(state.slots.values()): raise VisionError("No recognized occupied slot; stop for review")
        return state

    def run(self, execute: bool = False, max_moves: int = 20, debug: bool = False) -> int:
        frame, state = None, None
        try:
            if execute and not self.cfg.get("rules_verified"):
                raise ValueError("Validate actual game rules before setting rules_verified: true")
            self.android.check_connection()
            for _ in range(max_moves):
                frame = wait_until_board_stable(self.android,self.cfg,self.vision.check_screen)
                state = self._read(frame)
                moves = get_legal_moves(state,self.rules)
                if not moves: return 0
                selected = self.agent.select_move(state,moves)
                if selected not in moves: raise ValueError("Agent returned an illegal action")
                save_image(resolve(self.cfg,"logs/latest_debug.png"),annotate(frame,state,self.cfg,moves,selected))
                if debug:
                    cv2.imshow("Decision (Esc stops)",cv2.resize(annotate(frame,state,self.cfg,moves,selected),None,
                               fx=self.cfg["preview_scale"],fy=self.cfg["preview_scale"]))
                    if cv2.waitKey(30) & 255 == 27: return 0
                record = dict(timestamp=utc_stamp(),state=state.to_dict(),legal_moves=[asdict(m) for m in moves],
                    selected_move=asdict(selected),agent=type(self.agent).__name__,reward=None,dry_run=not execute)
                print(json.dumps(record,ensure_ascii=False))
                if not execute:
                    append_jsonl(resolve(self.cfg,"logs/moves.jsonl"),record)
                    return 0
                # Reobserve after expensive decision; abort if state changed.
                fresh = self.android.screenshot()
                current = self._read(fresh)
                if not observed_equal(state,current): raise VisionError("Board changed during decision")
                self.android.check_connection()
                append_jsonl(resolve(self.cfg,"logs/moves.jsonl"),record | {"status":"planned"})
                self.android.execute(selected,self.cfg)
                frame = wait_until_board_stable(self.android,self.cfg,self.vision.check_screen)
                following = self.vision.read_state(frame)
                if not following.confident: raise VisionError("Uncertain post-action state")
                expected = apply_move(state,selected,self.rules)
                if not observed_equal(expected,following):
                    raise VisionError("Actual transition differs from simulator; correct rules/vision before continuing")
                append_jsonl(resolve(self.cfg,"logs/moves.jsonl"),record | {"status":"verified", "next_state":following.to_dict()})
                if not any(following.slots.values()): return 0
            return 0
        except (Exception, KeyboardInterrupt) as exc:
            folder = resolve(self.cfg,"logs") / ("stop_"+datetime.now().strftime("%Y%m%d_%H%M%S_%f"))
            folder.mkdir(parents=True,exist_ok=True)
            try:
                frame = self.android.screenshot()
            except Exception:
                pass  # Keep last available image if the device disconnected.
            if frame is not None: save_image(folder/"screen.png",frame)
            (folder/"diagnostic.json").write_text(json.dumps(dict(timestamp=utc_stamp(),error=str(exc),
                state=state.to_dict() if state else None),ensure_ascii=False,indent=2),encoding="utf-8")
            raise
        finally:
            if debug: cv2.destroyAllWindows()

    def record(self, count: int = 1):
        """User annotates the move and performs it physically; no automatic touch events."""
        for _ in range(count):
            before = wait_until_board_stable(self.android,self.cfg,self.vision.check_screen)
            state = self._read(before)
            text = input("Enter slot_id target_cell_id for your next MANUAL move (q ends): ").strip()
            if text.lower() == "q": return
            move = Move(*map(int,text.split()))
            if move not in get_legal_moves(state,self.rules): raise ValueError("Annotation is illegal under configured rules")
            input("Perform that move on the phone, then press Enter here: ")
            after = wait_until_board_stable(self.android,self.cfg,self.vision.check_screen)
            following = self.vision.read_state(after)
            if not following.confident: raise VisionError("Uncertain post-demonstration observation")
            key = str(time.time_ns())
            folder = resolve(self.cfg,"data/recordings")
            save_image(folder/f"{key}_before.png",before)
            save_image(folder/f"{key}_after.png",after)
            append_jsonl(folder/"demonstrations.jsonl",dict(timestamp=utc_stamp(),state=state.to_dict(),
                move=asdict(move),next_state=following.to_dict(),reward=None,
                before=f"{key}_before.png",after=f"{key}_after.png",annotation="manual"))
