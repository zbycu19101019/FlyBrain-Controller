from agents import RandomAgent, GreedyAgent, SearchAgent
from agents.flybrain_agent import FlyBrainAgent
from flybrain.connectome import synthetic, import_csv
from flybrain.neurons import LIFParameters
from flybrain.simulator import LIFBackend
from flybrain.encoder import PopulationEncoder
from flybrain.activity import FeatureService
from flybrain.readout import LinearReadout
from game.rules import Rules
from settings import resolve


def make_features(cfg):
    kind=cfg["brain_backend"]
    if kind == "synthetic": network=synthetic(cfg["brain_neurons"],cfg["brain_seed"])
    elif kind == "connectome": network=import_csv(resolve(cfg,cfg["connectome_csv"]),cfg["unknown_sign_policy"])
    else: raise ValueError(f"Unknown brain_backend: {kind}")
    backend=LIFBackend(network,cfg["brain_dt"],LIFParameters(**cfg["brain"]),cfg["brain_groups"],cfg["brain_bins"])
    encoder=PopulationEncoder(backend.n,cfg["encoder_colors"],cfg["brain_seed"])
    return FeatureService(backend,encoder,cfg["brain_duration_ms"],resolve(cfg,"data/cache"))


def make_agent(name,cfg,seed=0):
    kwargs=dict(rules=Rules(**cfg["rules"]),weights=cfg["heuristic_weights"])
    if name == "random": return RandomAgent(seed)
    if name == "greedy": return GreedyAgent(**kwargs)
    if name == "search": return SearchAgent(depth=2,**kwargs)
    if name == "flybrain":
        features=make_features(cfg)
        readout,metadata=LinearReadout.load(resolve(cfg,cfg["readout_model"]),features.fingerprint)
        if metadata["rules"] != cfg["rules"] or metadata["heuristic_weights"] != cfg["heuristic_weights"]:
            raise ValueError("Teacher rules/heuristics changed; retrain")
        return FlyBrainAgent(features,readout)
    if name == "selfplay":
        features=make_features(cfg)
        path=resolve(cfg,cfg.get("self_play_model","data/models/self_play.npz"))
        if not path.exists(): raise ValueError("No self-play model yet; train it in Laboratory first")
        readout,metadata=LinearReadout.load(path,features.fingerprint)
        if metadata.get("rules") != cfg["rules"]:
            raise ValueError("Self-play model uses different game rules; train it again")
        return FlyBrainAgent(features,readout)
    raise ValueError(f"Unknown agent: {name}")
