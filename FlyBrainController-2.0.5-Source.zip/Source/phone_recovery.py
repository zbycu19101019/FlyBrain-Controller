"""Bounded recovery: reobserve, recalibrate, optionally close an identified control."""
import copy
from enum import Enum
import re
import time
import xml.etree.ElementTree as ET
import numpy as np


class LayoutChanged(ValueError): pass
class RecoveryFailed(ValueError): pass


class RecoveryState(str,Enum):
    WAIT="recovery_wait"
    CALIBRATE="recovery_calibrate"
    CONTROL="recovery_control"
    READY="recovered"


def find_known_control(xml,allowed_packages,screen_size,labels=None):
    """Use Android accessibility bounds. A generic unlabeled X is not proof of an ad."""
    allowed=set(allowed_packages)
    if not allowed: return None
    labels=set(labels or ["continue","kontynuuj","close ad","zamknij reklamę","skip ad","pomiń reklamę"])
    labels={s.strip().casefold() for s in labels}
    root=ET.fromstring(xml)
    width,height=screen_size
    found=set()
    for node in root.iter("node"):
        if node.get("package") not in allowed or node.get("enabled")!="true" or node.get("clickable")!="true": continue
        names={node.get("text","").strip().casefold(),node.get("content-desc","").strip().casefold()}
        if not names&labels: continue
        bounds=re.fullmatch(r"\[(\d+),(\d+)\]\[(\d+),(\d+)\]",node.get("bounds",""))
        if not bounds: continue
        x1,y1,x2,y2=map(int,bounds.groups())
        if 0<=x1<x2<=width and 0<=y1<y2<=height and (x2-x1)*(y2-y1)<width*height*.2:
            found.add((x1,y1,x2,y2))
    return next(iter(found)) if len(found)==1 else None


def close_known_control(android,options,emit):
    allowed=options.get("allowed_packages",[])
    if not options.get("enabled",True) or not allowed: return False
    before=android.screenshot()
    android._run(["shell","uiautomator","dump","/sdcard/flybrain_recovery.xml"])
    xml=android._run(["exec-out","cat","/sdcard/flybrain_recovery.xml"]).decode("utf-8")
    bounds=find_known_control(xml,allowed,list(before.shape[1::-1]),options.get("labels"))
    if bounds is None: return False
    after=android.screenshot()
    if after.shape!=before.shape: return False
    x1,y1,x2,y2=bounds
    if float(np.mean(np.abs(before[y1:y2,x1:x2].astype(float)-after[y1:y2,x1:x2])))>3: return False
    emit(RecoveryState.CONTROL.value,"Rozpoznano dozwolony przycisk zamknięcia/kontynuacji. Klikam raz.")
    android.tap((x1+x2)//2,(y1+y2)//2)
    return True


def recover(policy,android,options,emit,allow_controls=True):
    attempts=max(1,min(3,int(options.get("attempts",2))))
    delay=max(0,min(5,float(options.get("wait_seconds",3))))
    last="Nie rozpoznano planszy."
    clicked=False
    for attempt in range(attempts):
        emit(RecoveryState.WAIT.value,f"Anulowano stary plan. Oczekiwanie {delay:g} s; próba {attempt+1}/{attempts}.")
        time.sleep(delay)
        android.check_connection()
        frame=android.screenshot()
        try:
            candidate=copy.deepcopy(policy)
            emit(RecoveryState.CALIBRATE.value,"Rozpoznaję ponownie planszę. Nie wysyłam ruchów gry.")
            candidate.check_screen(frame)  # Never learn a new screen guard from an unknown overlay.
            if not candidate._adopt_dynamic_layout(frame):
                # Small calibrated boards may legitimately have fewer than 8 cells.
                candidate.read(frame)
            signature=candidate.layout_signature()[0]
            stable,obs,_=candidate.stable(android)
            if candidate.layout_signature()[0]!=signature or len(obs.board)<1 or not any(obs.slots.values()):
                raise LayoutChanged("Ponowna kalibracja nie jest jeszcze stabilna.")
            if sum(c in {"blocked","unknown"} for c in obs.board.values())>len(obs.board)*.4:
                raise LayoutChanged("Zbyt wiele nieczytelnych pól po ponownej kalibracji.")
            # Old geometry-keyed outcome memory must not be reused at new IDs.
            if candidate.layout_signature()[0]!=policy.layout_signature()[0]:
                candidate.memory={}; candidate.outcome_weights=None
                candidate.outcome_samples=0; candidate.outcome_training.clear()
                candidate.intelligence.lif=None
            emit(RecoveryState.READY.value,"Odzyskano stabilną planszę. Wybiorę nowy ruch z nowego stanu.")
            return candidate,stable,obs,clicked
        except ValueError as exc:
            last=str(exc)
        if allow_controls and not clicked and attempt+1<attempts:
            clicked=close_known_control(android,options.get("controls",{}),emit)
    raise RecoveryFailed(f"Nie odzyskano planszy po {attempts} próbach. {last}")
