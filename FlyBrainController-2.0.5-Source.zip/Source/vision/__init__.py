"""Calibrated, conservative image observation."""
