import numpy as np
from game.state import GameState, BoardCell
from .color_classifier import ColorClassifier, ColorPrototype
from .stack_reader import StackReader
from android.screenshot import load_image
from settings import resolve


class VisionError(RuntimeError): pass


class BoardDetector:
    def __init__(self, cfg: dict):
        self.cfg = cfg
        if not cfg["board_cells"] or not cfg["slots"] or not cfg["screen_size"]:
            raise VisionError("Run calibration first")
        self.reader = StackReader(ColorClassifier([ColorPrototype(**p) for p in cfg["color_prototypes"]],
            cfg["vision_thresholds"]["ambiguity_margin"]),cfg["sample_offsets"],cfg["patch_radius"])
        if "empty" not in {p["name"] for p in cfg["color_prototypes"]}:
            raise VisionError("Calibrate an explicit empty/background prototype")
        self.guards = [(g, load_image(resolve(cfg,g["image"]))) for g in cfg.get("screen_guards",[])]

    def check_screen(self, image: np.ndarray, require_guard: bool = True) -> None:
        if list(image.shape[1::-1]) != self.cfg["screen_size"]:
            raise VisionError("Screen size/orientation changed; recalibrate")
        if require_guard and not self.guards:
            raise VisionError("Add static screen guards before device automation")
        for guard, reference in self.guards:
            x1,y1,x2,y2 = guard["roi"]
            patch = image[y1:y2,x1:x2]
            if patch.shape != reference.shape or float(np.mean(np.abs(patch.astype(float)-reference))) > guard["max_mae"]:
                raise VisionError("Unknown screen or overlay: screen guard mismatch")

    def read_state(self, image: np.ndarray, require_guard: bool = True) -> GameState:
        self.check_screen(image,require_guard)
        blocked_ids=set(map(int,self.cfg.get("blocked_cells",[])))
        board = {i:self.reader.read_stack(image,*p) for i,p in self.cfg["board_cells"].items()}
        slots = {i:self.reader.read_stack(image,*p) for i,p in self.cfg["slots"].items()}
        observations = list(board.values())+list(slots.values())
        confidence = min(o.confidence for o in observations)
        valid = (all(o.valid for o in observations) and not any(o.blocked for o in slots.values())
                 and confidence >= self.cfg["vision_thresholds"]["confidence"])
        return GameState({i:BoardCell(i,None if o.blocked or i in blocked_ids else o.stack,
                                      o.blocked or i in blocked_ids) for i,o in board.items()},
                         {i:o.stack for i,o in slots.items()},confident=valid,
                         confidence=confidence,neighbors=self.cfg["neighbors"])
