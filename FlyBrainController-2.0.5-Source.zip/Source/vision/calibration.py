"""Interactive centers, color prototypes and static screen guard calibration."""
import argparse
from pathlib import Path
import cv2
import numpy as np
from android.adb import AndroidController
from android.screenshot import load_image, save_image
from settings import ROOT, load_config, save_config, resolve


def display_to_real(x: int, y: int, original: tuple, displayed: tuple) -> tuple[int, int]:
    return (min(original[0]-1, max(0, round(x * original[0] / displayed[0]))),
            min(original[1]-1, max(0, round(y * original[1] / displayed[1]))))


def infer_neighbors(points: dict, max_distance: float) -> dict:
    if max_distance <= 0:
        raise ValueError("max_distance must be positive")
    return {i: sorted(j for j in points if j != i and
            np.linalg.norm(np.array(points[i])-points[j]) <= max_distance) for i in points}


def run(path: Path, image_path: str | None = None, color: str | None = None,
        guard: bool = False, neighbor_distance: float | None = None) -> None:
    cfg = load_config(path)
    image = load_image(image_path) if image_path else AndroidController(
        cfg["adb_path"], cfg.get("device_serial"), cfg.get("adb_timeout", 10)).screenshot()
    h, w = image.shape[:2]
    scale = float(cfg["preview_scale"])
    if not 0 < scale <= 1:
        raise ValueError("preview_scale must be in (0,1]")
    size = (max(1, round(w*scale)), max(1, round(h*scale)))
    if guard:
        preview = cv2.resize(image, size)
        x, y, rw, rh = cv2.selectROI("Select static game UI region; Enter confirms", preview)
        cv2.destroyAllWindows()
        if not rw or not rh:
            return
        x1, y1 = display_to_real(x, y, (w, h), size)
        x2, y2 = display_to_real(x+rw, y+rh, (w, h), size)
        name = f"data/calibration/guard_{len(cfg['screen_guards'])}.png"
        save_image(resolve(cfg, name), image[y1:y2, x1:x2])
        cfg["screen_guards"].append({"roi": [x1, y1, x2, y2], "image": name, "max_mae": 8})
        save_config(path, cfg)
        return
    mode = ["board_cells"]
    points = {"board_cells": [], "slots": []}
    selected = []
    title = "Calibration: c=cell s=slot u=undo q=SAVE Esc=cancel"

    def click(event, x, y, flags, param):
        if event != cv2.EVENT_LBUTTONDOWN:
            return
        px, py = display_to_real(x, y, (w, h), size)
        if color:
            patch = image[max(0,py-3):min(h,py+4), max(0,px-3):min(w,px+4)]
            bgr = np.median(patch, axis=(0, 1)).astype(np.uint8)
            hsv = cv2.cvtColor(bgr.reshape(1,1,3), cv2.COLOR_BGR2HSV)[0,0]
            selected[:] = [dict(name=color, h=int(hsv[0]), s=int(hsv[1]), v=int(hsv[2]),
                               tolerance={"h": 12, "s": 50, "v": 50})]
            print(selected[0])
        else:
            points[mode[0]].append([px, py])

    cv2.namedWindow(title, cv2.WINDOW_AUTOSIZE)
    cv2.setMouseCallback(title, click)
    try:
        while True:
            display = cv2.resize(image, size)
            for key, pts in points.items():
                for idx, (x,y) in enumerate(pts):
                    p = (round(x*size[0]/w), round(y*size[1]/h))
                    cv2.circle(display, p, 5, (0,255,0) if key == "board_cells" else (255,0,0), 2)
                    cv2.putText(display, f"{key[0]}{idx}", p, 0, .4, (255,255,255), 1)
            cv2.imshow(title, display)
            key = cv2.waitKey(30) & 255
            if key == 27 or cv2.getWindowProperty(title, cv2.WND_PROP_VISIBLE) < 1:
                return
            if key == ord("c"): mode[0] = "board_cells"
            if key == ord("s"): mode[0] = "slots"
            if key == ord("u") and points[mode[0]]: points[mode[0]].pop()
            if key == ord("q"):
                if color:
                    if not selected: raise ValueError("Select a color sample first")
                    cfg["color_prototypes"] = [p for p in cfg["color_prototypes"] if p["name"] != color] + selected
                else:
                    if not all(points.values()): raise ValueError("Mark at least one cell AND slot")
                    for name, pts in points.items(): cfg[name] = dict(enumerate(pts))
                    cfg["screen_size"] = [w, h]
                    cfg["board_roi"] = [0, 0, w, h]
                    cfg["screen_guards"] = []
                    cfg["rules_verified"] = False
                    cfg["neighbors"] = infer_neighbors(cfg["board_cells"], neighbor_distance) if neighbor_distance else {i: [] for i in cfg["board_cells"]}
                save_config(path, cfg)
                return
    finally:
        cv2.destroyAllWindows()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", type=Path, default=ROOT / "config.yaml")
    parser.add_argument("--image")
    parser.add_argument("--color", help="Sample named color; use empty for background")
    parser.add_argument("--guard", action="store_true")
    parser.add_argument("--neighbor-distance", type=float)
    args = parser.parse_args()
    run(args.config, args.image, args.color, args.guard, args.neighbor_distance)


if __name__ == "__main__": main()
