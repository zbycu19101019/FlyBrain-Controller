import cv2


def annotate(image, state, cfg, moves=(), selected=None):
    output = image.copy()
    for kind, points in (("C",cfg["board_cells"]),("S",cfg["slots"])):
        for i,(x,y) in points.items():
            stack = state.board[i].stack if kind == "C" else state.slots[i]
            label = f"{kind}{i}: {','.join(stack.colors) if stack else 'empty'}"
            cv2.circle(output,(x,y),10,(0,255,0),2)
            cv2.putText(output,label,(x+12,y),0,.5,(255,255,255),2)
    if selected:
        cv2.arrowedLine(output,tuple(cfg["slots"][selected.slot_id]),tuple(cfg["board_cells"][selected.target_cell_id]),(0,0,255),4)
    cv2.putText(output,f"confidence={state.confidence:.2f} legal={len(moves)}",(15,30),0,.7,(0,255,255),2)
    return output
