"""Small local digit OCR with explicit rejection. No network or external executable."""
from dataclasses import dataclass
from pathlib import Path
import cv2
import numpy as np


@dataclass(frozen=True)
class NumberReading:
    value: int|None
    confidence: float
    reason: str = ""


def normalize(mask):
    y,x=np.nonzero(mask)
    if not len(x): return np.zeros((40,28),np.float32)
    glyph=mask[y.min():y.max()+1,x.min():x.max()+1].astype(np.float32)
    return cv2.resize(glyph,(28,40),interpolation=cv2.INTER_AREA)/255.


class DigitReader:
    def __init__(self,model=None,threshold=.76,margin=.035):
        model=Path(model) if model else Path(__file__).resolve().parent.parent/'data/models/digits.npz'
        self.threshold,self.margin=threshold,margin
        with np.load(model,allow_pickle=False) as data:
            self.templates=data['templates'].astype(np.float32); self.labels=data['labels'].astype(int)
        if self.templates.ndim!=3 or self.templates.shape[1:]!=(40,28) or len(self.labels)!=len(self.templates):
            raise ValueError('Invalid digit template model')

    @staticmethod
    def components(frame,point,kind='board',scale=1.,roi=None):
        bounds=roi or ((-43,-105,43,18) if kind=='board' else (-38,-55,38,32))
        x,y=point; h,w=frame.shape[:2]
        x1,y1,x2,y2=(round(x+bounds[0]*scale),round(y+bounds[1]*scale),
                     round(x+bounds[2]*scale),round(y+bounds[3]*scale))
        if x1<0 or y1<0 or x2>w or y2>h or x1>=x2 or y1>=y2: return []
        patch=frame[y1:y2,x1:x2]
        # Printed numerals are darker than their tile. Otsu also creates border
        # components, which are excluded by geometry and central alignment.
        gray=patch.max(axis=2).astype(np.uint8)  # HSV value avoids luminance shifts across tile hues.
        if float(gray.std())<8: return []
        _,mask=cv2.threshold(gray,0,255,cv2.THRESH_BINARY_INV+cv2.THRESH_OTSU)
        count,labels,stats,_=cv2.connectedComponentsWithStats(mask,8)
        components=[]
        for ident in range(1,count):
            cx,cy,cw,ch,area=stats[ident]
            if not (7*scale<=cw<=52*scale and 20*scale<=ch<=64*scale): continue
            if not .12<=area/(cw*ch)<=.9: continue
            if cx<=0 or cy<=0 or cx+cw>=mask.shape[1] or cy+ch>=mask.shape[0]: continue
            glyph=(labels[cy:cy+ch,cx:cx+cw]==ident).astype(np.uint8)*255
            components.append((x1+cx,y1+cy,cw,ch,glyph))
        return sorted(components,key=lambda item:item[0])

    def classify(self,glyph):
        sample=normalize(glyph)
        intersection=np.minimum(self.templates,sample).sum(axis=(1,2))
        union=np.maximum(self.templates,sample).sum(axis=(1,2))
        iou=intersection/np.maximum(1.,union)
        scores=sorted([(float(iou[self.labels==digit].max()),digit) for digit in set(self.labels)],reverse=True)
        best,digit=scores[0]; gap=best-scores[1][0]
        return (digit if best>=self.threshold and gap>=self.margin else None),best

    def read(self,frame,point,kind='board',scale=1.,roi=None):
        parts=self.components(frame,point,kind,scale,roi)
        if not parts: return NumberReading(None,0.,'no numeral')
        # Reject ambiguous lines or labels instead of silently choosing a digit.
        if len(parts)>2: return NumberReading(None,0.,'ambiguous components')
        if len(parts)==2 and abs((parts[0][1]+parts[0][3]/2)-(parts[1][1]+parts[1][3]/2))>10*scale:
            return NumberReading(None,0.,'multiple text rows')
        center=(parts[0][0]+parts[-1][0]+parts[-1][2])/2
        if abs(center-point[0])>18*scale: return NumberReading(None,0.,'off-center text')
        digits=[]; confidence=1.
        for *_,glyph in parts:
            value,score=self.classify(glyph); confidence=min(confidence,score)
            if value is None: return NumberReading(None,confidence,'uncertain digit')
            digits.append(str(value))
        if len(digits)>1 and digits[0]=='0': return NumberReading(None,confidence,'leading zero')
        number=int(''.join(digits))
        if not 1<=number<=99: return NumberReading(None,confidence,'out of range')
        return NumberReading(number,confidence)
