from dataclasses import dataclass
import numpy as np
from game.state import Stack
from .color_classifier import ColorClassifier


@dataclass
class StackObservation:
    stack: Stack | None
    confidence: float
    valid: bool
    samples: list[str]
    blocked: bool = False


class StackReader:
    """Each offset must correspond to one visible layer; never infer hidden layers."""
    def __init__(self, classifier: ColorClassifier, offsets: list, radius: int = 3):
        if not offsets or radius < 1: raise ValueError("Provide offsets and positive patch radius")
        self.classifier, self.offsets, self.radius = classifier, offsets, radius

    def read_stack(self, image: np.ndarray, x: int, y: int) -> StackObservation:
        colors, confidences = [], []
        h,w = image.shape[:2]
        for dx,dy in self.offsets:
            px,py,r = x+dx,y+dy,self.radius
            if not (r <= px < w-r and r <= py < h-r):
                return StackObservation(None,0.,False,["out_of_bounds"])
            patch = image[py-r:py+r+1,px-r:px+r+1]
            name, conf = self.classifier.classify(np.median(patch,axis=(0,1)))
            colors.append(name)
            confidences.append(conf)
        if colors and all(name == "obstacle" for name in colors):
            return StackObservation(None, min(confidences), True, colors, blocked=True)
        # Empty is explicit background, unknown is never silently deleted.
        layers = list(colors)
        while layers and layers[-1] == "empty": layers.pop()
        valid = "unknown" not in colors and "empty" not in layers
        return StackObservation(Stack(layers) if layers else None, min(confidences),valid,colors)
