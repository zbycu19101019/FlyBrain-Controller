from dataclasses import dataclass
import cv2
import numpy as np


@dataclass(frozen=True)
class ColorPrototype:
    name: str
    h: float
    s: float
    v: float
    tolerance: dict[str, float]

    def __post_init__(self):
        if not (0 <= self.h < 180 and 0 <= self.s <= 255 and 0 <= self.v <= 255):
            raise ValueError("HSV prototype out of range")
        if any(not np.isfinite(self.tolerance.get(k,0)) or self.tolerance.get(k,0) <= 0 for k in ("h","s","v")):
            raise ValueError("All HSV tolerances must be positive and finite")

    def distance(self, hsv) -> float:
        h,s,v = map(float, hsv)  # avoid uint8 subtraction overflow
        dh = min(abs(h-self.h), 180-abs(h-self.h))
        # Hue is undefined for desaturated backgrounds.
        if self.s < 30 and s < 30: dh = 0.
        return max(dh/self.tolerance["h"], abs(s-self.s)/self.tolerance["s"], abs(v-self.v)/self.tolerance["v"])


class ColorClassifier:
    def __init__(self, prototypes: list[ColorPrototype], ambiguity_margin: float = .12):
        if not prototypes or len({p.name for p in prototypes}) != len(prototypes):
            raise ValueError("Provide a nonempty, uniquely named color palette")
        self.prototypes, self.margin = prototypes, ambiguity_margin

    def classify_hsv(self, hsv) -> tuple[str,float]:
        distances = sorted((p.distance(hsv),p.name) for p in self.prototypes)
        distance, name = distances[0]
        confidence = max(0.,1-distance)
        if distance >= 1 or (len(distances)>1 and distances[1][0]-distance < self.margin):
            return "unknown", 0.
        return name, confidence

    def classify(self, bgr: np.ndarray) -> tuple[str,float]:
        pixel = np.clip(bgr,0,255).astype(np.uint8).reshape(1,1,3)
        return self.classify_hsv(cv2.cvtColor(pixel,cv2.COLOR_BGR2HSV)[0,0])
