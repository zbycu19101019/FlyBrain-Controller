"""Validated empty-cell gestures with OCR and optional configured Hexa/MCTS advice.

The offline toy readout is not used for phone decisions. Hidden layers remain
uncertain and the separate Hexa rule hypothesis needs explicit confirmation.
"""
from dataclasses import dataclass, field
from collections import deque
from pathlib import Path
import json
import random
import time
import numpy as np
import cv2
from android.adb import AndroidController
from android.screenshot import load_image, save_image
from vision.color_classifier import ColorClassifier, ColorPrototype
from runtime import append_jsonl, utc_stamp
from settings import load_config
from phone_recovery import LayoutChanged, RecoveryFailed, recover
from transition_check import predict_visible, verify_transition
from utils.notifier import send_windows_push, flush_notifications


@dataclass(frozen=True)
class Observation:
    board: dict[int, str]
    slots: dict[int, str | None]
    board_counts: dict[int, int] = field(default_factory=dict)
    slot_counts: dict[int, int] = field(default_factory=dict)
    ocr_confidence: dict = field(default_factory=dict,compare=False)


def event(kind: str, message: str, **values):
    print(json.dumps(dict(event=kind,message=message,**values),ensure_ascii=True),flush=True)


class PhonePolicy:
    def __init__(self, folder: Path, speed_percent=75, accuracy_percent=50,
                 animation_timeout=10, stability_threshold=1.5):
        self.folder=Path(folder)
        speed_percent=max(0,min(100,int(speed_percent)))
        accuracy_percent=max(0,min(100,int(accuracy_percent)))
        self.swipe_duration_ms=round(400-2.4*speed_percent)
        self.poll_interval=.03-.00027*speed_percent
        self.stable_frames=3+round(accuracy_percent*4/100)
        self.animation_timeout=max(2.,float(animation_timeout))
        self.stability_threshold=max(.1,float(stability_threshold))
        self.confidence_threshold=.45+.004*max(0,accuracy_percent-50)
        path=self.folder/"phone_profile.json"
        if not path.exists(): raise ValueError("Brak profilu prawdziwej gry. Potrzebna kalibracja ekranu telefonu.")
        self.profile=json.loads(path.read_text(encoding="utf-8"))
        self.sample_offset=tuple(self.profile.get("sample_offset",(25,-35)))
        self.cells={int(k):v for k,v in self.profile["cells"].items()}
        self.slots={int(k):v for k,v in self.profile["slots"].items()}
        self.neighbors={int(k):v for k,v in self.profile["neighbors"].items()}
        self.blocked_cells=set(map(int,self.profile.get("blocked_cells",[])))
        self.dynamic_layout=False
        self.dynamic_slot_points={}
        self.dynamic_active_slots=set()
        self.next_dynamic_slot_id=0
        self.classifier=ColorClassifier([ColorPrototype(**p) for p in self.profile["palette"]])
        self.guards=[(g,load_image(self.folder/g["image"])) for g in self.profile["guards"]]
        if not self.guards: raise ValueError("Brak wzorców identyfikujących ekran gry.")
        self.memory={}
        self.outcome_weights=None
        self.outcome_samples=0
        self.outcome_training=deque(maxlen=5000)
        self.load_memory()
        from phone_intelligence import PhoneIntelligence
        self.intelligence=PhoneIntelligence(self.folder,self.profile)

    def memory_key(self,color,cell,board):
        """Describe a familiar local situation for persistent move memory."""
        nearby=[]
        for neighbor in self.neighbors.get(int(cell),[]):
            nearby.append(board.get(neighbor,board.get(str(neighbor),"unknown")))
        # Tray positions are interchangeable: the player can choose any stack,
        # so remembered outcomes must not depend on a fixed slot/order.
        return (str(color),int(cell),tuple(sorted(map(str,nearby))))

    @staticmethod
    def detect_hex_centers(frame,top_fraction,bottom_fraction):
        """Find visible hex tiles in a screen band, independent of level layout."""
        h,w=frame.shape[:2]; y1=round(h*top_fraction); y2=round(h*bottom_fraction)
        gray=cv2.cvtColor(frame[y1:y2],cv2.COLOR_BGR2GRAY)
        edges=cv2.Canny(gray,40,100)
        edges=cv2.dilate(edges,np.ones((3,3),np.uint8),iterations=1)
        contours,_=cv2.findContours(edges,cv2.RETR_LIST,cv2.CHAIN_APPROX_SIMPLE)
        candidates=[]
        for contour in contours:
            area=cv2.contourArea(contour)
            if not 2800<=area<=16000: continue
            perimeter=cv2.arcLength(contour,True)
            polygon=cv2.approxPolyDP(contour,.05*perimeter,True)
            if not 5<=len(polygon)<=7: continue
            x,y,bw,bh=cv2.boundingRect(contour)
            if not 65<=bw<=160 or not 65<=bh<=160: continue
            if not .68<=bw/bh<=1.5: continue
            candidates.append((area,(round(x+bw/2),round(y1+y+bh/2))))
        # Stacked tiles expose several hexagonal edges whose centers are
        # vertically offset by a layer. Cluster those contours into one cell;
        # the uppermost point is closest to the playable face center. Adjacent
        # cells are over 90 px apart on supported phone layouts.
        groups=[]
        for area,point in sorted(candidates,reverse=True):
            group=next((items for items in groups if any(
                (point[0]-p[0])**2+(point[1]-p[1])**2<48**2 for _,p in items)),None)
            if group is None: groups.append([(area,point)])
            else: group.append((area,point))
        return [min((point for _,point in group),key=lambda p:(p[1],p[0]))
                for group in groups]

    def _assign_dynamic_slots(self,frame):
        found=self.detect_hex_centers(frame,.60,.81)
        active=set()
        for point in found:
            matches=[(((point[0]-old[0])**2+(point[1]-old[1])**2),sid)
                     for sid,old in self.dynamic_slot_points.items()]
            distance,sid=min(matches) if matches else (float("inf"),None)
            if distance>38**2:
                sid=self.next_dynamic_slot_id; self.next_dynamic_slot_id+=1
                self.dynamic_slot_points[sid]=point
            else:
                old=self.dynamic_slot_points[sid]
                self.dynamic_slot_points[sid]=tuple(round(.7*a+.3*b) for a,b in zip(old,point))
            active.add(sid)
        self.dynamic_active_slots=active
        self.slots=dict(self.dynamic_slot_points)

    def _adopt_dynamic_layout(self,frame):
        centers=self.detect_hex_centers(frame,.18,.65)
        if len(centers)<8: return False
        centers.sort(key=lambda p:(p[1],p[0]))
        if self.blocked_cells:
            raise ValueError("Zmienił się układ z ręcznie zablokowanymi polami. Wykonaj ponowną kalibrację.")
        self.cells={i:list(point) for i,point in enumerate(centers)}
        nearest=[]
        for i,(x,y) in self.cells.items():
            distances=[((x-p[0])**2+(y-p[1])**2)**.5
                       for j,p in self.cells.items() if j!=i]
            if distances: nearest.append(min(distances))
        spacing=float(np.median(nearest)) if nearest else 0
        cutoff=spacing*1.25
        self.neighbors={i:sorted(j for j,q in self.cells.items() if j!=i and
            (p[0]-q[0])**2+(p[1]-q[1])**2<=cutoff**2) for i,p in self.cells.items()}
        # Static obstacle IDs belong to the old level; locks and obstacle colors
        # are re-detected from the current screenshot instead.
        if self.blocked_cells:
            raise ValueError("Zmienił się układ z ręcznie zablokowanymi polami. Wykonaj ponowną kalibrację.")
        self.dynamic_layout=True
        self.dynamic_slot_points={}; self.next_dynamic_slot_id=0
        self._assign_dynamic_slots(frame)
        return True

    def remember(self,color,cell,board,status):
        if status not in {"verified","missed_or_unconfirmed"}:
            return
        key=self.memory_key(color,cell,board)
        counts=self.memory.setdefault(key,[0,0])
        counts[0 if status=="verified" else 1]+=1

    def board_metrics(self,board):
        values={int(k):str(v) for k,v in board.items()}
        empty={cell for cell,value in values.items() if value=="empty"}
        unseen=set(empty); components=[]
        while unseen:
            start=unseen.pop(); stack=[start]; component={start}
            while stack:
                current=stack.pop()
                for neighbor in self.neighbors.get(current,[]):
                    if neighbor in unseen:
                        unseen.remove(neighbor); component.add(neighbor); stack.append(neighbor)
            components.append(component)
        isolated=sum(not any(n in empty for n in self.neighbors.get(cell,[])) for cell in empty)
        matched_pairs=0
        for cell,value in values.items():
            if value in {"empty","blocked","locked","unknown"}: continue
            matched_pairs+=sum(cell<n and values.get(n)==value for n in self.neighbors.get(cell,[]))
        return dict(free=len(empty),components=len(components),isolated=isolated,
                    largest=max((len(c) for c in components),default=0),matches=matched_pairs)

    def board_potential(self,board):
        m=self.board_metrics(board); size=max(1,len(self.cells))
        # Reward useful color links and preserve a large connected region of
        # empty cells; penalize stranded cells and fragmented open space.
        return (.25*m["free"] + .8*m["matches"] - .8*m["components"]
                - 1.4*m["isolated"] + .15*m["largest"])

    def action_features(self,board,color,cell):
        values={int(k):str(v) for k,v in board.items()}
        neighbors=self.neighbors.get(int(cell),[])
        matching=sum(values.get(n)==color for n in neighbors)
        free_neighbors=sum(values.get(n)=="empty" for n in neighbors)
        after=dict(values); after[int(cell)]=color
        m=self.board_metrics(after); size=max(1,len(self.cells))
        return np.asarray([1.,matching/6.,free_neighbors/6.,m["free"]/size,
            m["largest"]/size,m["components"]/size,m["isolated"]/size],dtype=float)

    def fit_outcome_model(self,samples):
        if len(samples)<8: return
        x=np.asarray([features for features,_ in samples],dtype=float)
        y=np.asarray([reward for _,reward in samples],dtype=float)
        regularizer=np.eye(x.shape[1])*2.0
        regularizer[0,0]=.2
        try: self.outcome_weights=np.linalg.solve(x.T@x+regularizer,x.T@y)
        except np.linalg.LinAlgError: self.outcome_weights=None
        if self.outcome_weights is not None: self.outcome_samples=len(samples)

    def learn_from_move(self,before,after,color,cell,status):
        self.remember(color,cell,before,status)
        if status!="verified" or not after:
            return
        features=self.action_features(before,color,cell)
        reward=float(np.clip(self.board_potential(after)-self.board_potential(before),-8.,8.))
        self.outcome_training.append((features,reward))
        self.fit_outcome_model(list(self.outcome_training))

    def load_memory(self):
        """Load the latest phone outcomes so new sessions benefit from prior games."""
        path=self.folder/"logs"/"phone_moves.jsonl"
        if not path.exists():
            return
        recent=deque(maxlen=5000)
        try:
            with path.open("rb") as stream:
                size=stream.seek(0,2)
                stream.seek(max(0,size-4*1024*1024))
                if stream.tell(): stream.readline()
                for line in stream:
                    try: row=json.loads(line.decode("utf-8"))
                    except json.JSONDecodeError: continue
                    except UnicodeDecodeError: continue
                    if isinstance(row,dict): recent.append(row)
        except OSError:
            return
        outcome_samples=[]
        for row in recent:
            before=row.get("before") or {}
            board=before.get("board") or {}
            color=row.get("expected_color")
            cell=row.get("cell")
            if color is None or cell is None or not board:
                continue
            self.remember(color,cell,board,row.get("status"))
            after=(row.get("after") or {}).get("board") or {}
            if row.get("status")=="verified" and after:
                features=self.action_features(board,color,cell)
                reward=float(np.clip(self.board_potential(after)-self.board_potential(board),-8.,8.))
                outcome_samples.append((features,reward))
        self.outcome_training=deque(outcome_samples,maxlen=5000)
        self.fit_outcome_model(outcome_samples)

    @staticmethod
    def patch(frame,point,offset=(25,-35),radius=3):
        x,y=point[0]+offset[0],point[1]+offset[1]
        h,w=frame.shape[:2]
        if not radius <= x < w-radius or not radius <= y < h-radius:
            raise ValueError("Punkt kalibracji znajduje się poza ekranem.")
        return frame[y-radius:y+radius+1,x-radius:x+radius+1]

    def locked_cells(self,frame):
        """Find gold lock badges and associate each with its nearest calibrated cell.

        The color sample used for a cell is intentionally offset from the touch
        point. That can sample the gray hex behind a lock while the actual swipe
        lands on the lock badge, so lock detection must inspect the full image.
        """
        hsv=cv2.cvtColor(frame,cv2.COLOR_BGR2HSV)
        mask=cv2.inRange(hsv,np.array([10,100,140],dtype=np.uint8),
                         np.array([40,255,255],dtype=np.uint8))
        h,w=mask.shape
        xs=[p[0] for p in self.cells.values()]; ys=[p[1] for p in self.cells.values()]
        x1=max(0,min(xs)-85); x2=min(w,max(xs)+86)
        y1=max(0,min(ys)-100); y2=min(h,max(ys)+110)
        board_mask=np.zeros_like(mask); board_mask[y1:y2,x1:x2]=mask[y1:y2,x1:x2]
        count,_,stats,_=cv2.connectedComponentsWithStats(board_mask,8)
        found=set()
        for x,y,bw,bh,area in stats[1:count]:
            # Lock body plus its small price label form a compact gold blob.
            # Large gold/orange game pieces fail the size filter.
            if not (18<=bw<=75 and 20<=bh<=75 and 500<=area<=2600):
                continue
            cx,cy=x+bw/2,y+bh/2
            # Associate each compact lock badge with one nearest cell. Marking
            # every nearby center can hide adjacent, genuinely empty cells
            # when a dynamic cell center is slightly displaced by stack layers.
            cell,(px,py)=min(self.cells.items(),key=lambda item:
                (item[1][0]-cx)**2+(item[1][1]-cy)**2)
            if (px-cx)**2+(py-cy)**2 <= 78**2:
                found.add(cell)
        return found

    def read_slot_color(self,frame,point):
        """Vote across numeral-free parts of a slot tile instead of one pixel patch."""
        offsets=((-24,-20),(24,-20),(-30,8),(30,8),(0,32))
        votes={}; empty_votes=0
        for offset in offsets:
            patch=self.patch(frame,point,offset=offset,radius=4)
            bgr=np.median(patch,axis=(0,1))
            color,confidence=self.classifier.classify(bgr)
            if color == "empty" and confidence>=self.confidence_threshold: empty_votes+=1
            if color not in {"unknown","empty","obstacle"} and confidence>=self.confidence_threshold:
                votes.setdefault(color,[]).append(confidence)
        if not votes:
            return ("empty",1.) if empty_votes>=3 else ("unknown",0.)
        ranked=sorted(votes.items(),key=lambda item:(len(item[1]),sum(item[1])),reverse=True)
        color,scores=ranked[0]
        runner_up=len(ranked[1][1]) if len(ranked)>1 else 0
        if len(scores)<2 or len(scores)<=runner_up:
            return "unknown",float(np.mean(scores))
        return color,float(np.mean(scores))

    def layout_signature(self):
        return (tuple(sorted((k,tuple(v)) for k,v in self.cells.items())),
                tuple(sorted((k,tuple(v)) for k,v in self.slots.items())))

    def check_screen(self,frame):
        if list(frame.shape[1::-1]) != self.profile["screen_size"]:
            raise LayoutChanged("Zmieniła się rozdzielczość lub orientacja telefonu. Potrzebna nowa kalibracja.")
        for guard,ref in self.guards:
            x1,y1,x2,y2=guard["roi"]
            patch=frame[y1:y2,x1:x2]
            if patch.shape != ref.shape or np.mean(np.abs(patch.astype(float)-ref)) > guard["max_mae"]:
                raise LayoutChanged("Ekran nie pasuje do planszy: możliwe okno, reklama lub nowy poziom.")

    def read(self,frame) -> Observation:
        self.check_screen(frame)
        if self.dynamic_layout:
            self._assign_dynamic_slots(frame)
        board,slots={},{}
        locked=self.locked_cells(frame)
        for i,point in self.cells.items():
            if i in locked:
                board[i]="locked"
                continue
            if i in self.blocked_cells:
                board[i]="blocked"
                continue
            sample=np.median(self.patch(frame,point,offset=self.sample_offset),axis=(0,1))
            touch=np.median(self.patch(frame,point,offset=(0,0),radius=4),axis=(0,1))
            color,conf=self.classifier.classify(sample)
            touch_color,touch_conf=self.classifier.classify(touch)
            if color == "obstacle":
                board[i]="blocked"
                continue
            # The face sample is offset to avoid tile numerals and can land on
            # a neighboring edge when the camera/layout shifts. A confident
            # explicit empty classification at the actual drop point is a
            # better signal for an empty cell.
            if (touch_color == "empty" and touch_conf >= self.confidence_threshold
                    and (color in {"unknown","empty"} or conf < self.confidence_threshold)):
                board[i]="empty"
                continue
            if color == "unknown" or conf < self.confidence_threshold:
                board[i]="blocked"
                continue
            if color == "empty":
                # A cell is a placement target only when both the clear face
                # sample and the actual drop point show the empty-cell color.
                # If a neighbouring stack overlaps the center, keep it out of
                # the target set even when the offset patch sees gray.
                if touch_color != "empty" or touch_conf < self.confidence_threshold:
                    board[i]="blocked"
                    continue
            elif touch_color not in {"unknown",color} and touch_conf >= self.confidence_threshold:
                # At a stack, the center often lands on its printed numeral
                # or a neighbouring stack edge. Keep the confident face-color
                # read when the center is merely unreadable; a conflicting
                # confident color still means the calibrated cell is unsafe.
                board[i]="blocked"
                continue
            board[i]=color
        uncertain_static_slot=False
        for i,point in self.slots.items():
            if self.dynamic_layout and i not in self.dynamic_active_slots:
                slots[i]=None
                continue
            patch=self.patch(frame,point,offset=(25,-35))
            bgr=np.median(patch,axis=(0,1))
            reference=self.profile.get("slot_empty_bgr",{}).get(str(i))
            # Calibrated layouts compare against their measured empty tray. In
            # dynamic layouts only detected visible stacks are sampled.
            if not self.dynamic_layout and reference is not None and np.max(np.abs(bgr-np.array(reference))) < 30:
                slots[i]=None
                continue
            color,conf=self.read_slot_color(frame,point)
            if color=="unknown" or conf<self.confidence_threshold:
                if not self.dynamic_layout:
                    uncertain_static_slot=True
                    slots[i]=None
                    continue
                raise ValueError(f"Niepewny odczyt dolnego slotu {i}; nie wysyłam ruchu. Sprawdź podgląd i kalibrację dolnego panelu.")
            slots[i]=None if color=="empty" else color
        # Old profiles can point to the tray edges after a resolution/layout
        # shift. Try current-frame hex detection before declaring its palette bad.
        if uncertain_static_slot and self._adopt_dynamic_layout(frame):
            return self.read(frame)
        if not self.dynamic_layout and (not any(v is not None for v in slots.values()) or
                sum(v=="blocked" for v in board.values())/max(1,len(board))>.4):
            if self._adopt_dynamic_layout(frame):
                return self.read(frame)
        observation=Observation(board,slots)
        return self.intelligence.enrich(frame,observation,self.cells,self.slots)

    def select(self,obs: Observation):
        fallback=self._select_colors(obs)
        return self.intelligence.choose(obs,self.neighbors,fallback)

    def _select_colors(self,obs: Observation):
        def rank_move(board,sid,color,cid):
            matching=sum(board.get(n)==color for n in self.neighbors.get(cid,[]))
            free=sum(board.get(n)=="empty" for n in self.neighbors.get(cid,[]))
            wins,misses=self.memory.get(self.memory_key(color,cid,board),(0,0))
            learned_bonus=6.0*(wins-misses)/(wins+misses+2)
            outcome_bonus=0.
            if self.outcome_weights is not None:
                features=self.action_features(board,color,cid)
                confidence=min(1.,self.outcome_samples/30.)
                outcome_bonus=float(np.clip(features@self.outcome_weights,-4.,4.))*confidence
            return matching*10+free+learned_bonus+outcome_bonus,matching

        slots={sid:color for sid,color in obs.slots.items() if color is not None}
        if not slots: return None
        # Beam-search the visible tray as a small set of choices. This plans
        # the order of up to three placements while preserving high-value
        # empty cells for colors that can use them later.
        beam=[(dict(obs.board),slots,0.,None,0)]
        completed=[]
        for depth in range(1,min(3,len(slots))+1):
            expanded=[]
            for board,available,total,first,first_matching in beam:
                found_move=False
                for sid,color in available.items():
                    for cid,top in board.items():
                        if top!="empty": continue
                        found_move=True
                        score,matching=rank_move(board,sid,color,cid)
                        next_board=dict(board); next_board[cid]=color
                        next_slots=dict(available); del next_slots[sid]
                        next_first=first or (sid,cid)
                        next_matching=first_matching if first is not None else matching
                        expanded.append((next_board,next_slots,total+score,next_first,next_matching))
                if not found_move and first is not None:
                    completed.append((total,first,first_matching,depth-1))
            if not expanded: break
            expanded.sort(key=lambda item:item[2],reverse=True)
            beam=expanded[:32]
            completed.extend((score,first,matching,depth) for _,_,score,first,matching in beam)
        if not completed: return None
        best_score=max(item[0] for item in completed)
        best=[item for item in completed if abs(item[0]-best_score)<1e-9]
        score,(sid,cid),matching,depth=random.choice(best)
        self.last_plan_depth=max(1,depth)
        self.last_plan_score=score
        return sid,cid,matching

    def render(self,frame,obs,move):
        result=frame.copy()
        for i,(x,y) in self.cells.items():
            color=(0,50,255) if obs.board.get(i)=="locked" else (0,230,220)
            cv2.circle(result,(x,y),8,color,2)
            cv2.putText(result,f"{i}: {obs.board_counts.get(i,'?')}",(x+9,y+6),0,.5,(255,255,255),1)
        if move:
            sid,cid,_=move
            cv2.arrowedLine(result,tuple(self.slots[sid]),tuple(self.cells[cid]),(0,220,255),5)
        return result

    def publish_preview(self,frame):
        """Atomically share the latest worker screenshot with the live UI."""
        temporary=self.folder/"phone_preview.tmp.png"
        try:
            save_image(temporary,frame)
            temporary.replace(self.folder/"phone_preview.png")
        except OSError:
            try: temporary.unlink(missing_ok=True)
            except OSError: pass

    @staticmethod
    def stability_patch(frame,point,offset=(0,0),radius=14):
        """Fixed-size, expanded ROI around a calibrated board/slot center."""
        x,y=point[0]+offset[0],point[1]+offset[1]
        h,w=frame.shape[:2]
        if not (0 <= x < w and 0 <= y < h):
            raise ValueError("Punkt stabilizacji znajduje się poza ekranem.")
        x1,x2=x-radius,x+radius+1; y1,y2=y-radius,y+radius+1
        crop=frame[max(0,y1):min(h,y2),max(0,x1):min(w,x2)]
        return cv2.copyMakeBorder(crop,max(0,-y1),max(0,y2-h),
            max(0,-x1),max(0,x2-w),cv2.BORDER_REPLICATE)

    def stable(self,android,timeout=None,stable_frames=None,watch_cell=None,watch_color=None,poll_interval=None):
        if timeout is None: timeout=self.animation_timeout
        if stable_frames is None: stable_frames=self.stable_frames
        if poll_interval is None: poll_interval=self.poll_interval
        if stable_frames < 2: raise ValueError("Stabilizacja wymaga co najmniej 2 klatek.")
        timeout=min(30.,float(timeout))
        previous=None; previous_layout=None; previous_observation=None; count=0; best_stable=0; last_delta=float("inf")
        watched_layout=self.layout_signature()
        started=time.monotonic(); deadline=started+timeout; watched_color=False
        slowest_capture=0.
        while time.monotonic() < deadline:
            capture_started=time.monotonic()
            frame=android.screenshot()
            capture_time=time.monotonic()-capture_started
            slowest_capture=max(slowest_capture,capture_time)
            # ADB screenshots can take over a second on some Wi-Fi links.
            # Give enough wall time to collect the requested consecutive
            # frames, with a hard cap so a genuinely moving screen still stops.
            adaptive_budget=min(30.,max(timeout,2.+stable_frames*slowest_capture*1.3))
            deadline=max(deadline,started+adaptive_budget)
            self.publish_preview(frame)
            observation=self.read(frame)  # Validate every frame, including transient overlays.
            layout=self.layout_signature()
            # Consuming/refilling a tray stack may move or add detected slot
            # centers. Wait for that tray to settle below; it is not a board
            # recalibration. Board cell coordinates must still remain exact.
            if watch_cell is not None and layout[0] != watched_layout[0]:
                raise LayoutChanged("Układ zmienił się podczas weryfikacji gestu. Anulowano stary plan.")
            # A valid placement may trigger a merge that removes/recolors the
            # target before the board settles. Remember whether the requested
            # color was actually visible in any frame of that transition.
            if watch_cell is not None and watch_color is not None:
                sample=np.median(self.patch(frame,self.cells[watch_cell],offset=self.sample_offset),axis=(0,1))
                observed,confidence=self.classifier.classify(sample)
                watched_color |= observed == watch_color and confidence >= self.confidence_threshold
            # Include a wider area around each cell and the visible tray face;
            # fixed-size clipped ROIs also work for points near screen edges.
            parts=[self.stability_patch(frame,p).ravel() for p in self.cells.values()]
            parts.extend(self.stability_patch(frame,p,offset=(25,-35)).ravel()
                         for p in self.slots.values())
            parts.extend(self.stability_patch(frame,p,offset=self.sample_offset).ravel()
                         for p in self.cells.values())
            parts.extend(self.stability_patch(frame,p).ravel() for p in self.slots.values())
            vector=np.stack(parts).astype(float)
            delta=(float(np.max(np.mean(np.abs(vector-previous),axis=1)))
                   if previous is not None and layout==previous_layout else float("inf"))
            last_delta=delta
            count=count+1 if delta < self.stability_threshold and observation==previous_observation else 0
            best_stable=max(best_stable,count+1 if previous is not None and delta < self.stability_threshold else 1)
            # Require five consecutive captures with stable enlarged ROIs.
            # The other screen-polling thread is paused during phone tasks.
            if count >= stable_frames-1: return frame,observation,watched_color
            previous=vector; previous_layout=layout; previous_observation=observation
            # ADB screenshot capture already paces this loop; keep only a tiny
            # yield so the stable-frame check does not add 200 ms per move.
            time.sleep(poll_interval)
        raise LayoutChanged(
            f"Plansza nie ustabilizowała się: {best_stable}/{stable_frames} kolejnych klatek "
            f"(różnica {last_delta:.2f}, próg {self.stability_threshold:.2f}). "
            "Sprawdź, czy gra nie animuje planszy; limit uwzględnia teraz czas zrzutów ADB."
        )

    def slot_visual_change(self,before,after,sid,point=None):
        """Detect a consumed/refilled stack even when its color is unchanged."""
        x,y=point if point is not None else self.slots[sid]
        h,w=before.shape[:2]
        # Compare the visible stack, including its numbered face and layers.
        x1,x2=max(0,x-45),min(w,x+46)
        y1,y2=max(0,y-45),min(h,y+46)
        a=before[y1:y2,x1:x2]
        b=after[y1:y2,x1:x2]
        if a.shape != b.shape:
            return True
        return float(np.mean(cv2.absdiff(a,b))) >= 3.0


def analyze_transition(policy,android,before_frame,before,frame,after,sid,cid,source_point,seen,expected,attempts=3):
    """Reobserve delayed effects without sending another gesture or weakening evidence."""
    layout=policy.layout_signature()[0]
    for attempt in range(max(1,min(5,int(attempts)))):
        changed=(after.slots.get(sid)!=before.slots[sid] or
                 policy.slot_visual_change(before_frame,frame,sid,point=source_point))
        verdict=verify_transition(before,after,sid,cid,policy.neighbors,changed,seen,expected)
        if verdict.accepted or attempt+1>=max(1,min(5,int(attempts))):
            return frame,after,seen,changed,verdict
        event('analyzing',f'Analizuję reakcję gry ponownie ({attempt+2}/{attempts}). {verdict.detail}')
        time.sleep(1)
        frame,after,observed=policy.stable(android,watch_cell=cid,watch_color=before.slots[sid])
        if policy.layout_signature()[0]!=layout:
            raise LayoutChanged('Geometria zmieniła się podczas dodatkowej analizy.')
        seen=seen or observed


def _run_phone(config: Path,steps: int = 1,execute: bool = False,speed_percent=75,accuracy_percent=50):
    cfg=load_config(config); folder=Path(config).parent
    policy=PhonePolicy(folder,speed_percent,accuracy_percent,
                       animation_timeout=cfg.get("animation_timeout",10),
                       stability_threshold=cfg.get("animation_threshold",1.5))
    android=AndroidController(cfg["adb_path"],cfg.get("device_serial"),cfg["adb_timeout"])
    android.check_connection()
    run_id=str(time.time_ns())
    frame=None
    pending=None
    pending_record=None
    recovery_count=0
    confirmed=0
    sent=0
    empty_decisions=0
    analysis_attempts=max(1,min(5,int(cfg.get('analysis_attempts',3))))
    try:
        while sent < steps:
            step=sent
            try:
                event("observing","Odczytuję planszę i czekam na koniec animacji.")
                # Reuse the stable post-move capture for the next decision. The
                # pre-gesture freshness check below still guards against drift.
                if pending is None:
                    frame,obs,_=policy.stable(android)
                else:
                    frame,obs=pending
                    pending=None
                decision_layout=policy.layout_signature()
                move=policy.select(obs)
                if move is None:
                    if empty_decisions<analysis_attempts-1:
                        empty_decisions+=1
                        event('analyzing',f'Brak pewnego ruchu. Ponownie odczytuję całą planszę i OCR ({empty_decisions+1}/{analysis_attempts}).')
                        time.sleep(1)
                        continue
                    if cfg.get('recovery',{}).get('enabled',True) and recovery_count<max(0,min(3,int(cfg.get('recovery',{}).get('max_per_run',2)))):
                        empty_decisions=0
                        raise LayoutChanged('Kolejne odczyty nie wskazały ruchu. Próbuję ponownie rozpoznać układ.')
                    visible_stacks=sum(color is not None for color in obs.slots.values())
                    free_cells=sum(color=="empty" for color in obs.board.values())
                    locked_cells=sum(color=="locked" for color in obs.board.values())
                    blocked_cells=sum(color=="blocked" for color in obs.board.values())
                    occupied_cells=len(obs.board)-free_cells-locked_cells-blocked_cells
                    if not visible_stacks:
                        reason="Nie rozpoznano stosu w dolnym panelu. Możliwa zmiana układu poziomu lub pusty zasobnik; sprawdź podgląd i kalibrację."
                    elif not free_cells and locked_cells:
                        reason=(f"Nie rozpoznano pustego celu (klatki: {locked_cells}, zajęte: {occupied_cells}, "
                                f"niepewne: {blocked_cells}). Nie wysyłam ruchu na kłódkę. "
                                "Jeśli widzisz szare puste heksy, odśwież podgląd; sterownik poprawił ich wykrywanie.")
                    elif not free_cells:
                        reason=(f"Nie rozpoznano pustego celu (zajęte: {occupied_cells}, niepewne: {blocked_cells}). "
                                "Nie wysyłam ruchu na pole, którego stanu nie mogę potwierdzić.")
                    else:
                        reason="Nie znaleziono bezpiecznego dopasowania stosu do wolnego pola. Nie wysyłam ruchu."
                    if frame is not None: save_image(folder/"phone_stop.png",frame)
                    event("stopped",reason,free_cells=free_cells,locked_cells=locked_cells,
                          blocked_cells=blocked_cells,occupied_cells=occupied_cells)
                    if execute:
                        send_windows_push("FlyBrain zatrzymany",reason,enabled=cfg.get("notifications_enabled",True))
                    return
                sid,cid,matching=move
                empty_decisions=0
                reason=(f"Plan do {getattr(policy,'last_plan_depth',1)} ruchów: slot {sid} "
                        f"({obs.slots[sid]}) → wolne pole {cid}; zgodni sąsiedzi: {matching}.")
                save_image(folder/"live_decision.png",policy.render(frame,obs,move))
                intelligence=policy.intelligence.summary
                if intelligence.get('used','').startswith('mcts'):
                    reason=f"MCTS: slot {sid} ({obs.slots[sid]}) → wolne pole {cid}."
                reason+=f" OCR slotu: {obs.slot_counts.get(sid,'?')}; plan: {intelligence.get('used','colors')}."
                if intelligence.get('mode')=='shadow' and intelligence.get('search'):
                    search=intelligence['search']
                    reason+=f" Analiza MCTS: {search['iterations']} symulacji; propozycja {search['move']}."
                append_jsonl(folder/"logs/phone_planning.jsonl",dict(timestamp=utc_stamp(),run_id=run_id,
                    before=vars(obs),selected=[sid,cid],analysis=intelligence))
                event("decision",reason,slot=sid,cell=cid,intelligence=intelligence)
                if not execute:
                    event("preview","To tylko propozycja. Do telefonu nie wysłano ruchu."); return
                current_frame=android.screenshot()
                policy.publish_preview(current_frame)
                current=policy.read(current_frame)
                if current != obs or policy.layout_signature()!=decision_layout: raise LayoutChanged("Plansza zmieniła się podczas decyzji. Ruch anulowany.")
                before_frame=current_frame
                source_point=tuple(policy.slots[sid])
                expected=predict_visible(obs,(sid,cid),policy.neighbors,policy.intelligence.rules,
                                         policy.intelligence.options.get("rules_verified",False))
                event("moving",f"Przeciągam stos ze slotu {sid} na pole {cid}.",move_number=step+1)
                # Shorter drag keeps up with the game's immediate response while
                # leaving the settle/verification checks unchanged.
                pending_record=dict(timestamp=utc_stamp(),run_id=run_id,move_number=step+1,
                    policy="visible_top_placement",slot=sid,cell=cid,before=vars(obs),
                    expected_color=obs.slots[sid],reason=reason,intelligence=intelligence,expected_state=expected)
                append_jsonl(folder/"logs/phone_moves.jsonl",pending_record | {"status":"planned"})
                android.swipe(*policy.slots[sid],*policy.cells[cid],duration_ms=policy.swipe_duration_ms)
                sent+=1
                event("waiting","Ruch wysłany. Czekam na reakcję gry.")
                frame,after,target_seen_during_animation=policy.stable(
                    android,watch_cell=cid,watch_color=obs.slots[sid])
                frame,after,target_seen_during_animation,source_changed,verdict=analyze_transition(
                    policy,android,before_frame,obs,frame,after,sid,cid,source_point,
                    target_seen_during_animation,expected,analysis_attempts)
                target_color=after.board[cid]
                target_matches=target_color == obs.slots[sid]
                verified=verdict.accepted
                target_confirmed=verified
                append_jsonl(folder/"logs/phone_moves.jsonl",dict(timestamp=utc_stamp(),run_id=run_id,
                    move_number=step+1,policy="visible_top_placement",
                    slot=sid,cell=cid,before=vars(obs),after=vars(after),reason=reason,
                    expected_color=obs.slots[sid],source_changed=source_changed,intelligence=intelligence,
                    target_observed_color=target_color,target_matches=target_matches,
                    target_seen_expected_during_animation=target_seen_during_animation,
                    verification_kind=verdict.kind,verification_detail=verdict.detail,expected_state=expected,
                    status="verified" if verdict.trainable else "cascade_inferred" if verified else "missed_or_unconfirmed"))
                pending_record=None
                policy.learn_from_move(obs.board,after.board,obs.slots[sid],cid,
                                       "verified" if verdict.trainable else "cascade_inferred" if verified else "missed_or_unconfirmed")
                try:
                    policy.intelligence.learn(obs,after,(sid,cid),policy.neighbors,verdict.trainable)
                except (OSError,ValueError) as learning_error:
                    event("learning_warning",f"Nie zapisano próbki LIF: {learning_error}")
                if not verified:
                    raise ValueError(f"Ruch niepotwierdzony: {verdict.detail}")
                confirmed+=1
                recovery_count=0  # Budget applies to consecutive failures, not the entire session.
                event("cascade" if verdict.kind.startswith("cascade") else "verified",
                      f"Ruch {step+1}: {verdict.detail}",move_number=step+1)
                pending=(frame,after)
            except LayoutChanged as layout_error:
                pending=None
                if pending_record is not None:
                    append_jsonl(folder/"logs/phone_moves.jsonl",pending_record |
                        {"status":"execution_unknown","error":str(layout_error)})
                    pending_record=None
                recovery_options=cfg.get("recovery",{})
                if not recovery_options.get("enabled",True):
                    raise
                if recovery_count>=max(0,min(3,int(recovery_options.get("max_per_run",2)))):
                    raise RecoveryFailed("Wyczerpano limit odzyskiwania stanu w tej serii.") from layout_error
                recovery_count+=1
                event("recovery_wait",str(layout_error))
                policy,frame,obs,closed=recover(policy,android,recovery_options,event,allow_controls=execute)
                pending=(frame,obs)
                if closed and execute:
                    send_windows_push("FlyBrain wznowiony","Zamknięto znane okno i odzyskano planszę.",
                                      enabled=cfg.get("notifications_enabled",True))
        event("done",f"Wysłano {sent} ruchów; zaakceptowano {confirmed}. Osiągnięto limit serii.")
    except Exception as exc:
        if pending_record is not None:
            try:
                append_jsonl(folder/"logs/phone_moves.jsonl",pending_record |
                    {"status":"execution_unknown","error":str(exc)})
            except OSError: pass
        try: frame=android.screenshot()
        except Exception: pass
        if frame is not None: save_image(folder/"phone_stop.png",frame)
        # The desktop worker emits the single UI error event after this raises.
        raise


def run_phone(config: Path,steps: int = 1,execute: bool = False,speed_percent=75,accuracy_percent=50):
    """Include setup/ADB failures in the notification boundary too."""
    enabled=True
    try:
        enabled=load_config(config).get("notifications_enabled",True)
        return _run_phone(config,steps,execute,speed_percent,accuracy_percent)
    except Exception as exc:
        if execute: send_windows_push("FlyBrain wymaga uwagi",str(exc),enabled=enabled)
        raise
    finally:
        flush_notifications(2)
