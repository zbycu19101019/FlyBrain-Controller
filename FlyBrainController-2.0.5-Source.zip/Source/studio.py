"""Modern desktop UI with an explicit separation between phone and offline modes."""
import json
import os
from pathlib import Path
import queue
import secrets
import string
import subprocess
import sys
import threading
import time
import traceback
from tkinter import filedialog, messagebox
import customtkinter as ctk
from PIL import Image
from desktop import initialize_data, worker, ASSETS

BG="#0c111a"; PANEL="#151d29"; CARD="#1c2736"; TEXT="#eef3fa"; MUTED="#9dacc0"; ACCENT="#43dfb5"


def _publish_latest(messages,item):
    try:
        messages.put_nowait(item)
    except queue.Full:
        try: messages.get_nowait()
        except queue.Empty: pass
        try: messages.put_nowait(item)
        except queue.Full: pass


def device_monitor(config,messages,stop,refresh=None,interval=1.0,pause=None):
    from settings import load_config
    from android.adb import AndroidController
    from android.screenshot import load_image
    from phone_live import PhonePolicy
    import cv2
    last_error=None; policy=None; profile_stamp=None; preview_stamp=None
    data_folder=Path(config).resolve().parent
    profile_path=data_folder/"phone_profile.json"

    def publish_frame(frame):
        nonlocal policy,profile_stamp
        stamp=(profile_path.stat().st_mtime_ns,profile_path.stat().st_size) if profile_path.exists() else None
        if stamp != profile_stamp:
            try: policy=PhonePolicy(data_folder) if stamp is not None else None
            except Exception: policy=None
            profile_stamp=stamp
        if policy is None:
            summary={"error":"Brak profilu rozpoznawania telefonu."}
        else:
            try:
                obs=policy.read(frame)
                summary={"cells":len(policy.cells),"slots_total":len(policy.slots),
                    "free":sum(v=="empty" for v in obs.board.values()),
                    "slots":sum(v is not None for v in obs.slots.values()),
                    "counts":sum(v is not None for v in obs.board_counts.values())+sum(v is not None for v in obs.slot_counts.values()),
                    "blocked":sum(v in {"blocked","locked"} for v in obs.board.values()),
                    "error":None}
            except Exception as exc: summary={"error":str(exc)}
        h,w=frame.shape[:2]; scale=min(1.,360/w,780/h)
        display=cv2.resize(frame,None,fx=scale,fy=scale,interpolation=cv2.INTER_AREA) if scale<1 else frame
        _publish_latest(messages,("frame",(display,(w,h),summary)))

    while not stop.is_set():
        if pause is not None and pause.is_set():
            # The phone worker owns ADB while a task is active. Reuse its
            # atomically published screenshots so the preview remains live
            # without launching a competing screencap command.
            preview_path=data_folder/"phone_preview.png"
            try:
                stamp=preview_path.stat().st_mtime_ns
                if stamp != preview_stamp:
                    publish_frame(load_image(preview_path)); preview_stamp=stamp; last_error=None
            except (FileNotFoundError,OSError,ValueError):
                pass
            stop.wait(.1)
            continue
        try:
            cfg=load_config(config)
            device=AndroidController(cfg["adb_path"],cfg.get("device_serial"),timeout=4)
            device.check_connection()
            publish_frame(device.screenshot())
            last_error=None
        except Exception as exc:
            message=str(exc)
            if message != last_error:
                _publish_latest(messages,("error",message))
                last_error=message
        if refresh is not None and refresh.is_set(): refresh.clear()
        elif stop.wait(interval): break


class Studio:
    def __init__(self,root,folder,monitor=True):
        self.root,self.folder=root,Path(folder); self.config=initialize_data(self.folder)
        self.process=None; self.log_path=None; self.last_log=""; self.error=False
        self.phone_preferences_path=self.folder/"phone_controls.json"
        try: phone_preferences=json.loads(self.phone_preferences_path.read_text(encoding="utf-8"))
        except (OSError,ValueError,json.JSONDecodeError): phone_preferences={}
        self.phone_speed=ctk.DoubleVar(value=float(phone_preferences.get("speed",75)))
        self.phone_accuracy=ctk.DoubleVar(value=float(phone_preferences.get("accuracy",50)))
        self.messages=queue.Queue(maxsize=1); self.stop_event=threading.Event(); self.refresh_request=threading.Event(); self.monitor_pause=threading.Event(); self.image=None
        ctk.set_appearance_mode("dark")
        root.title("FlyBrain Studio 1.7.0 — telefon i laboratorium"); root.configure(fg_color=BG)
        root.geometry(f"{min(1380,root.winfo_screenwidth()-70)}x{min(920,root.winfo_screenheight()-90)}")
        root.minsize(1050,720); root.grid_columnconfigure(1,weight=1); root.grid_rowconfigure(1,weight=1)
        sidebar=ctk.CTkFrame(root,width=174,fg_color="#101722",corner_radius=0)
        sidebar.grid(row=0,column=0,rowspan=3,sticky="nsew"); sidebar.grid_propagate(False)
        self.label(sidebar,"FLYBRAIN",23,bold=True).pack(anchor="w",padx=22,pady=(30,0))
        self.label(sidebar,"S T U D I O   /   2.0.5",10,MUTED).pack(anchor="w",padx=22,pady=(4,32))
        for title,action in [("Telefon",lambda:self.set_mode(True)),("Laboratorium",lambda:self.set_mode(False)),
                             ("Inteligencja",self.intelligence_settings),("Kalibracja",self.calibrate),("Ustawienia",self.settings),("Pliki i wyniki",lambda:os.startfile(self.folder)),
                             ("Instrukcja",lambda:self.open_text(ASSETS/"README.md"))]:
            self.button(sidebar,title,action,title == "Telefon").pack(fill="x",padx=15,pady=5)
        self.label(sidebar,"REZERWUAR LIF\n100 neuronów\nSieć syntetyczna",12,MUTED,justify="left").pack(side="bottom",anchor="w",padx=22,pady=28)
        header=ctk.CTkFrame(root,fg_color="transparent"); header.grid(row=0,column=1,sticky="ew",padx=26,pady=(24,16))
        self.title=self.label(header,"Sterowanie telefonem",27,bold=True); self.title.pack(anchor="w")
        self.subtitle=self.label(header,"Rzeczywista plansza. Widoczne decyzje. Kontrolowane ruchy.",13,MUTED); self.subtitle.pack(anchor="w",pady=(4,0))
        learning=self.card(header); learning.pack(fill="x",pady=(10,0))
        self.label(learning,"CZEGO NAUCZYŁA SIĘ MUCHA",10,MUTED,bold=True).pack(anchor="w",padx=14,pady=(9,2))
        self.learning_summary=self.label(learning,"Odczytuję zapisany trening…",14,bold=True,wraplength=650,justify="left")
        self.learning_summary.pack(anchor="w",padx=14,pady=(0,2))
        self.learning_details=self.label(learning,"Model offline uczy się uproszczonej symulacji, nie rozgrywki na telefonie.",11,MUTED,wraplength=650,justify="left")
        self.learning_details.pack(anchor="w",padx=14,pady=(0,9))
        self.phone_data_summary=self.label(learning,"Dane z gry na telefonie: odczytuję…",13,bold=True,wraplength=650,justify="left")
        self.phone_data_summary.pack(anchor="w",padx=14,pady=(2,2))
        self.phone_data_details=self.label(learning,"Zapisane stany planszy i wyniki ruchów z telefonu.",11,MUTED,wraplength=650,justify="left")
        self.phone_data_details.pack(anchor="w",padx=14,pady=(0,9))
        self.refresh_learning_indicator()
        body=ctk.CTkFrame(root,fg_color="transparent"); body.grid(row=1,column=1,sticky="nsew",padx=26)
        body.grid_columnconfigure(0,weight=1); body.grid_rowconfigure(0,weight=1)
        center=ctk.CTkScrollableFrame(body,fg_color="transparent",corner_radius=0)
        center.grid(row=0,column=0,sticky="nsew",padx=(0,16)); center.grid_columnconfigure(0,weight=1)
        status=self.card(center); status.grid(row=0,column=0,sticky="ew",pady=(0,12))
        top=ctk.CTkFrame(status,fg_color="transparent"); top.pack(fill="x",padx=20,pady=(18,8))
        self.badge=self.label(top,"GOTOWY DO SPRAWDZENIA",11,ACCENT,bold=True); self.badge.pack(side="left")
        self.mode_label=self.label(top,"TRYB: TELEFON",11,MUTED); self.mode_label.pack(side="right")
        self.headline=self.label(status,"Sprawdzam połączenie…",23,bold=True,wraplength=500,justify="left"); self.headline.pack(anchor="w",padx=20,pady=(0,8))
        self.explanation=self.label(status,"Podgląd ekranu jest tylko odczytem. Ruchy rozpoczną się dopiero po kliknięciu przycisku.",13,MUTED,wraplength=500,justify="left"); self.explanation.pack(anchor="w",padx=20,pady=(0,20))
        pipeline=ctk.CTkFrame(status,fg_color="#101722",corner_radius=10); pipeline.pack(fill="x",padx=16,pady=(0,16))
        self.steps=[]
        for i,title in enumerate(("01  Obraz","02  Decyzja","03  Ruch","04  Kontrola")):
            pipeline.grid_columnconfigure(i,weight=1)
            label=self.label(pipeline,title,11,MUTED); label.grid(row=0,column=i,pady=12,padx=4); self.steps.append(label)
        self.phone_controls=self.card(center); self.phone_controls.grid(row=1,column=0,sticky="ew",pady=(0,12))
        self.label(self.phone_controls,"ZAGRAJ NA TELEFONIE",11,MUTED,bold=True).pack(anchor="w",padx=20,pady=(18,6))
        self.label(self.phone_controls,"Agent: widoczne kolory",18,bold=True).pack(anchor="w",padx=20)
        self.label(self.phone_controls,"Planuje kolejność do 3 ruchów z widocznych slotów. Uwzględnia sąsiadujące kolory i wyniki poprzednich partii; wykonuje ruch dopiero po bezpiecznym odczycie pola.",12,MUTED,wraplength=490,justify="left").pack(anchor="w",padx=20,pady=(6,14))
        row=self.row(self.phone_controls)
        self.label(row,"Prędkość sterowania",12,MUTED).pack(side="left")
        self.speed_value=self.label(row,"",12,bold=True); self.speed_value.pack(side="right")
        ctk.CTkSlider(self.phone_controls,from_=0,to=100,number_of_steps=20,variable=self.phone_speed,
            command=self.phone_controls_changed).pack(fill="x",padx=22,pady=(0,8))
        row=self.row(self.phone_controls)
        self.label(row,"Dokładność odczytu",12,MUTED).pack(side="left")
        self.accuracy_value=self.label(row,"",12,bold=True); self.accuracy_value.pack(side="right")
        ctk.CTkSlider(self.phone_controls,from_=0,to=100,number_of_steps=20,variable=self.phone_accuracy,
            command=self.phone_controls_changed).pack(fill="x",padx=22,pady=(0,10))
        self.phone_controls_changed()
        row=self.row(self.phone_controls)
        self.label(row,"Limit ruchów",12,MUTED).pack(side="left")
        self.limit=ctk.StringVar(value="1")
        ctk.CTkSegmentedButton(row,values=["1","10","50"],variable=self.limit,selected_color="#257b66").pack(side="right")
        row=self.row(self.phone_controls)
        self.button(row,"Zagraj na telefonie",lambda:self.start("phone",self.limit.get(),
            str(round(self.phone_speed.get())),str(round(self.phone_accuracy.get()))),True).pack(side="left",fill="x",expand=True,padx=(0,8))
        self.button(row,"Pokaż propozycję",lambda:self.start("preview")).pack(side="left")
        self.sim_controls=self.card(center)
        self.label(self.sim_controls,"LABORATORIUM OFFLINE",11,MUTED,bold=True).pack(anchor="w",padx=20,pady=(18,8))
        self.label(self.sim_controls,"Tutaj telefon nie wykonuje ruchów.",18,bold=True).pack(anchor="w",padx=20)
        self.label(self.sim_controls,"Trenuj przez samodzielną grę na uproszczonej planszy z przeszkodami. Ten model uczy się tylko symulacji, nie reguł niezaobserwowanej gry na telefonie.",12,MUTED,wraplength=490,justify="left").pack(anchor="w",padx=20,pady=10)
        row=self.row(self.sim_controls); self.agent=ctk.StringVar(value="greedy")
        ctk.CTkOptionMenu(row,variable=self.agent,values=["random","greedy","search","flybrain","selfplay"],fg_color=CARD).pack(side="left")
        self.button(row,"Uruchom symulację",lambda:self.start("main","--agent",self.agent.get()),True).pack(side="right")
        row=self.row(self.sim_controls)
        self.button(row,"Trenuj readout",lambda:self.start("train")).pack(side="left")
        self.button(row,"Porównaj agentów",lambda:self.start("benchmark")).pack(side="right")
        row=self.row(self.sim_controls)
        self.button(row,"Ucz samodzielnie z przeszkodami",lambda:self.start("selfplay"),True).pack(fill="x")
        ready=self.card(center); ready.grid(row=2,column=0,sticky="ew",pady=(0,12))
        self.label(ready,"GOTOWOŚĆ DO GRY",11,MUTED,bold=True).pack(anchor="w",padx=20,pady=(16,6))
        self.connection=self.label(ready,"○  ADB: trwa sprawdzanie",13,MUTED); self.connection.pack(anchor="w",padx=20,pady=5)
        self.profile=self.label(ready,"○  Profil planszy",13,MUTED); self.profile.pack(anchor="w",padx=20,pady=5)
        self.observation=self.label(ready,"○  Obserwacja: oczekiwanie",13,MUTED,wraplength=500,justify="left"); self.observation.pack(anchor="w",padx=20,pady=(5,16))
        activity=self.card(center); activity.grid(row=3,column=0,sticky="ew")
        self.label(activity,"CO SIĘ DZIEJE",11,MUTED,bold=True).pack(anchor="w",padx=20,pady=(16,6))
        self.history=ctk.CTkTextbox(activity,height=125,fg_color="transparent",font=("Segoe UI",12),text_color=TEXT,wrap="word")
        self.history.pack(fill="x",padx=12,pady=(0,12)); self.history.configure(state="disabled")
        self.log_line("Panel uruchomiony. Żaden ruch nie został wysłany.")
        preview=self.card(body); preview.grid(row=0,column=1,sticky="ns")
        self.label(preview,"EKRAN TELEFONU",11,MUTED,bold=True).pack(anchor="w",padx=18,pady=(18,4))
        self.screen_status=self.label(preview,"Oczekiwanie na ADB",12,ACCENT); self.screen_status.pack(anchor="w",padx=18,pady=(0,10))
        self.preview=ctk.CTkLabel(preview,text="Podłącz i odblokuj\ntelefon z Androidem",width=266,height=530,fg_color="#080c13",corner_radius=12,text_color=MUTED)
        self.preview.pack(padx=12,pady=4)
        self.button(preview,"Odśwież teraz",self.refresh_request.set).pack(fill="x",padx=12,pady=(4,0))
        self.label(preview,"PODGLĄD · NIE WYSYŁA DOTKNIĘĆ",10,MUTED).pack(pady=12)
        footer=ctk.CTkFrame(root,fg_color="transparent"); footer.grid(row=2,column=1,sticky="ew",padx=26,pady=14)
        self.button(footer,"ZATRZYMAJ RUCHY",self.stop,danger=True).pack(side="left")
        self.footer=self.label(footer,"Bez aktywnego zadania",12,MUTED); self.footer.pack(side="left",padx=16)
        self.button(footer,"Log techniczny",self.show_log).pack(side="right")
        root.protocol("WM_DELETE_WINDOW",self.close)
        if monitor: threading.Thread(target=device_monitor,args=(self.config,self.messages,self.stop_event,self.refresh_request,1.0,self.monitor_pause),daemon=True).start()
        root.after(250,self.poll)

    def label(self,parent,text,size=13,color=TEXT,bold=False,**kwargs):
        return ctk.CTkLabel(parent,text=text,font=("Segoe UI",size,"bold" if bold else "normal"),text_color=color,**kwargs)
    def phone_controls_changed(self,_value=None):
        speed=max(0,min(100,int(round(self.phone_speed.get()))))
        accuracy=max(0,min(100,int(round(self.phone_accuracy.get()))))
        duration=round(400-2.4*speed)
        stable_frames=3+round(accuracy*4/100)
        threshold=.45+.004*max(0,accuracy-50)
        self.speed_value.configure(text=f"{speed}% · {duration} ms")
        self.accuracy_value.configure(text=f"{accuracy}% · {stable_frames} klatek · próg {threshold:.2f}")
        temporary=self.phone_preferences_path.with_suffix(".tmp")
        try:
            temporary.write_text(json.dumps(dict(speed=speed,accuracy=accuracy)),encoding="utf-8")
            temporary.replace(self.phone_preferences_path)
        except OSError:
            try: temporary.unlink(missing_ok=True)
            except OSError: pass
    def card(self,parent): return ctk.CTkFrame(parent,fg_color=PANEL,corner_radius=16)
    def row(self,parent):
        row=ctk.CTkFrame(parent,fg_color="transparent"); row.pack(fill="x",padx=20,pady=(0,16)); return row
    def button(self,parent,text,command,primary=False,danger=False):
        return ctk.CTkButton(parent,text=text,command=command,height=40,corner_radius=9,font=("Segoe UI",12,"bold"),
            fg_color="#713545" if danger else ACCENT if primary else CARD,
            hover_color="#984559" if danger else "#6fe7c6" if primary else "#2a3a50",text_color="#09271f" if primary else TEXT)

    def set_mode(self,phone):
        if self.process and self.process.poll() is None:
            messagebox.showinfo("Zadanie trwa","Najpierw zatrzymaj lub zakończ bieżące zadanie."); return
        self.title.configure(text="Sterowanie telefonem" if phone else "Laboratorium offline")
        self.subtitle.configure(text="Rzeczywista plansza. Widoczne decyzje. Kontrolowane ruchy." if phone else "Testy agentów i trening modelu. Bez sterowania telefonem.")
        self.phone_controls.grid_remove(); self.sim_controls.grid_remove()
        (self.phone_controls if phone else self.sim_controls).grid(row=1,column=0,sticky="ew",pady=(0,12))
        self.mode_label.configure(text="TRYB: TELEFON" if phone else "TRYB: SYMULACJA")
        self.headline.configure(text="Telefon czeka na polecenie" if phone else "Symulacja nie steruje telefonem")
        self.explanation.configure(text="Wybierz limit i kliknij Zagraj. Propozycja pozwala wcześniej obejrzeć wybrany ruch." if phone else "Wybrany agent rozegra uproszczoną grę w pamięci komputera.")

    def open_text(self,path): subprocess.Popen(["notepad.exe",str(path)])
    def show_log(self):
        if self.log_path and self.log_path.exists(): self.open_text(self.log_path)
        else: messagebox.showinfo("Log","Nie uruchomiono jeszcze żadnego zadania w tej sesji.")

    def intelligence_settings(self):
        from settings import load_config
        from phone_intelligence import load_options
        from game.hexa_board import HexaRules,HiddenPrior
        from agents.hexa_mcts import HexaMCTS
        settings=load_options(self.folder)
        window=ctk.CTkToplevel(self.root); window.title("Hexa Color 3D — inteligencja"); window.geometry("680x690")
        panel=ctk.CTkScrollableFrame(window); panel.pack(fill="both",expand=True,padx=15,pady=15)
        self.label(panel,"OCR · silnik Hexa · MCTS · LIF",22,bold=True).pack(pady=10)
        brain_config=load_config(self.config)
        self.label(panel,f"Sieć LIF: {brain_config['brain_neurons']} neuronów · {brain_config['brain_groups']} grup",14,ACCENT).pack(pady=4)
        self.label(panel,"Liczby opisują widoczną grupę. Ukryte warstwy są losowane z jawnych założeń. Reguły kaskad wymagają sprawdzenia w grze.",13,MUTED,wraplength=590).pack(pady=8)
        mode=ctk.StringVar(value=settings['mode'])
        ctk.CTkOptionMenu(panel,variable=mode,values=['colors','shadow','mcts']).pack(pady=6)
        self.label(panel,"colors: kolory | shadow: analiza bez wpływu na ruch | mcts: decyzje silnika",12,MUTED,wraplength=590).pack(pady=6)
        fields={}
        for key,label in [('clear_size','Próg czyszczenia'),('iterations','Maksimum symulacji'),('budget_ms','Budżet MCTS (ms)'),('horizon','Głębokość'),('hidden_probability','Założone prawdopodobieństwo ukrytej grupy')]:
            row=ctk.CTkFrame(panel,fg_color='transparent'); row.pack(fill='x',pady=4)
            self.label(row,label,13).pack(side='left')
            variable=ctk.StringVar(value=str(settings[key])); fields[key]=variable
            ctk.CTkEntry(row,textvariable=variable,width=100).pack(side='right')
        flow=ctk.StringVar(value=settings['flow']); clearing=ctk.StringVar(value=settings['clear_mode'])
        ctk.CTkOptionMenu(panel,variable=flow,values=['toward_placed','toward_largest']).pack(pady=6)
        ctk.CTkOptionMenu(panel,variable=clearing,values=['whole_run','exact_threshold']).pack(pady=6)
        verified=ctk.BooleanVar(value=settings['rules_verified']); lif=ctk.BooleanVar(value=settings['lif_enabled'])
        ctk.CTkCheckBox(panel,text='Potwierdziłem próg, kierunek i sposób czyszczenia w grze',variable=verified).pack(pady=8)
        ctk.CTkCheckBox(panel,text='LIF: ucz z potwierdzonych ruchów i wspieraj MCTS',variable=lif).pack(pady=8)
        self.label(panel,"LIF używa osobnego readoutu telefonu; zaczyna doradzać po 12 potwierdzonych przykładach. Nie importuje ocen z uproszczonego symulatora.",12,MUTED,wraplength=590).pack(pady=8)
        def save():
            if self.process and self.process.poll() is None:
                messagebox.showinfo('Zadanie trwa','Najpierw zakończ bieżącą serię.'); return
            try:
                settings.update(mode=mode.get(),flow=flow.get(),clear_mode=clearing.get(),rules_verified=verified.get(),lif_enabled=lif.get())
                for key,var in fields.items(): settings[key]=float(var.get()) if key=='hidden_probability' else int(var.get())
                rules=HexaRules(settings['clear_size'],settings['flow'],settings['clear_mode'])
                HexaMCTS(rules,settings['iterations'],settings['budget_ms'],settings['horizon'])
                HiddenPrior(settings['hidden_probability'],settings['hidden_groups'],settings['hidden_max_count'])
                if settings['mode']=='mcts' and not settings['rules_verified']: raise ValueError('Najpierw potwierdź reguły albo wybierz shadow.')
                path=self.folder/'phone_intelligence.json'; temporary=path.with_suffix('.tmp')
                temporary.write_text(json.dumps(settings,indent=2),encoding='utf-8'); temporary.replace(path)
                self.log_line('Zapisano ustawienia inteligencji. Obowiązują od nowej serii.'); window.destroy()
            except (ValueError,OSError) as exc: messagebox.showerror('Ustawienia inteligencji',str(exc))
        self.button(panel,'Zapisz',save,True).pack(pady=12)

    def calibrate(self):
        window=ctk.CTkToplevel(self.root); window.title("Kalibracja telefonu"); window.geometry("650x420")
        self.label(window,"Zaznacz środki pól i slotów, zbierz kolory oraz stały wzorzec ekranu. Zapisuj klawiszem q.",14,wraplength=600).pack(padx=20,pady=20)
        self.button(window,"1. Punkty planszy i slotów",lambda:self.start("calibrate")).pack(pady=8)
        color=ctk.StringVar(value="empty")
        ctk.CTkOptionMenu(window,variable=color,values=["empty","red","blue","green","yellow","orange","purple","pink","obstacle"]).pack(pady=8)
        self.button(window,"2. Zbierz wybrany kolor",lambda:self.start("calibrate",color.get())).pack(pady=8)
        self.button(window,"3. Zaznacz stały wzorzec ekranu",lambda:self.start("calibrate","guard")).pack(pady=8)
        self.label(window,"Nowe punkty unieważniają poprzedni profil do czasu zapisania wzorca. Najpierw sprawdź propozycję bez ruchu.",12,MUTED,wraplength=600).pack(padx=20,pady=16)

    def settings(self):
        from settings import load_config,save_config
        window=ctk.CTkToplevel(self.root); window.title("Ustawienia połączenia"); window.geometry("690x760"); window.transient(self.root)
        cfg=load_config(self.config)
        self.label(window,"Połączenie i profil gry",23,bold=True).pack(anchor="w",padx=24,pady=(24,8))
        self.label(window,"Ścieżka do adb.exe",12,MUTED).pack(anchor="w",padx=24,pady=(10,4))
        variable=ctk.StringVar(value=cfg["adb_path"])
        ctk.CTkEntry(window,textvariable=variable,width=640,height=38).pack(padx=24)
        def browse():
            selected=filedialog.askopenfilename(filetypes=[("ADB","adb.exe")])
            if selected: variable.set(selected)
        def save():
            current=load_config(self.config); current["adb_path"]=variable.get().strip() or "adb"; save_config(self.config,current)
            self.log_line("Zapisano ustawienia ADB."); window.destroy()
        row=self.row(window)
        self.button(row,"Wskaż adb.exe",browse).pack(side="left"); self.button(row,"Zapisz",save,True).pack(side="right")
        self.label(window,"Profil telefonu opisuje konkretne pola, kolory i tło. Zmiana poziomu lub rozdzielczości może wymagać ponownej kalibracji.",13,MUTED,wraplength=620,justify="left").pack(anchor="w",padx=24,pady=12)
        row=self.row(window)
        self.button(row,"Konfiguracja YAML",lambda:self.open_text(self.config)).pack(side="left")
        self.button(row,"Profil telefonu",lambda:self.open_text(self.folder/"phone_profile.json")).pack(side="left",padx=8)
        self.label(window,"ADB PRZEZ WI‑FI",14,bold=True).pack(anchor="w",padx=24,pady=(18,4))
        self.label(window,"Android 11+: komputer i telefon muszą być w tej samej sieci Wi‑Fi. Zeskanuj kod na telefonie w: Opcje programisty → Debugowanie bezprzewodowe → Sparuj urządzenie kodem QR.",12,MUTED,wraplength=640,justify="left").pack(anchor="w",padx=24,pady=(0,10))
        cfg=load_config(self.config)
        self.label(window,"Adres parowania IP:port",12,MUTED).pack(anchor="w",padx=24,pady=(4,3))
        pair_endpoint=ctk.StringVar(value="")
        ctk.CTkEntry(window,textvariable=pair_endpoint,width=640,height=36,placeholder_text="np. 192.168.1.20:37123").pack(padx=24)
        self.label(window,"Kod parowania",12,MUTED).pack(anchor="w",padx=24,pady=(8,3))
        pair_code=ctk.StringVar(value="")
        ctk.CTkEntry(window,textvariable=pair_code,width=640,height=36,show="•").pack(padx=24)
        self.label(window,"Adres połączenia IP:port",12,MUTED).pack(anchor="w",padx=24,pady=(8,3))
        connect_endpoint=ctk.StringVar(value=cfg.get("device_serial") or "")
        ctk.CTkEntry(window,textvariable=connect_endpoint,width=640,height=36,placeholder_text="np. 192.168.1.20:42817").pack(padx=24)
        wifi_status=self.label(window,"Po USB lub Wi‑Fi: ADB wybiera zapisane urządzenie.",12,MUTED,wraplength=640,justify="left"); wifi_status.pack(anchor="w",padx=24,pady=8)

        def show_pairing_qr():
            if getattr(self,"_wifi_connecting",False):
                wifi_status.configure(text="Polecenie ADB jest już wykonywane.",text_color="#ffbe78"); return
            try:
                import cv2
                alphabet=string.ascii_letters+string.digits
                service="studio-"+"".join(secrets.choice(alphabet) for _ in range(10))
                password="".join(secrets.choice(alphabet) for _ in range(12))
                payload=f"WIFI:T:ADB;S:{service};P:{password};;"
                code=cv2.QRCodeEncoder_create().encode(payload)
                code=cv2.copyMakeBorder(code,4,4,4,4,cv2.BORDER_CONSTANT,value=255)
                qr_image=Image.fromarray(code).resize((320,320),Image.Resampling.NEAREST)
            except Exception as exc:
                wifi_status.configure(text="Nie można utworzyć kodu QR: "+str(exc),text_color="#ffbe78"); return

            qr_window=ctk.CTkToplevel(window); qr_window.title("Parowanie ADB — kod QR"); qr_window.geometry("430x520"); qr_window.transient(window)
            qr_window.grab_set()
            self.label(qr_window,"Zeskanuj kod w ustawieniach debugowania bezprzewodowego telefonu.",13,MUTED,wraplength=380,justify="center").pack(padx=18,pady=(18,8))
            qr_ctk=ctk.CTkImage(light_image=qr_image,dark_image=qr_image,size=(300,300))
            qr_label=ctk.CTkLabel(qr_window,image=qr_ctk,text=""); qr_label.image=qr_ctk; qr_label.pack(pady=4)
            qr_status=self.label(qr_window,"Czekam na skan i parowanie telefonu…",12,ACCENT,wraplength=380,justify="center"); qr_status.pack(padx=18,pady=(8,14))
            cancel=threading.Event()
            def close_qr():
                cancel.set(); qr_window.destroy()
            qr_window.protocol("WM_DELETE_WINDOW",close_qr)
            adb_path=load_config(self.config).get("adb_path","adb")
            self._wifi_connecting=True

            def adb_output(*args):
                result=subprocess.run([adb_path,*args],capture_output=True,text=True,timeout=8,shell=False,
                    creationflags=getattr(subprocess,"CREATE_NO_WINDOW",0))
                if result.returncode:
                    raise RuntimeError((result.stderr or result.stdout).strip() or f"ADB zakończyło się kodem {result.returncode}")
                return result.stdout.strip()

            def report_qr(text,color=ACCENT,finish=False):
                def apply():
                    if not qr_window.winfo_exists(): return
                    qr_status.configure(text=text,text_color=color)
                    if finish:
                        self._wifi_connecting=False
                        if color==ACCENT:
                            cancel.set(); self.refresh_request.set()
                self.root.after(0,apply)

            def watch_pairing():
                paired_host=None; deadline=time.monotonic()+90
                try:
                    while time.monotonic()<deadline and not cancel.is_set():
                        services=adb_output("mdns","services")
                        pairing=None
                        for line in services.splitlines():
                            parts=line.split()
                            if len(parts)>=3 and parts[0]==service and parts[1]=="_adb-tls-pairing._tcp":
                                pairing=parts[2]; break
                        if pairing:
                            report_qr("Telefon znaleziony. Paruję ADB…")
                            result=adb_output("pair",pairing,password)
                            paired_host=pairing.rsplit(":",1)[0]
                            report_qr("Sparowano. Nawiązuję połączenie ADB…")
                            break
                        cancel.wait(.5)
                    if not paired_host:
                        if not cancel.is_set(): report_qr("Nie wykryto skanu w 90 s. Otwórz ponownie kod QR i spróbuj jeszcze raz.","#ffbe78",True)
                        return
                    connect_deadline=time.monotonic()+25
                    while time.monotonic()<connect_deadline and not cancel.is_set():
                        services=adb_output("mdns","services")
                        for line in services.splitlines():
                            parts=line.split()
                            if len(parts)>=3 and parts[1]=="_adb-tls-connect._tcp" and parts[2].rsplit(":",1)[0]==paired_host:
                                endpoint=parts[2]
                                result=adb_output("connect",endpoint)
                                current=load_config(self.config); current["device_serial"]=endpoint; save_config(self.config,current)
                                report_qr(f"Połączono z telefonem przez Wi‑Fi ({endpoint}).",ACCENT,True)
                                return
                        cancel.wait(.5)
                    if not cancel.is_set(): report_qr("Telefon sparowano, ale nie pojawił się jeszcze adres usługi ADB. Sprawdź, czy Debugowanie bezprzewodowe jest włączone.","#ffbe78",True)
                except Exception as exc:
                    report_qr("ADB: "+str(exc),"#ffbe78",True)
                finally:
                    self.root.after(0,lambda:setattr(self,"_wifi_connecting",False))

            threading.Thread(target=watch_pairing,daemon=True).start()

        def wifi_command(args,done):
            if getattr(self,"_wifi_connecting",False):
                wifi_status.configure(text="Polecenie ADB jest już wykonywane.",text_color="#ffbe78"); return
            self._wifi_connecting=True; wifi_status.configure(text="Łączę przez ADB…",text_color=ACCENT)
            adb_path=load_config(self.config).get("adb_path","adb")
            def run():
                try:
                    result=subprocess.run([adb_path,*args],capture_output=True,text=True,timeout=30,shell=False,
                        creationflags=getattr(subprocess,"CREATE_NO_WINDOW",0))
                    if result.returncode: raise RuntimeError((result.stderr or result.stdout).strip() or f"ADB zakończyło się kodem {result.returncode}")
                    output=(result.stdout or result.stderr).strip()
                    self.root.after(0,lambda:done(output))
                except Exception as exc:
                    self.root.after(0,lambda message=str(exc):wifi_status.configure(text="ADB: "+message,text_color="#ffbe78"))
                finally:
                    self.root.after(0,lambda:setattr(self,"_wifi_connecting",False))
            threading.Thread(target=run,daemon=True).start()

        def connect_wifi():
            endpoint=connect_endpoint.get().strip()
            if not endpoint or ":" not in endpoint:
                wifi_status.configure(text="Wpisz adres telefonu w formacie IP:port.",text_color="#ffbe78"); return
            def connected(output):
                current=load_config(self.config); current["device_serial"]=endpoint; save_config(self.config,current)
                wifi_status.configure(text=(output or "Połączono")+f". Zapisano urządzenie {endpoint}; podgląd odświeży się automatycznie.",text_color=ACCENT)
                self.refresh_request.set()
            wifi_command(["connect",endpoint],connected)

        def pair_wifi():
            endpoint=pair_endpoint.get().strip(); code=pair_code.get().strip()
            if not endpoint or ":" not in endpoint or not code:
                wifi_status.configure(text="Wpisz adres IP:port parowania i kod pokazany przez Androida.",text_color="#ffbe78"); return
            wifi_command(["pair",endpoint,code],lambda output:wifi_status.configure(text=output or "Parowanie zakończone. Teraz połącz adres IP:port z debugowania bezprzewodowego.",text_color=ACCENT))

        wifi_row=ctk.CTkFrame(window,fg_color="transparent"); wifi_row.pack(fill="x",padx=24,pady=(2,0))
        self.button(wifi_row,"Pokaż kod QR",show_pairing_qr).pack(side="left")
        self.button(wifi_row,"Sparuj telefon",pair_wifi).pack(side="left")
        self.button(wifi_row,"Połącz przez Wi‑Fi",connect_wifi,True).pack(side="right")

    def log_line(self,message):
        self.history.configure(state="normal"); self.history.insert("end",time.strftime("%H:%M:%S")+"  "+message+"\n")
        self.history.see("end"); self.history.configure(state="disabled")

    def refresh_learning_indicator(self):
        report=self.folder/"data"/"models"/"self_play_report.json"
        try:
            data=json.loads(report.read_text(encoding="utf-8"))
            episodes=int(data.get("total_episodes",data.get("episodes",0))); success=float(data.get("success_percent",0))
            samples=int(data.get("samples",0)); scenarios=data.get("scenario_counts",{})
            topology_count=len(scenarios.get("topologies",{}))
            sizes=list(scenarios.get("board_sizes",{}))
            size_text=f"{min(map(int,sizes))}–{max(map(int,sizes))} pól" if sizes else "różne rozmiary"
            obstacle_values=list(scenarios.get("obstacle_counts",{}))
            obstacle_text=f"{min(map(int,obstacle_values))}–{max(map(int,obstacle_values))} przeszkód" if obstacle_values else "zmienne przeszkody"
            self.learning_summary.configure(text=f"{success:.0f}% skuteczności ostatniej serii  ·  {episodes} gier  ·  {samples} przykładów")
            self.learning_details.configure(text=(f"Offline: {topology_count or 4} układy planszy, {size_text}, {obstacle_text}; "
                "zmienne tacki i długości stosów. Symulator jest uproszczony i nie odtwarza dokładnie gry z telefonu."))
        except (OSError,ValueError,TypeError,json.JSONDecodeError):
            self.learning_summary.configure(text="Brak zapisanego treningu")
            self.learning_details.configure(text="Uruchom „Ucz samodzielnie z przeszkodami” w Laboratorium offline. Model telefonu obecnie rozpoznaje widoczne kolory i kłódki; nie uczy się jeszcze z ruchów w grze." )
        self.refresh_phone_data_indicator()

    def refresh_phone_data_indicator(self):
        path=self.folder/"logs"/"phone_moves.jsonl"
        total=verified=unconfirmed=0; sessions=set()
        try:
            if path.exists():
                with path.open("r",encoding="utf-8") as stream:
                    for line in stream:
                        try: row=json.loads(line)
                        except json.JSONDecodeError: continue
                        if not isinstance(row,dict): continue
                        status=row.get("status")
                        if status=="planned": continue
                        total+=1
                        verified+=status=="verified"
                        unconfirmed+=status in {"missed_or_unconfirmed","execution_unknown"}
                        if row.get("run_id"): sessions.add(row["run_id"])
            if total:
                self.phone_data_summary.configure(text=f"Pamięć muchy: {verified} potwierdzonych ruchów · {len(sessions)} serii · {total} obserwacji")
                self.phone_data_details.configure(text=(f"Uczę ocenę ruchów na podstawie zmian po partiach: połączeń kolorów i zachowanych wolnych pól. "
                    f"Pamięć rozpoznaje podobne układy niezależnie od pozycji stosu; równorzędne wybory są losowe. {unconfirmed} ruchów wymagało kontroli."))
            else:
                self.phone_data_summary.configure(text="Pamięć muchy: czeka na pierwszą grę")
                self.phone_data_details.configure(text="Zapamiętam planszę, wybrany ruch i jego wynik, a później wykorzystam podobne sytuacje przy wyborze ruchów.")
        except OSError as exc:
            self.phone_data_summary.configure(text="Nie można odczytać danych z telefonu")
            self.phone_data_details.configure(text=str(exc))

    def start(self,action,*args):
        if self.process and self.process.poll() is None:
            messagebox.showinfo("Zadanie trwa","Poczekaj na wynik lub kliknij ZATRZYMAJ RUCHY."); return
        folder=self.folder/"logs/runs"; folder.mkdir(parents=True,exist_ok=True)
        self.log_path=folder/(str(time.time_ns())+".log"); self.last_log=""; self.error=False
        command=[sys.executable]
        if not getattr(sys,"frozen",False): command.append(str(ASSETS/"desktop.py"))
        command += ["--worker",str(self.log_path),action,str(self.config),*args]
        if action in {"phone","preview","calibrate"}: self.monitor_pause.set()
        self.process=subprocess.Popen(command,cwd=self.folder,creationflags=getattr(subprocess,"CREATE_NO_WINDOW",0))
        titles={"phone":"Uruchamiam sterowanie telefonem","preview":"Przygotowuję propozycję ruchu","main":"Uruchamiam symulację offline","train":"Zbieram dane i trenuję readout","benchmark":"Porównuję czterech agentów"}
        self.headline.configure(text=titles.get(action,action)); self.badge.configure(text="ZADANIE W TOKU",text_color=ACCENT)
        self.explanation.configure(text="Śledź kolejne kroki poniżej. W każdej chwili możesz zatrzymać zadanie.")
        self.footer.configure(text="Aktywne zadanie: "+action); self.log_line(titles.get(action,action))

    def event(self,item):
        kind=item.get("event"); message=item.get("message","")
        stage={"observing":0,"decision":1,"preview":1,"moving":2,"waiting":3,"verified":3}.get(kind)
        if kind in {"analyzing","cascade","recovery_wait","recovery_calibrate","recovery_control","recovered"}: stage=3
        for i,label in enumerate(self.steps): label.configure(text_color=ACCENT if i == stage else MUTED)
        headings={"observing":"Odczytuję ekran","decision":"Ruch został wybrany","moving":"Wysyłam gest do telefonu","waiting":"Czekam na grę","verified":"Ruch potwierdzony","preview":"Propozycja — bez wykonania","done":"Seria ruchów zakończona","stopped":"Zatrzymano automat","error":"Potrzebna uwaga"}
        headings.update(analyzing="Analizuję ponownie — automat działa",cascade="Reakcja kaskadowa",recovery_wait="Odzyskuję stan — oczekiwanie",
                        recovery_calibrate="Ponowna kalibracja planszy",recovery_control="Obsługa znanego okna",
                        recovered="Plansza odzyskana")
        self.headline.configure(text=headings.get(kind,"Trwa zadanie")); self.explanation.configure(text=message); self.log_line(message)
        if kind == "error": self.error=True; self.badge.configure(text="WSTRZYMANO",text_color="#ffbe78")
        if kind in {"verified","error"}: self.refresh_phone_data_indicator()

    def poll(self):
        latest=None
        while not self.messages.empty(): latest=self.messages.get_nowait()
        if latest:
            kind,value=latest
            if kind == "frame":
                pixels,screen_size,summary=value
                image=Image.fromarray(pixels[:,:,::-1]); height=min(585,max(440,self.root.winfo_height()-240)); width=round(height*image.width/image.height)
                self.image=ctk.CTkImage(light_image=image,dark_image=image,size=(width,height))
                self.preview.configure(image=self.image,text="",width=max(266,width),height=height)
                self.screen_status.configure(text=f"NA ŻYWO  ·  {screen_size[0]} × {screen_size[1]}",text_color=ACCENT)
                self.connection.configure(text="●  ADB: telefon połączony",text_color=ACCENT)
                if summary.get("error"):
                    self.profile.configure(text="○  Profil wymaga sprawdzenia",text_color="#ffbe78")
                    self.observation.configure(text=summary["error"],text_color=MUTED)
                    if self.log_path is None: self.headline.configure(text="Połączenie działa. Sprawdź profil gry.")
                else:
                    self.profile.configure(text=f"●  Profil: {summary['cells']} pól / {summary['slots_total']} sloty",text_color=ACCENT)
                    self.observation.configure(text=f"●  Plansza: {summary['free']} wolnych, {summary['blocked']} zablokowanych (w tym kłódki)/nieczytelnych pól; {summary['slots']} stosy w slotach; OCR: {summary.get('counts',0)} liczb",text_color=MUTED)
                    if self.log_path is None:
                        self.headline.configure(text="Telefon gotowy do pierwszego ruchu")
                        self.explanation.configure(text="Plansza została rozpoznana. Kliknij Zagraj na telefonie lub najpierw obejrzyj propozycję.")
            else:
                self.connection.configure(text="○  ADB: brak gotowego telefonu",text_color="#ffbe78")
                self.screen_status.configure(text="BRAK AKTUALNEGO OBRAZU",text_color="#ffbe78"); self.observation.configure(text=value,text_color=MUTED)
        if self.log_path and self.log_path.exists():
            text=self.log_path.read_text(encoding="utf-8",errors="replace"); full=text[:text.rfind("\n")+1]
            if full != self.last_log:
                for line in full[len(self.last_log):].splitlines():
                    try:
                        item=json.loads(line)
                        if isinstance(item,dict) and "event" in item: self.event(item)
                    except json.JSONDecodeError:
                        if line.startswith("step="): self.log_line("Symulacja: "+line)
                        elif line.startswith("Outcome:"):
                            self.headline.configure(text="Symulacja offline zakończona"); self.explanation.configure(text="Wynik: "+line.split(":",1)[1].strip()+". Telefon nie wykonywał ruchów.")
                        elif "Training data:" in line: self.explanation.configure(text="Zbieranie danych: "+line)
                        elif line.startswith("Self-play:"):
                            self.log_line(line)
                            self.learning_summary.configure(text="Trwa samodzielny trening offline…")
                            self.learning_details.configure(text=line)
                        elif line.startswith("ERROR:"): self.error=True; self.explanation.configure(text=line)
                self.last_log=full
        if self.process and self.process.poll() is not None:
            code=self.process.returncode
            if code and not self.error:
                self.headline.configure(text="Zadanie przerwane"); self.explanation.configure(text="Szczegóły są w logu technicznym. Nie wysyłam kolejnych ruchów.")
            self.badge.configure(text="WSTRZYMANO" if code else "ZAKOŃCZONO",text_color="#ffbe78" if code else ACCENT)
            self.footer.configure(text="Bez aktywnego zadania"); self.process=None
            self.monitor_pause.clear(); self.refresh_request.set()
            self.refresh_learning_indicator()
        self.root.after(400,self.poll)

    def stop(self):
        if self.process and self.process.poll() is None:
            self.process.terminate(); self.error=True
            self.log_line("Zatrzymano zadanie. Wysłany wcześniej gest może jeszcze się zakończyć.")
            self.headline.configure(text="Zatrzymano przez użytkownika"); self.explanation.configure(text="Nie będą wysyłane kolejne ruchy. Podgląd pozostaje aktywny.")
    def close(self): self.stop_event.set(); self.stop(); self.root.destroy()


def entry():
    if len(sys.argv)>1 and sys.argv[1] == "--worker": return worker(sys.argv[2:])
    if len(sys.argv)>1 and sys.argv[1] == "--self-test":
        folder=Path(sys.argv[2]); folder.mkdir(parents=True,exist_ok=True)
        try:
            root=ctk.CTk(); root.withdraw(); app=Studio(root,folder,monitor=False); root.update(); root.destroy()
            code=worker([str(folder/"smoke.log"),"main",str(app.config),"--agent","flybrain","--seed","10042"])
            from phone_intelligence import smoke_check
            (folder/"intelligence-smoke.json").write_text(json.dumps(smoke_check(folder)),encoding="utf-8")
            from win11toast import notify, XmlDocument
            document=XmlDocument(); document.load_xml('<toast><visual><binding template="ToastGeneric"/></visual></toast>')
            (folder/"notification-smoke.txt").write_text("Native notification dependencies and XML: OK",encoding="utf-8")
            (folder/"result.txt").write_text(f"GUI and bundled model test: {code}",encoding="utf-8"); return code
        except Exception:
            (folder/"error.txt").write_text(traceback.format_exc(),encoding="utf-8"); return 2
    folder=Path(os.environ.get("LOCALAPPDATA",str(Path.home())))/"FlyBrainController"/"Data"
    root=ctk.CTk(); Studio(root,folder); root.mainloop(); return 0
