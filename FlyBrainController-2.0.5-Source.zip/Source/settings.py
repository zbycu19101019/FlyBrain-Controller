"""Configuration paths are relative to the configuration file, not the shell."""
from pathlib import Path
import yaml

ROOT = Path(__file__).resolve().parent


def load_config(path: str | Path = ROOT / "config.yaml") -> dict:
    path = Path(path).resolve()
    cfg = yaml.safe_load(path.read_text(encoding="utf-8"))
    if not isinstance(cfg, dict):
        raise ValueError("Configuration must be a mapping")
    cfg["_root"] = str(path.parent)
    for name in ("board_cells", "slots", "neighbors"):
        cfg[name] = {int(k): v for k, v in cfg.get(name, {}).items()}
    return cfg


def resolve(cfg: dict, path: str) -> Path:
    return Path(cfg["_root"]) / path


def save_config(path: str | Path, cfg: dict) -> None:
    path = Path(path)
    clean = {k: v for k, v in cfg.items() if not k.startswith("_")}
    temporary = path.with_suffix(".tmp")
    temporary.write_text(yaml.safe_dump(clean, sort_keys=False, allow_unicode=True), encoding="utf-8")
    temporary.replace(path)
