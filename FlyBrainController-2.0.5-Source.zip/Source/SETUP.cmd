@echo off
cd /d "%~dp0"
py -3.12 -m venv .venv
if errorlevel 1 goto fail
".venv\Scripts\python.exe" -m pip install -r requirements-desktop.txt
if errorlevel 1 goto fail
echo Gotowe. Uruchom START.cmd.
pause
exit /b 0
:fail
echo Instalacja nie powiodla sie. Wymagany Python 3.12 i dostep do internetu.
pause
exit /b 1
