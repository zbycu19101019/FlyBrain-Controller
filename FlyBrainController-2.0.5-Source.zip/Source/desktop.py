"""Windows desktop entry point and isolated background workers."""
from contextlib import redirect_stdout, redirect_stderr
import os
from pathlib import Path
import shutil
import subprocess
import sys
import traceback
import tkinter as tk
from tkinter import ttk, filedialog, messagebox


ASSETS = Path(__file__).resolve().parent


def initialize_data(folder: Path) -> Path:
    folder.mkdir(parents=True, exist_ok=True)
    for relative in ("config.yaml", "data/models/readout.npz", "data/models/training_report.json",
                     "data/models/self_play.npz", "data/models/self_play_report.json"):
        destination = folder / relative
        source = ASSETS / relative
        if source.exists() and not destination.exists():
            destination.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(source, destination)
    upgrade_brain(folder)
    return folder / "config.yaml"


def upgrade_brain(folder):
    """Migrate the shipped 100-neuron preset, preserving custom networks and backups."""
    from settings import load_config,save_config
    cfg=load_config(folder/'config.yaml'); defaults=load_config(ASSETS/'config.yaml')
    cfg.setdefault('self_play_model','data/models/self_play.npz')
    if cfg.get('brain_backend')!='synthetic' or cfg.get('brain_neurons')!=100:
        return False
    keys=['brain_seed','brain_duration_ms','brain_dt','brain_bins','brain_groups','brain',
          'encoder_colors','rules','heuristic_weights','readout_model','self_play_model']
    if any(cfg.get(k)!=defaults.get(k) for k in keys): return False
    backup=folder/'backups'/'before-1000-neurons'
    for relative in ['config.yaml','data/models/readout.npz','data/models/training_report.json',
                     'data/models/self_play.npz','data/models/self_play_report.json',
                     'data/models/self_play_replay.npz','data/models/phone_lif_replay.npz']:
        source=folder/relative; destination=backup/relative
        if source.exists() and not destination.exists():
            destination.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(source,destination)
    for name in ['readout.npz','training_report.json','self_play.npz','self_play_report.json']:
        shutil.copy2(ASSETS/'data/models'/name,folder/'data/models'/name)
    cfg['brain_neurons']=1000
    save_config(folder/'config.yaml',cfg)
    return True


def worker(arguments: list[str]) -> int:
    log, action, config, *rest = arguments
    with Path(log).open("w", encoding="utf-8", buffering=1) as stream, redirect_stdout(stream), redirect_stderr(stream):
        try:
            if action == "main":
                from main import main
                return main(["--config", config, *rest])
            if action in {"phone", "preview"}:
                from phone_live import run_phone
                run_phone(Path(config), int(rest[0]) if rest else 1, action == "phone",
                          speed_percent=int(rest[1]) if len(rest)>1 else 75,
                          accuracy_percent=int(rest[2]) if len(rest)>2 else 50)
                return 0
            if action == "calibrate":
                from vision.calibration import run
                before=Path(config).read_bytes()
                run(Path(config), color=rest[0] if rest and rest[0] != "guard" else None,
                    guard=bool(rest and rest[0] == "guard"))
                if Path(config).read_bytes()!=before:
                    from phone_profile import export_profile
                    ready=export_profile(Path(config))
                    print("Profil telefonu gotowy." if ready else "Dokończ kalibrację pól, kolorów i wzorca ekranu.")
            elif action == "train":
                from training.train_readout import train
                from settings import load_config
                train(load_config(config))
            elif action == "selfplay":
                from training.train_selfplay import train
                from settings import load_config
                train(load_config(config))
            elif action == "benchmark":
                from training.evaluate import evaluate
                from settings import load_config
                evaluate(load_config(config))
            else:
                raise ValueError(f"Unknown action: {action}")
            return 0
        except Exception as exc:
            import json
            print(json.dumps(dict(event="error", message=str(exc)), ensure_ascii=False), flush=True)
            traceback.print_exc()
            return 2


class Desktop:
    def __init__(self, root: tk.Tk, folder: Path):
        self.root, self.folder = root, folder
        self.config = initialize_data(folder)
        self.process = None
        self.log_path = folder / "desktop.log"
        root.title("FlyBrain Controller")
        root.geometry("900x700")
        root.minsize(760, 620)
        style = ttk.Style(root)
        if "vista" in style.theme_names(): style.theme_use("vista")
        main = ttk.Frame(root, padding=18)
        main.pack(fill="both", expand=True)
        ttk.Label(main, text="FlyBrain Controller", font=("Segoe UI", 21, "bold")).pack(anchor="w")
        ttk.Label(main, text="Prototyp offline i integracja Android • Android").pack(anchor="w", pady=(0, 12))
        ttk.Label(main, text="Najpierw: ADB → test telefonu → kalibracja punktów i kolorów → podgląd bez sterowania.",
                  wraplength=840).pack(anchor="w")
        from settings import load_config
        cfg = load_config(self.config)
        adb = ttk.Frame(main); adb.pack(fill="x", pady=10)
        ttk.Label(adb, text="ADB:").pack(side="left")
        self.adb = tk.StringVar(value=cfg["adb_path"])
        ttk.Entry(adb, textvariable=self.adb).pack(side="left", fill="x", expand=True, padx=8)
        ttk.Button(adb, text="Wskaż adb.exe", command=self.choose_adb).pack(side="left")
        ttk.Button(adb, text="Zapisz", command=self.save_adb).pack(side="left", padx=5)
        tabs = ttk.Notebook(main); tabs.pack(fill="x", pady=6)
        offline = ttk.Frame(tabs, padding=12); phone = ttk.Frame(tabs, padding=12)
        tabs.add(offline, text="Symulacja i model"); tabs.add(phone, text="Telefon i kalibracja")
        self.agent = tk.StringVar(value="greedy")
        ttk.Label(offline, text="Agent:").grid(row=0, column=0, sticky="w")
        ttk.Combobox(offline, textvariable=self.agent, values=("random", "greedy", "search", "flybrain"),
                     state="readonly", width=14).grid(row=0, column=1, padx=8)
        ttk.Button(offline, text="Uruchom symulację", command=lambda:self.start("main", "--agent", self.agent.get())).grid(row=0,column=2,padx=6)
        ttk.Button(offline, text="Trenuj readout", command=lambda:self.start("train")).grid(row=1,column=0,pady=12)
        ttk.Button(offline, text="Benchmark 4 × 100 gier", command=lambda:self.start("benchmark")).grid(row=1,column=1,columnspan=2,padx=8)
        ttk.Label(offline, text="Sieć demonstracyjna jest syntetyczna. Model nie jest wytrenowany dla konkretnej gry.",
                  wraplength=780).grid(row=2,column=0,columnspan=3,sticky="w")
        for col,(label,action,args) in enumerate([
            ("1. Test telefonu","main",["--test-device"]),
            ("2. Punkty planszy","calibrate",[]),
            ("3. Wzorzec ekranu","calibrate",["guard"])]):
            ttk.Button(phone,text=label,command=lambda a=action,p=args:self.start(a,*p)).grid(row=0,column=col,padx=5,pady=5)
        self.color=tk.StringVar(value="red")
        ttk.Combobox(phone,textvariable=self.color,values=("red","blue","green","yellow","empty"),width=14).grid(row=1,column=0,padx=5)
        ttk.Button(phone,text="Zbierz wybrany kolor",command=lambda:self.start("calibrate",self.color.get())).grid(row=1,column=1,padx=5,pady=5)
        ttk.Button(phone,text="Sprawdź odczyt obrazu",command=lambda:self.start("main","--test-vision")).grid(row=1,column=2,padx=5)
        ttk.Button(phone,text="Podgląd decyzji (bez ruchu)",command=lambda:self.start("main","--device","android","--dry-run","--debug","--agent",self.agent.get())).grid(row=2,column=0,columnspan=2,pady=8)
        ttk.Button(phone,text="Wykonaj jeden ruch",command=lambda:self.start("main","--device","android","--execute","--max-moves","1","--agent",self.agent.get())).grid(row=2,column=2,padx=5)
        controls=ttk.Frame(main); controls.pack(fill="x",pady=10)
        ttk.Button(controls,text="Zatrzymaj",command=self.stop).pack(side="left")
        ttk.Button(controls,text="Konfiguracja",command=lambda:self.open_text(self.config)).pack(side="left",padx=8)
        ttk.Button(controls,text="Instrukcja",command=lambda:self.open_text(ASSETS/"README.md")).pack(side="left")
        ttk.Button(controls,text="Folder danych",command=lambda:os.startfile(self.folder)).pack(side="left",padx=8)
        self.status=tk.StringVar(value=f"Gotowe. Dane: {folder}")
        ttk.Label(main,textvariable=self.status,wraplength=840).pack(anchor="w",pady=6)
        self.output=tk.Text(main,font=("Consolas",10),wrap="word",height=12,state="disabled")
        self.output.pack(fill="both",expand=True)
        root.protocol("WM_DELETE_WINDOW",self.close)
        root.after(250,self.poll)

    def open_text(self,path):
        subprocess.Popen(["notepad.exe",str(path)])

    def choose_adb(self):
        path=filedialog.askopenfilename(title="Wybierz adb.exe",filetypes=[("ADB","adb.exe")])
        if path: self.adb.set(path); self.save_adb()

    def save_adb(self):
        from settings import load_config,save_config
        try:
            cfg=load_config(self.config); cfg["adb_path"]=self.adb.get().strip() or "adb"
            save_config(self.config,cfg)
        except Exception as exc: messagebox.showerror("Konfiguracja",str(exc))

    def start(self,action,*args):
        if self.process and self.process.poll() is None:
            messagebox.showinfo("Zadanie w toku","Zakończ lub zatrzymaj poprzednie zadanie."); return
        self.save_adb()
        self.log_path.write_text("",encoding="utf-8")
        command=[sys.executable]
        if not getattr(sys,"frozen",False): command.append(str(Path(__file__).resolve()))
        command += ["--worker",str(self.log_path),action,str(self.config),*args]
        self.process=subprocess.Popen(command,cwd=self.folder,creationflags=getattr(subprocess,"CREATE_NO_WINDOW",0))
        self.status.set("Trwa: "+action+" "+" ".join(args))

    def poll(self):
        if self.log_path.exists():
            text=self.log_path.read_text(encoding="utf-8",errors="replace")[-60000:]
            self.output.configure(state="normal"); self.output.delete("1.0","end")
            self.output.insert("end",text); self.output.see("end"); self.output.configure(state="disabled")
        if self.process and self.process.poll() is not None:
            code=self.process.returncode
            self.status.set("Zakończono poprawnie." if code == 0 else f"Zatrzymano / błąd ({code}). Szczegóły poniżej.")
            self.process=None
        self.root.after(500,self.poll)

    def stop(self):
        if self.process and self.process.poll() is None:
            self.process.terminate()
            self.status.set("Zatrzymano proces. Wysłany wcześniej ruch telefonu może jeszcze się zakończyć.")

    def close(self):
        self.stop(); self.root.destroy()


def entry():
    if len(sys.argv)>1 and sys.argv[1] == "--worker": return worker(sys.argv[2:])
    if len(sys.argv)>1 and sys.argv[1] == "--self-test":
        folder=Path(sys.argv[2]); folder.mkdir(parents=True,exist_ok=True)
        try:
            root=tk.Tk(); root.withdraw()
            app=Desktop(root,folder); root.update(); root.destroy()
            code=worker([str(folder/"smoke.log"),"main",str(app.config),"--agent","flybrain","--seed","10042"])
            (folder/"result.txt").write_text(f"GUI and bundled model test: {code}",encoding="utf-8")
            return code
        except Exception:
            (folder/"error.txt").write_text(traceback.format_exc(),encoding="utf-8")
            return 2
    folder=Path(os.environ.get("LOCALAPPDATA",str(Path.home())))/"FlyBrainController"/"Data"
    root=tk.Tk(); Desktop(root,folder); root.mainloop()
    return 0


if __name__ == "__main__":
    from studio import entry as studio_entry
    raise SystemExit(studio_entry())
