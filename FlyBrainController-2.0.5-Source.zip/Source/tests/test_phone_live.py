import json
from types import SimpleNamespace
import numpy as np
import pytest
from android.screenshot import save_image
from desktop import initialize_data
from phone_profile import export_profile
from phone_live import PhonePolicy, Observation, run_phone
from settings import load_config, save_config


def calibrated(tmp_path, cells=1):
    config=initialize_data(tmp_path)
    cfg=load_config(config)
    cfg.update(screen_size=[1000,800],board_cells={i:[100+(i%8)*100,100+(i//8)*100] for i in range(cells)},
               slots={0:[500,700]},neighbors={i:[] for i in range(cells)},
               screen_guards=[dict(roi=[0,0,5,5],image="guard.png",max_mae=2)],
               color_prototypes=[dict(name="empty",h=0,s=0,v=100,tolerance=dict(h=15,s=30,v=40)),
                                 dict(name="red",h=0,s=255,v=255,tolerance=dict(h=15,s=30,v=40))])
    frame=np.full((800,1000,3),100,np.uint8)
    frame[650:750,450:550]=(0,0,255)
    save_image(tmp_path/"guard.png",frame[:5,:5])
    save_config(config,cfg)
    assert export_profile(config)
    return config,frame,PhonePolicy(tmp_path)


def test_clean_calibration_creates_usable_phone_profile(tmp_path):
    _,frame,policy=calibrated(tmp_path)
    assert policy.read(frame)==Observation({0:"empty"},{0:"red"})
    assert policy.select(policy.read(frame))[:2]==(0,0)


def test_recalibration_invalidates_old_profile_until_guard_collected(tmp_path):
    config,_,_=calibrated(tmp_path)
    cfg=load_config(config); cfg["screen_guards"]=[]; save_config(config,cfg)
    assert not export_profile(config)
    with pytest.raises(ValueError,match="Brak profilu"): PhonePolicy(tmp_path)


def test_cancelled_calibration_preserves_existing_profile(tmp_path,monkeypatch):
    from desktop import worker
    import vision.calibration
    config,_,_=calibrated(tmp_path)
    original=(tmp_path/"phone_profile.json").read_bytes()
    monkeypatch.setattr(vision.calibration,"run",lambda *a,**kw:None)
    assert worker([str(tmp_path/"worker.log"),"calibrate",str(config)])==0
    assert (tmp_path/"phone_profile.json").read_bytes()==original


def test_one_animating_cell_cannot_hide_in_large_board_average(tmp_path,monkeypatch):
    import phone_live
    _,frame,policy=calibrated(tmp_path,40)
    clock=[0.]; captures=[0]
    monkeypatch.setattr(phone_live.time,"monotonic",lambda:clock[0])
    monkeypatch.setattr(phone_live.time,"sleep",lambda delay:None)
    policy.publish_preview=lambda frame:None
    def screenshot():
        clock[0]+=.1; captures[0]+=1
        image=frame.copy(); image[86:115,86:115]=100+10*(captures[0]%2)
        return image
    with pytest.raises(ValueError,match="nie ustabilizowała"):
        policy.stable(SimpleNamespace(screenshot=screenshot),timeout=1,stable_frames=3,poll_interval=0)
    assert captures[0]>=3


def test_every_animation_frame_checks_screen_guard(tmp_path):
    _,frame,policy=calibrated(tmp_path)
    invalid=frame.copy(); invalid[:5,:5]=255
    invalid[65:140,65:140]=(0,0,255)
    frames=iter([invalid]+[frame]*8)
    with pytest.raises(ValueError,match="Ekran nie pasuje"):
        policy.stable(SimpleNamespace(screenshot=lambda:next(frames)),watch_cell=0,watch_color="red",poll_interval=0)


def test_static_board_still_stabilizes(tmp_path):
    _,frame,policy=calibrated(tmp_path)
    _,obs,seen=policy.stable(SimpleNamespace(screenshot=lambda:frame.copy()),stable_frames=3,poll_interval=0)
    assert obs.board[0]=="empty" and not seen


def test_empty_tray_is_not_a_color_to_move(tmp_path):
    _,frame,policy=calibrated(tmp_path)
    frame[650:750,450:550]=100
    policy._adopt_dynamic_layout=lambda frame:False
    assert policy.read(frame).slots[0] is None


def test_dynamic_layout_preserves_manual_obstacle_restrictions(tmp_path):
    _,frame,policy=calibrated(tmp_path)
    policy.blocked_cells={0}; old=dict(policy.cells)
    policy.detect_hex_centers=lambda *args:[(100+i*100,200) for i in range(8)]
    with pytest.raises(ValueError,match="zablokowanymi"):
        policy._adopt_dynamic_layout(frame)
    assert policy.blocked_cells=={0} and policy.cells==old


def test_disconnect_after_gesture_has_durable_unconfirmed_record(tmp_path,monkeypatch):
    import phone_live
    config,frame,policy=calibrated(tmp_path)
    obs=policy.read(frame); stable_calls=[0]; swipes=[]
    def stable(*args,**kwargs):
        stable_calls[0]+=1
        if stable_calls[0]>1: raise RuntimeError("ADB disconnected after swipe")
        return frame,obs,False
    policy.stable=stable
    monkeypatch.setattr(phone_live,"PhonePolicy",lambda *args,**kw:policy)
    monkeypatch.setattr(phone_live,"AndroidController",lambda *args:SimpleNamespace(
        check_connection=lambda:True,screenshot=lambda:frame,swipe=lambda *a,**kw:swipes.append(a)))
    with pytest.raises(RuntimeError,match="disconnected"):
        run_phone(config,steps=3,execute=True)
    rows=[json.loads(line) for line in (tmp_path/"logs/phone_moves.jsonl").read_text().splitlines()]
    assert len(swipes)==1
    assert [row["status"] for row in rows]==["planned","execution_unknown"]
    assert rows[0]["run_id"]==rows[1]["run_id"]


def test_coordinate_change_cancels_gesture_even_when_colors_match(tmp_path,monkeypatch):
    import phone_live
    config,frame,policy=calibrated(tmp_path)
    cfg=load_config(config); cfg['recovery']={'enabled':False}; save_config(config,cfg)
    obs=policy.read(frame); swipes=[]
    policy.stable=lambda *a,**kw:(frame,obs,False)
    def read(frame):
        policy.cells[0]=[200,200]
        return obs
    policy.read=read
    monkeypatch.setattr(phone_live,"PhonePolicy",lambda *a,**kw:policy)
    monkeypatch.setattr(phone_live,"AndroidController",lambda *a:SimpleNamespace(
        check_connection=lambda:True,screenshot=lambda:frame,swipe=lambda *a,**kw:swipes.append(a)))
    with pytest.raises(ValueError,match="Ruch anulowany"):
        run_phone(config,execute=True)
    assert not swipes


def test_no_move_reobserves_before_stopping(tmp_path,monkeypatch):
    import phone_live
    config,frame,policy=calibrated(tmp_path)
    cfg=load_config(config); cfg['recovery']={'enabled':False}; save_config(config,cfg)
    reads=[]; obs=policy.read(frame)
    def stable(*a,**kw):
        reads.append(1)
        return frame,obs,False
    policy.stable=stable; policy.select=lambda _:None
    monkeypatch.setattr(phone_live.time,'sleep',lambda _:None)
    monkeypatch.setattr(phone_live,'PhonePolicy',lambda *a,**kw:policy)
    monkeypatch.setattr(phone_live,'AndroidController',lambda *a:SimpleNamespace(check_connection=lambda:True))
    run_phone(config,execute=False)
    assert len(reads)==3


@pytest.mark.parametrize('after_swipe',[False,True])
def test_recovery_discards_old_coordinates_and_never_replays_sent_gesture(tmp_path,monkeypatch,after_swipe):
    import phone_live
    from phone_recovery import LayoutChanged
    config,frame,policy=calibrated(tmp_path)
    obs=policy.read(frame); swipes=[]; recovered=[]
    def stable(*a,**kw):
        if kw.get('watch_cell') is not None:
            raise LayoutChanged('new level')
        return frame,obs,False
    def read(image):
        if not after_swipe and not recovered: policy.cells[0]=[200,200]
        return obs
    def restore(*a,**kw):
        recovered.append(True)
        policy.cells[0]=[300,300]
        return policy,frame,obs,False
    policy.stable=stable; policy.read=read
    monkeypatch.setattr(phone_live,'recover',restore)
    monkeypatch.setattr(phone_live,'PhonePolicy',lambda *a,**kw:policy)
    monkeypatch.setattr(phone_live,'AndroidController',lambda *a:SimpleNamespace(
        check_connection=lambda:True,screenshot=lambda:frame,swipe=lambda *a,**kw:swipes.append(a)))
    run_phone(config,steps=1,execute=True)
    assert len(swipes)==1
    assert swipes[0][2:]==((100,100) if after_swipe else (300,300))
    rows=[json.loads(line) for line in (tmp_path/'logs/phone_moves.jsonl').read_text().splitlines()]
    assert [row['status'] for row in rows]==['planned','execution_unknown']


def test_selfplay_discards_rewards_from_incompatible_rules(tmp_path,monkeypatch):
    import training.train_selfplay as module
    cfg=load_config(); cfg["_root"]=str(tmp_path)
    feature=SimpleNamespace(fingerprint="test",manifest={},features=lambda state,move:np.array([move.slot_id,move.target_cell_id],float))
    monkeypatch.setattr(module,"make_features",lambda cfg:feature)
    replay=tmp_path/"data/models/self_play_replay.npz"; replay.parent.mkdir(parents=True)
    np.savez_compressed(replay,x=np.ones((25,2)),y=np.full(25,1e12),feature_fingerprint="test")
    first=module.train(cfg,episodes=10)
    with np.load(replay) as data: assert np.max(data["y"])<1e12
    cfg["reward_weights"]["valid_move"]=2
    second=module.train(cfg,episodes=10)
    assert second["samples"]==first["samples"]
    assert second["total_episodes"]==10
