from copy import deepcopy
from unittest.mock import Mock
import numpy as np
import pytest
from android.screenshot import save_image
from agents import GreedyAgent
from game.rules import Rules
from runtime import GameLoop, wait_until_board_stable
from settings import load_config
from vision.board_detector import BoardDetector, VisionError


def setup(tmp_path):
    cfg=load_config()
    cfg.update(_root=str(tmp_path),screen_size=[60,60],board_cells={0:[20,20]},slots={3:[40,40]},
        neighbors={0:[]},board_roi=[0,0,60,60],rules_verified=True,
        animation_min_wait=0,animation_interval=0,animation_stable_frames=1,animation_timeout=.2)
    cfg["color_prototypes"]=[dict(name="red",h=0,s=255,v=255,tolerance=dict(h=10,s=30,v=30)),
        dict(name="empty",h=0,s=0,v=0,tolerance=dict(h=10,s=30,v=30))]
    reference=np.zeros((5,5,3),dtype=np.uint8)
    save_image(tmp_path/"guard.png",reference)
    cfg["screen_guards"]=[dict(roi=[0,0,5,5],image="guard.png",max_mae=5)]
    before=np.zeros((60,60,3),dtype=np.uint8); before[36:45,36:45]=(0,0,255)
    after=np.zeros_like(before); after[16:25,16:25]=(0,0,255)
    return cfg,before,after


class FakeAndroid:
    def __init__(self,before,after): self.before,self.after,self.actions=before,after,[]
    def check_connection(self): return True
    def screenshot(self): return (self.after if self.actions else self.before).copy()
    def execute(self,move,cfg): self.actions.append(move)


def test_end_to_end_vision_to_action_and_postcondition(tmp_path):
    cfg,before,after=setup(tmp_path)
    android=FakeAndroid(before,after)
    loop=GameLoop(android,BoardDetector(cfg),GreedyAgent(),Rules(),cfg)
    assert loop.run(execute=True) == 0
    assert len(android.actions) == 1 and android.actions[0].slot_id == 3
    assert '"status": "verified"' in (tmp_path/"logs/moves.jsonl").read_text()


def test_dry_run_never_touches(tmp_path):
    cfg,before,after=setup(tmp_path)
    android=FakeAndroid(before,after)
    GameLoop(android,BoardDetector(cfg),GreedyAgent(),Rules(),cfg).run()
    assert not android.actions


@pytest.mark.parametrize("problem",["unknown","orientation","overlay","unverified"])
def test_failsafe_never_touches(tmp_path,problem):
    cfg,before,after=setup(tmp_path)
    if problem == "unknown": before[36:45,36:45]=(255,0,0)
    if problem == "orientation": before=before[:50]
    if problem == "overlay": before[:5,:5]=255
    if problem == "unverified": cfg["rules_verified"]=False
    android=FakeAndroid(before,after)
    with pytest.raises((VisionError,ValueError)):
        GameLoop(android,BoardDetector(cfg),GreedyAgent(),Rules(),cfg).run(True)
    assert not android.actions
    assert list((tmp_path/"logs").glob("stop_*/diagnostic.json"))
    assert list((tmp_path/"logs").glob("stop_*/screen.png"))


def test_unexpected_transition_stops_after_one_action(tmp_path):
    cfg,before,after=setup(tmp_path)
    android=FakeAndroid(before,before)
    with pytest.raises(VisionError,match="differs"):
        GameLoop(android,BoardDetector(cfg),GreedyAgent(),Rules(),cfg).run(True)
    assert len(android.actions) == 1


def test_animation_timeout(tmp_path):
    cfg,before,after=setup(tmp_path); cfg["animation_timeout"]=.003
    android=Mock(); count=[0]
    def frame():
        count[0]+=1
        return np.full((60,60,3),255*(count[0]%2),dtype=np.uint8)
    android.screenshot=frame
    with pytest.raises(TimeoutError): wait_until_board_stable(android,cfg)


def test_static_guard_required(tmp_path):
    cfg,before,after=setup(tmp_path); cfg["screen_guards"]=[]
    with pytest.raises(VisionError): BoardDetector(cfg).read_state(before)
