from types import SimpleNamespace
import pytest
from phone_live import Observation,analyze_transition
from phone_recovery import LayoutChanged

@pytest.mark.parametrize('delayed',[True,False])
def test_rechecks_delayed_effect_without_touching_phone(monkeypatch,delayed):
    monkeypatch.setattr('phone_live.time.sleep',lambda _:None)
    before=Observation({0:'empty'},{0:'red'})
    after=Observation({0:'red'},{0:None}) if delayed else before
    captures=[]
    def stable(*a,**kw):
        captures.append(1)
        return None,after,False
    policy=SimpleNamespace(layout_signature=lambda:('same',),neighbors={},
                           slot_visual_change=lambda *a,**kw:False,stable=stable)
    result=analyze_transition(policy,object(),None,before,None,before,0,0,(0,0),False,None)
    assert result[-1].accepted==delayed
    assert len(captures)==(1 if delayed else 2)

def test_extra_analysis_rejects_geometry_drift(monkeypatch):
    monkeypatch.setattr('phone_live.time.sleep',lambda _:None)
    obs=Observation({0:'empty'},{0:'red'})
    signatures=iter(['old','new'])
    policy=SimpleNamespace(layout_signature=lambda:(next(signatures),),neighbors={},
                           slot_visual_change=lambda *a,**kw:False,
                           stable=lambda *a,**kw:(None,obs,False))
    with pytest.raises(LayoutChanged):
        analyze_transition(policy,object(),None,obs,None,obs,0,0,(0,0),False,None)
