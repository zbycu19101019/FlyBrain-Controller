import json
import random
import time
from dataclasses import asdict
from pathlib import Path
import cv2
import numpy as np
import pytest
from game.hexa_board import HexaBoard,HexaStack,HexaRules,HiddenPrior
from agents.hexa_mcts import HexaMCTS
from phone_live import Observation
from phone_intelligence import PhoneIntelligence
from flybrain.phone_value import PhoneLIFValue
from settings import load_config,save_config
from vision.digit_reader import DigitReader


def stack(color,count,unknown=False): return HexaStack((color,)*count,unknown)
def puzzle(unknown=False):
    return HexaBoard({0:stack('red',8,unknown),1:None,2:None},{0:stack('red',2,unknown)},
                     {0:(1,),1:(0,),2:()})


def test_eight_plus_two_clears_and_input_is_unchanged():
    board=puzzle(); after=board.apply((0,1))
    assert after.score==10 and after.free==3 and after.slots[0] is None
    assert board.cells[0].top_count==8 and board.slots[0].top_count==2 and board.score==0


def test_hidden_layers_cannot_be_presented_as_exact():
    board=puzzle(True)
    with pytest.raises(ValueError,match='determinization'): board.apply((0,1))
    sample=board.determinize(random.Random(1),HiddenPrior(1,2,3,('red','blue')))
    assert not sample.uncertain and len(sample.cells[0].colors)>8
    assert board.cells[0].unknown_below


def test_cascade_reveals_lower_color_and_clears_again():
    board=HexaBoard({0:stack('red',8),1:None,2:stack('blue',8)},
        {0:HexaStack(('blue',)*2+('red',)*2)},{0:(1,),1:(0,2),2:(1,)})
    after=board.apply((0,1))
    assert after.score==20 and after.free==3


def test_clear_modes_are_explicit():
    board=HexaBoard({0:stack('red',8),1:None},{0:stack('red',4)},{0:(1,),1:(0,)})
    all_run=board.apply((0,1),HexaRules(clear_mode='whole_run'))
    exact=board.apply((0,1),HexaRules(clear_mode='exact_threshold'))
    assert all_run.score==12 and all_run.free==2
    assert exact.score==10 and exact.cells[1].top_count==2


def test_blockers_and_illegal_moves():
    board=HexaBoard({0:None,1:None},{0:stack('red',2)},{0:(),1:()},frozenset({0}))
    assert board.legal_moves()==[(0,1)]
    with pytest.raises(ValueError,match='Illegal'): board.apply((0,0))


@pytest.mark.parametrize('flow',['toward_placed','toward_largest'])
def test_random_cascades_conserve_tokens(flow):
    rng=random.Random(1337)
    for _ in range(100):
        cells={i:HexaStack(tuple(rng.choice(['red','blue']) for _ in range(rng.randint(1,10)))) if i<3 else None for i in range(5)}
        board=HexaBoard(cells,{0:stack('red',2)},{i:tuple(j for j in range(5) if abs(i-j)==1) for i in range(5)})
        before=sum(len(s.colors) for s in (*board.cells.values(),*board.slots.values()) if s)
        after=board.apply((0,3),HexaRules(flow=flow))
        total=sum(len(s.colors) for s in (*after.cells.values(),*after.slots.values()) if s)
        assert before==total+after.score


def test_mcts_prefers_immediate_clear():
    result=HexaMCTS(iterations=500,budget_ms=1000,seed=7).search(puzzle())
    assert result.move==(0,1) and result.iterations==500
    assert all(-1<=s['mean_value']<=1 for s in result.statistics)


def test_mcts_time_budget_and_legality_with_hidden_states():
    board=puzzle(True); start=time.perf_counter()
    result=HexaMCTS(iterations=100000,budget_ms=20,prior=HiddenPrior(1,2,4,('red','blue'))).search(board)
    assert time.perf_counter()-start<1
    assert result.move in board.legal_moves() and result.uncertain
    assert result.iterations<100000


def test_no_legal_moves_returns_none():
    board=HexaBoard({0:stack('red',1)},{0:stack('blue',1)},{0:()})
    assert HexaMCTS().search(board).move is None


def intelligence(tmp_path,**options):
    (tmp_path/'phone_intelligence.json').write_text(json.dumps(options))
    return PhoneIntelligence(tmp_path,dict(palette=[dict(name='red')]))


def test_shadow_reports_mcts_but_preserves_existing_action(tmp_path):
    intel=intelligence(tmp_path,mode='shadow',budget_ms=100,iterations=100)
    obs=Observation({0:'red',1:'empty',2:'empty'},{0:'red'},{0:8},{0:2})
    fallback=(0,2,0)
    assert intel.choose(obs,{0:[1],1:[0],2:[]},fallback)==fallback
    assert intel.summary['search']['iterations']>0
    assert intel.summary['used']=='colors'


def test_mcts_requires_confirmation_and_ocr(tmp_path):
    obs=Observation({0:'empty',1:'red'},{0:'red'})
    intel=intelligence(tmp_path,mode='mcts',rules_verified=False)
    with pytest.raises(ValueError,match='Potwierdź'): intel.choose(obs,{0:[1],1:[0]},(0,0,1))
    intel.options['rules_verified']=True
    assert intel.choose(obs,{0:[1],1:[0]},(0,0,1))==(0,0,1)
    assert 'OCR' in intel.summary['fallback_reason']


def test_no_graph_prevents_simulator_from_inventing_neighbors(tmp_path):
    obs=Observation({0:'empty',1:'red'},{0:'red'},{1:8},{0:2})
    intel=intelligence(tmp_path)
    assert intel.choose(obs,{0:[],1:[]},(0,0,0))==(0,0,0)
    assert 'neighbor' in intel.summary['fallback_reason']


def test_confirmed_mcts_is_used_and_lif_prior_is_passed(tmp_path):
    from types import SimpleNamespace
    obs=Observation({0:'empty',1:'red',2:'empty'},{0:'red'},{1:8},{0:2})
    intel=intelligence(tmp_path,mode='mcts',rules_verified=True,iterations=300,budget_ms=1000,hidden_probability=0)
    calls=[]
    def prediction(obs,moves,neighbors):
        calls.append(moves); return {move:.9 for move in moves}
    intel.lif=SimpleNamespace(x=[1]*12,predict=prediction)
    result=intel.choose(obs,{0:[1],1:[0],2:[]},(0,2,0))
    assert result[:2]==(0,0) and calls
    assert intel.summary['used']=='mcts_lif' and intel.summary['lif_used']


def test_unknown_count_is_not_replaced_with_one():
    obs=Observation({0:'empty',1:'red'},{0:'red'},{1:8})
    with pytest.raises(ValueError,match='count missing'): HexaBoard.from_observation(obs,{0:[1],1:[0]})


def test_lif_phone_learning_uses_only_verified_outcomes_and_reloads(tmp_path):
    cfg=load_config(); cfg['_root']=str(tmp_path)
    value=PhoneLIFValue(cfg,dict(game='test'),minimum_samples=3)
    before=Observation({0:'red',1:'empty'},{0:'red'},{0:8},{0:2})
    after=Observation({0:'empty',1:'empty'},{0:None})
    graph={0:[1],1:[0]}; move=(0,1)
    first=value.features(before,move,graph).copy()
    assert not value.learn(before,after,move,graph,verified=False)
    assert not value.x and not value.path.exists()
    for _ in range(3): assert value.learn(before,after,move,graph,verified=True)
    assert value.model is not None and value.predict(before,[move],graph)[move]>0
    reloaded=PhoneLIFValue(cfg,dict(game='test'),minimum_samples=3)
    assert len(reloaded.x)==3
    np.testing.assert_allclose(first,reloaded.features(before,move,graph))
    incompatible=PhoneLIFValue(cfg,dict(game='different'),minimum_samples=3)
    assert incompatible.model is None and not incompatible.x


def test_blank_and_out_of_bounds_ocr_rejects():
    reader=DigitReader(); blank=np.full((500,500,3),100,np.uint8)
    assert reader.read(blank,(250,250)).value is None
    assert reader.read(blank,(0,0)).value is None


def test_ocr_synthetic_glyphs_without_private_screenshots():
    from PIL import Image,ImageDraw,ImageFont
    reader=DigitReader()
    font=ImageFont.truetype('arialbd.ttf',32)
    for digit in range(10):
        canvas=Image.new('L',(80,80)); ImageDraw.Draw(canvas).text((10,8),str(digit),font=font,fill=255)
        value,_=reader.classify((np.asarray(canvas)>100).astype(np.uint8)*255)
        assert value==digit
