import json
from types import SimpleNamespace
import pytest
from phone_live import Observation
from test_phone_live import calibrated
from desktop import worker


def test_consumed_tray_slot_can_shift_during_post_gesture_settling(tmp_path):
    _,frame,policy=calibrated(tmp_path)
    original_read=policy.read; reads=[]
    def read(image):
        # The detector converges to a new face center after changing stack height.
        policy.slots[0]=[500,698] if not reads else [500,696]
        reads.append(1)
        return original_read(image)
    policy.read=read
    _,obs,_=policy.stable(SimpleNamespace(screenshot=lambda:frame.copy()),
        stable_frames=3,watch_cell=0,watch_color='red',poll_interval=0)
    assert len(reads)>=4 and obs.slots[0]=='red'


def test_new_tray_detection_restarts_stability_instead_of_aborting(tmp_path):
    _,frame,policy=calibrated(tmp_path)
    original_read=policy.read; count=[0]
    def read(image):
        count[0]+=1
        if count[0]>=2: policy.slots[1]=[700,700]
        # Isolate the geometry check from the palette detector.
        return Observation({0:'empty'},{0:'red',**({1:None} if count[0]>=2 else {})})
    policy.read=read
    _,obs,_=policy.stable(SimpleNamespace(screenshot=lambda:frame.copy()),
        stable_frames=3,watch_cell=0,watch_color='red',poll_interval=0)
    assert count[0]>=4 and 1 in obs.slots


def test_actual_board_coordinate_change_still_stops_verification(tmp_path):
    _,frame,policy=calibrated(tmp_path)
    def read(image):
        policy.cells[0]=[200,200]
        return Observation({0:'red'},{0:None})
    policy.read=read
    with pytest.raises(ValueError,match='Układ zmienił'):
        policy.stable(SimpleNamespace(screenshot=lambda:frame),watch_cell=0,watch_color='red',poll_interval=0)


def test_source_visual_check_uses_pre_gesture_coordinate(tmp_path):
    _,before,policy=calibrated(tmp_path)
    after=before.copy(); after[655:746,455:546]=100
    policy.slots[0]=[700,700]
    assert not policy.slot_visual_change(before,after,0)
    assert policy.slot_visual_change(before,after,0,point=(500,700))


def test_phone_failure_emits_only_one_ui_error(tmp_path,monkeypatch):
    import phone_live
    config,frame,policy=calibrated(tmp_path)
    def fail(*args,**kw): raise ValueError('Układ zmienił się podczas weryfikacji gestu. Zatrzymano serię.')
    policy.stable=fail
    monkeypatch.setattr(phone_live,'PhonePolicy',lambda *a,**kw:policy)
    monkeypatch.setattr(phone_live,'AndroidController',lambda *a:SimpleNamespace(check_connection=lambda:True,screenshot=lambda:frame))
    log=tmp_path/'worker.log'
    assert worker([str(log),'phone',str(config)])==2
    events=[json.loads(line) for line in log.read_text(encoding='utf-8').splitlines() if line.startswith('{')]
    assert sum(event.get('event')=='error' for event in events)==1
