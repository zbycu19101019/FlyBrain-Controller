from dataclasses import replace
import json
from pathlib import Path
import numpy as np
import pytest
from scipy import sparse
from flybrain.connectome import synthetic, import_csv
from flybrain.simulator import LIFBackend
from flybrain.neurons import LIFParameters
from flybrain.encoder import PopulationEncoder
from flybrain.activity import FeatureService
from flybrain.readout import LinearReadout, MLPReadout
from game.simulator import GameSimulator
from game.rules import get_legal_moves
from training.replay_buffer import ReplayBuffer


def service(path,seed=17,dt=1):
    backend=LIFBackend(synthetic(100,seed),dt)
    encoder=PopulationEncoder(100,["red","blue","green","yellow"],seed)
    return FeatureService(backend,encoder,40,path)


def test_sparse_reproducible_network():
    network=synthetic(100)
    assert sparse.isspmatrix_csr(network.weights)
    assert network.weights.nnz <= 800
    assert network.fingerprint() == synthetic(100).fingerprint()
    assert network.fingerprint() != synthetic(100,18).fingerprint()


def test_lif_spiking_and_reset():
    backend=LIFBackend(synthetic(100))
    backend.stimulate(np.full(100,2.),40)
    first=backend.get_activity()
    assert first["rates_hz"].sum() > 0
    backend.reset(); backend.stimulate(np.full(100,2.),40)
    assert np.array_equal(first["rates_hz"],backend.get_activity()["rates_hz"])


def test_cache_and_candidate_order(tmp_path):
    state=GameSimulator().reset(3); a,b=get_legal_moves(state)[:2]
    f=service(tmp_path/"one")
    fa=f.features(state,a); fb=f.features(state,b)
    g=service(tmp_path/"two")
    assert np.array_equal(g.features(state,b),fb)
    assert np.array_equal(g.features(state,a),fa)
    assert not np.array_equal(fa,fb)
    f.backend.stimulate=lambda *args:pytest.fail("Cache should avoid resimulation")
    assert np.array_equal(f.features(state,a),fa) and f.cache_hits == 1
    assert service(tmp_path/"three",dt=.5).fingerprint != f.fingerprint


def test_import_unknown_and_direction(tmp_path):
    path=tmp_path/"edges.csv"
    path.write_text("source_neuron_id,target_neuron_id,synapse_count,sign\na,b,3,1\nb,c,2,\n")
    with pytest.raises(ValueError,match="Missing sign"): import_csv(path)
    network=import_csv(path,"omit")
    assert network.weights[1,0] == pytest.approx(.06)
    assert network.weights[0,1] == 0
    assert network.metadata["edges"][1]["sign"] == "unknown"
    assert network.metadata["edges"][0]["region"] == "unknown"


def test_readout_serialization_and_compatibility(tmp_path):
    rng=np.random.default_rng(42); x=rng.normal(size=(100,5)); y=x@np.arange(5)+2
    model=LinearReadout().fit(x,y,.001)
    assert np.mean((model.predict(x)-y)**2) < .001
    path=tmp_path/"model.npz"; model.save(path,{"feature_fingerprint":"abc"})
    loaded,_=LinearReadout.load(path,"abc")
    assert np.allclose(model.predict(x),loaded.predict(x))
    with pytest.raises(ValueError): LinearReadout.load(path,"different")


def test_mlp_learns_simple_relation():
    x=np.linspace(-1,1,80).reshape(-1,1); y=x[:,0]*2
    model=MLPReadout().fit(x,y,epochs=400,rate=.02)
    assert np.mean((model.predict(x)-y)**2) < .05


def test_replay_disk_reload(tmp_path):
    path=tmp_path/"replay.jsonl"; replay=ReplayBuffer(path,2)
    for i in range(3): replay.add(dict(state={},move={},reward=i,next_state={},done=False,neural_features=np.array([i])))
    restored=ReplayBuffer(path,2)
    assert len(restored.items) == 2 and restored.items[-1]["neural_features"] == [2]


def test_backend_rejects_bad_inputs():
    with pytest.raises(ValueError): LIFBackend(synthetic(100),100)
    backend=LIFBackend(synthetic(100))
    with pytest.raises(ValueError): backend.stimulate(np.zeros(10),40)
    with pytest.raises(ValueError): backend.stimulate(np.zeros(100),.5)
