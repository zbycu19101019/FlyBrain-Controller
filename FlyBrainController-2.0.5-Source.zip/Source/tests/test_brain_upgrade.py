from desktop import initialize_data,upgrade_brain
from settings import load_config,save_config
from factory import make_features

def test_default_network_has_1000_neurons(tmp_path):
    config=initialize_data(tmp_path)
    assert make_features(load_config(config)).backend.n==1000

def test_stock_upgrade_backs_up_config_and_phone_learning(tmp_path):
    config=initialize_data(tmp_path); cfg=load_config(config)
    cfg['brain_neurons']=100; cfg['adb_path']='my-adb.exe'; cfg.pop('self_play_model',None); save_config(config,cfg)
    phone=tmp_path/'data/models/phone_lif_replay.npz'; phone.write_bytes(b'old-phone-learning')
    assert upgrade_brain(tmp_path)
    assert load_config(config)['brain_neurons']==1000
    assert load_config(config)['adb_path']=='my-adb.exe'
    backup=tmp_path/'backups/before-1000-neurons'
    assert load_config(backup/'config.yaml')['brain_neurons']==100
    assert (backup/'data/models/phone_lif_replay.npz').read_bytes()==b'old-phone-learning'
    assert not upgrade_brain(tmp_path)

def test_custom_network_is_preserved(tmp_path):
    config=initialize_data(tmp_path); cfg=load_config(config)
    cfg['brain_neurons']=2048; save_config(config,cfg)
    assert not upgrade_brain(tmp_path)
    assert load_config(config)['brain_neurons']==2048
