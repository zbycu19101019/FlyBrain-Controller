import pytest
from settings import load_config
from training.train_readout import train
from training.evaluate import evaluate
from factory import make_agent
from game.simulator import GameSimulator
from game.rules import get_legal_moves


def test_training_reload_and_held_out_evaluation(tmp_path):
    cfg=load_config(); cfg["_root"]=str(tmp_path)
    metadata=train(cfg,episodes=5)
    assert metadata["training_samples"] > 0 and metadata["validation_samples"] > 0
    agent=make_agent("flybrain",cfg)
    state=GameSimulator().reset(10000); moves=get_legal_moves(state)
    assert agent.select_move(state,moves) in moves
    dataset=tmp_path/"data/recordings"/metadata["dataset"]
    reused=train(cfg,episodes=5,dataset=dataset)
    assert reused["simulation_seconds"] == 0
    with pytest.raises(ValueError,match="overlap"): evaluate(cfg,games=1,seed=0)
    report=evaluate(cfg,games=2,seed=10000)
    assert len(report["agents"]) == 4
    cfg["heuristic_weights"]["score"]=999
    with pytest.raises(ValueError,match="metadata"): train(cfg,episodes=5,dataset=dataset)
