from types import SimpleNamespace
import json
import numpy as np
import pytest
from phone_live import Observation
from phone_recovery import recover,find_known_control,RecoveryFailed,LayoutChanged
from transition_check import predict_visible,verify_transition
from game.hexa_board import HexaRules


def initial(): return Observation({0:'empty',1:'orange',2:'empty'},{0:'orange'},{1:8},{0:2})


def test_empty_is_not_success_by_itself():
    before=initial(); after=Observation(dict(before.board),{0:None})
    assert not verify_transition(before,after,0,0,{0:[1]},True).accepted


def test_cascade_seen_then_cleared_is_verified():
    result=verify_transition(initial(),Observation({0:'empty',1:'empty',2:'empty'},{0:None}),0,0,{0:[1]},True,True)
    assert result.accepted and result.trainable and result.kind=='cascade_observed'


def test_source_and_neighbor_clear_support_inference_not_training():
    result=verify_transition(initial(),Observation({0:'empty',1:'empty',2:'empty'},{0:None}),0,0,{0:[1]},True)
    assert result.accepted and not result.trainable and result.kind=='cascade_inferred'


def test_wrong_destination_rejects_inferred_cascade():
    result=verify_transition(initial(),Observation({0:'empty',1:'empty',2:'orange'},{0:None}),0,0,{0:[1]},True)
    assert not result.accepted


def test_unchanged_source_rejects_seen_color():
    result=verify_transition(initial(),Observation({0:'orange',1:'orange',2:'empty'},{0:'orange'}),0,0,{0:[1]},False,True)
    assert not result.accepted


def test_prediction_preserves_unknown_hidden_layers():
    result=predict_visible(initial(),(0,0),{0:[1],1:[0],2:[]},HexaRules(),True)
    assert result['cleared']==10
    assert result['board'][0] is None and result['board'][1] is None
    assert predict_visible(initial(),(0,0),{0:[1],1:[0],2:[]},HexaRules(),False) is None


def test_known_control_requires_package_and_unambiguous_enabled_button():
    xml='<hierarchy><node text="Close ad" package="game" enabled="true" clickable="true" bounds="[10,10][40,40]"/></hierarchy>'
    assert find_known_control(xml,['game'],[100,100])==(10,10,40,40)
    assert find_known_control(xml,[],[100,100]) is None
    assert find_known_control(xml,['other'],[100,100]) is None
    assert find_known_control(xml.replace('Close ad','X'),['game'],[100,100]) is None
    assert find_known_control(xml.replace('Close ad','X'),['game'],[100,100],['x'])==(10,10,40,40)
    assert find_known_control(xml.replace('enabled="true"','enabled="false"'),['game'],[100,100]) is None


class RecoveryPolicy:
    def __init__(self,fail=False): self.fail=fail
    def check_screen(self,frame):
        if self.fail: raise LayoutChanged('Overlay')
    def _adopt_dynamic_layout(self,frame): return True
    def layout_signature(self): return (((0,(5,5)),),())
    def stable(self,android): return android.screenshot(),Observation({0:'empty'},{0:'red'}),False


def test_recovery_waits_and_reacquires_without_touching(monkeypatch):
    sleeps=[]; monkeypatch.setattr('phone_recovery.time.sleep',lambda n:sleeps.append(n))
    android=SimpleNamespace(check_connection=lambda:True,screenshot=lambda:np.zeros((10,10,3),np.uint8))
    events=[]
    new,frame,obs,clicked=recover(RecoveryPolicy(),android,{},lambda *a:events.append(a))
    assert sleeps==[3] and not clicked and obs.board=={0:'empty'}
    assert events[-1][0]=='recovered'


def test_unknown_overlay_exhausts_budget_without_tap(monkeypatch):
    sleeps=[]; monkeypatch.setattr('phone_recovery.time.sleep',lambda n:sleeps.append(n))
    android=SimpleNamespace(check_connection=lambda:True,screenshot=lambda:np.zeros((10,10,3),np.uint8))
    with pytest.raises(RecoveryFailed): recover(RecoveryPolicy(True),android,{},lambda *a:None)
    assert sleeps==[3,3]


def test_setup_adb_failure_notifies_once(tmp_path,monkeypatch):
    import phone_live
    from desktop import initialize_data
    config=initialize_data(tmp_path); calls=[]
    monkeypatch.setattr(phone_live,'PhonePolicy',lambda *a,**k:object())
    def fail(): raise RuntimeError('ADB disconnected')
    monkeypatch.setattr(phone_live,'AndroidController',lambda *a:SimpleNamespace(check_connection=fail))
    monkeypatch.setattr(phone_live,'send_windows_push',lambda *a,**k:calls.append(a))
    with pytest.raises(RuntimeError): phone_live.run_phone(config,execute=True)
    assert len(calls)==1 and 'ADB disconnected' in calls[0][1]


def test_notification_delivery_failure_cannot_crash_game(monkeypatch):
    from utils import notifier
    monkeypatch.setattr(notifier.sys,'platform','win32')
    def fail(*a): raise RuntimeError('notifications disabled')
    monkeypatch.setattr(notifier,'_deliver',fail)
    thread=notifier.send_windows_push('test','failure',cooldown=0)
    thread.join(2)
    assert not thread.is_alive()
