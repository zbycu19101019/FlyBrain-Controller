import json
import subprocess
from unittest.mock import Mock, patch
import cv2
import numpy as np
import pytest
from android.adb import AndroidController, ADBError
from android.screenshot import decode_png
from vision.calibration import display_to_real, infer_neighbors
from vision.color_classifier import ColorClassifier, ColorPrototype
from vision.stack_reader import StackReader
from game.state import GameState, BoardCell, Stack
from game.rules import Rules, get_legal_moves
from game.moves import Move
from game.simulator import apply_move, GameSimulator
from agents import RandomAgent, GreedyAgent, SearchAgent


def test_adb_command_generation():
    with patch("shutil.which",return_value="adb"),patch("subprocess.run",return_value=Mock(returncode=0,stdout=b"",stderr=b"")) as run:
        AndroidController(serial="S25").swipe(1,2,3,4)
        assert run.call_args.args[0] == ["adb","-s","S25","shell","input","swipe","1","2","3","4","350"]
        assert run.call_args.kwargs["shell"] is False


def test_select_and_lock_device():
    adb = AndroidController()
    adb.devices = lambda: {"S25":"device", "other":"unauthorized"}
    assert adb.check_connection() and adb.serial == "S25"
    adb.devices = lambda: {"other":"device"}
    with pytest.raises(ADBError): adb.check_connection()


@pytest.mark.parametrize("devices",[{}, {"a":"unauthorized"}, {"a":"device","b":"device"}])
def test_ambiguous_or_unready_device(devices):
    adb=AndroidController(); adb.devices=lambda:devices
    with pytest.raises(ADBError): adb.check_connection()


def test_override_resolution():
    adb=AndroidController(); adb._run=lambda *a,**k:b"Physical size: 1440x3120\nOverride size: 1080x2340\n"
    assert adb.get_device_size() == (1080,2340)


@pytest.mark.parametrize("mode",["timeout","failure"])
def test_adb_errors(mode):
    with patch("shutil.which",return_value="adb"),patch("subprocess.run") as run:
        if mode == "timeout": run.side_effect=subprocess.TimeoutExpired("adb",1)
        else: run.return_value=Mock(returncode=1,stderr=b"disconnected")
        with pytest.raises(ADBError): AndroidController(serial="S25").screenshot()


def test_png_decode():
    image=np.zeros((10,20,3),dtype=np.uint8)
    assert np.array_equal(decode_png(cv2.imencode(".png",image)[1].tobytes()),image)
    with pytest.raises(RuntimeError): decode_png(b"bad")


def test_coordinate_scaling():
    assert display_to_real(200,400,(1440,3120),(576,1248)) == (500,1000)
    assert display_to_real(575,1247,(1440,3120),(576,1248)) == (1438,3118)


def test_neighbors():
    assert infer_neighbors({0:[0,0],1:[10,0],2:[30,0]},11) == {0:[1],1:[0],2:[]}


def palette():
    return ColorClassifier([ColorPrototype("red",0,255,255,dict(h=10,s=30,v=30)),
        ColorPrototype("empty",0,0,0,dict(h=10,s=30,v=30))])


def test_color_wraparound_red():
    assert palette().classify_hsv(np.array([179,255,255],dtype=np.uint8))[0] == "red"
    assert palette().classify_hsv([90,255,255])[0] == "unknown"


def test_unknown_stack_never_becomes_empty():
    image=np.full((30,30,3),(255,0,0),dtype=np.uint8)
    observation=StackReader(palette(),[[0,0]]).read_stack(image,15,15)
    assert not observation.valid and observation.samples == ["unknown"]


def test_empty_and_bounds():
    image=np.zeros((30,30,3),dtype=np.uint8)
    reader=StackReader(palette(),[[0,0]])
    assert reader.read_stack(image,15,15).stack is None
    assert not reader.read_stack(image,0,0).valid


def fixture_state():
    return GameState({0:BoardCell(0,Stack(["red"]*3)),1:BoardCell(1)},
                     {0:None,2:Stack(["blue","red"])})


def test_state_serialization_and_slot_ids():
    state=fixture_state()
    copy=GameState.from_dict(json.loads(state.canonical()))
    assert state == copy
    assert all(m.slot_id == 2 for m in get_legal_moves(copy))


def test_apply_move_is_pure_and_scores_clears():
    state=fixture_state(); before=state.canonical()
    result=apply_move(state,Move(2,0))
    assert state.canonical() == before and result.score == 4 and result.board[0].stack is None


@pytest.mark.parametrize("move",[Move(-1,0),Move(0,0),Move(2,99)])
def test_invalid_move(move):
    with pytest.raises(ValueError): apply_move(fixture_state(),move)


def test_color_mismatch_and_capacity():
    state=GameState({0:BoardCell(0,Stack(["blue"]))},{0:Stack(["red"])})
    assert not get_legal_moves(state)
    with pytest.raises(ValueError): apply_move(state,Move(0,0))


@pytest.mark.parametrize("agent",[RandomAgent(),GreedyAgent(),SearchAgent(2)])
def test_agents_legal_and_empty(agent):
    state=fixture_state(); moves=get_legal_moves(state)
    assert agent.select_move(state,moves) in moves
    assert agent.select_move(state,[]) is None


def test_search_is_max_at_every_level():
    agent=SearchAgent(2); state=fixture_state()
    values=[agent.value(apply_move(state,m)) for m in get_legal_moves(state)]
    assert agent.search(state,1) == max(values)


def test_simulator_reproducible():
    sim=GameSimulator()
    assert sim.reset(42) == sim.reset(42)
