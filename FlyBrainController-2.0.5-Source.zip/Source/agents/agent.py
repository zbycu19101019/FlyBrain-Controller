from typing import Protocol
from game.state import GameState
from game.moves import Move


class Agent(Protocol):
    def select_move(self, state: GameState, legal_moves: list[Move]) -> Move | None: ...
