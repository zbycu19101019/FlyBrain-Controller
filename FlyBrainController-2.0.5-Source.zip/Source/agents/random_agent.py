import random
from game.state import GameState
from game.moves import Move


class RandomAgent:
    def __init__(self, seed: int = 0): self.rng = random.Random(seed)

    def select_move(self, state: GameState, legal_moves: list[Move]) -> Move | None:
        return self.rng.choice(legal_moves) if legal_moves else None
