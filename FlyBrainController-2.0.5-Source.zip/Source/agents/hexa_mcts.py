"""Budgeted open-loop UCT with fresh hidden-state determinization per iteration."""
from dataclasses import dataclass,field
import math
import random
import time
from game.hexa_board import HiddenPrior,HexaRules


@dataclass
class Node:
    visits: int = 0
    value: float = 0.
    children: dict = field(default_factory=dict)


@dataclass
class SearchResult:
    move: tuple[int,int]|None
    iterations: int
    elapsed_ms: float
    statistics: list
    uncertain: bool


class HexaMCTS:
    def __init__(self,rules=HexaRules(),iterations=1500,budget_ms=300,horizon=8,seed=17,prior=HiddenPrior()):
        if not 1<=iterations<=100000 or not 1<=budget_ms<=10000 or not 1<=horizon<=30:
            raise ValueError("Invalid MCTS budget")
        self.rules,self.iterations,self.budget_ms,self.horizon=rules,iterations,budget_ms,horizon
        self.rng=random.Random(seed); self.prior=prior

    def search(self,board,root_priors=None):
        start=time.perf_counter(); deadline=start+self.budget_ms/1000
        root=Node(); legal_root=board.legal_moves(); root_priors=root_priors or {}
        if not legal_root: return SearchResult(None,0,0.,[],board.uncertain)
        for iteration in range(self.iterations):
            if time.perf_counter()>=deadline: break
            state=board.determinize(self.rng,self.prior)
            node=root; path=[root]; depth=0
            while depth<self.horizon:
                legal=state.legal_moves()
                if not legal: break
                unexplored=[m for m in legal if m not in node.children]
                if unexplored:
                    move=self.rng.choice(unexplored); child=Node(); node.children[move]=child
                    state=state.apply(move,self.rules); path.append(child); depth+=1
                    break
                def uct(move):
                    child=node.children[move]
                    bonus=.1*max(-1.,min(1.,root_priors.get(move,0.)))/(1+child.visits) if node is root else 0.
                    return child.value/child.visits+math.sqrt(2*math.log(max(1,node.visits))/child.visits)+bonus
                move=max(legal,key=uct); node=node.children[move]
                state=state.apply(move,self.rules); path.append(node); depth+=1
            while depth<self.horizon:
                legal=state.legal_moves()
                if not legal or time.perf_counter()>=deadline: break
                state=state.apply(self.rng.choice(legal),self.rules); depth+=1
            # Bounded value is a planning utility, never a calibrated win probability.
            trapped=bool(any(state.slots.values()) and not state.legal_moves())
            value=math.tanh(((state.score-board.score)/self.rules.clear_size+
                             .25*(state.free-board.free)-2*trapped)/3)
            for item in path: item.visits+=1; item.value+=value
        stats=[dict(slot=m[0],cell=m[1],visits=n.visits,mean_value=n.value/n.visits)
               for m,n in sorted(root.children.items()) if n.visits]
        move=max(root.children,key=lambda m:(root.children[m].visits,root.children[m].value/root.children[m].visits)) if root.children else None
        return SearchResult(move,root.visits,(time.perf_counter()-start)*1000,stats,board.uncertain)
