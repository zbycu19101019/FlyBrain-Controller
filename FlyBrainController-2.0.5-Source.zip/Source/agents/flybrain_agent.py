import numpy as np


class FlyBrainAgent:
    def __init__(self,features,readout): self.features,self.readout=features,readout

    def select_move(self,state,legal_moves):
        if not legal_moves: return None
        scores=self.readout.predict(np.array([self.features.features(state,m) for m in legal_moves]))
        if not np.all(np.isfinite(scores)): raise ValueError("Readout returned nonfinite scores")
        return legal_moves[int(np.argmax(scores))]
