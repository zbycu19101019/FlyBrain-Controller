from game.rules import get_legal_moves
from game.simulator import apply_move
from .greedy_agent import GreedyAgent


class SearchAgent(GreedyAgent):
    """Single-player maximum search. No fictitious adversarial minimizing turns."""
    def __init__(self, depth: int = 2, **kwargs):
        super().__init__(**kwargs)
        if not 1 <= depth <= 5: raise ValueError("depth must be in 1..5")
        self.depth = depth

    def search(self, state, depth):
        moves = get_legal_moves(state, self.rules)
        if not depth or not moves: return self.value(state)
        return max(self.search(apply_move(state,m,self.rules),depth-1) for m in moves)

    def select_move(self, state, legal_moves):
        return max(legal_moves, key=lambda m:self.search(apply_move(state,m,self.rules),self.depth-1)) if legal_moves else None
