from game.rules import Rules
from game.simulator import apply_move
from game.scoring import evaluate_state
from game.state import GameState
from game.moves import Move


class GreedyAgent:
    def __init__(self, rules: Rules = Rules(), weights: dict | None = None):
        self.rules, self.weights = rules, weights

    def value(self, state: GameState) -> float:
        return evaluate_state(state, self.weights, self.rules)

    def select_move(self, state: GameState, legal_moves: list[Move]) -> Move | None:
        return max(legal_moves, key=lambda m: self.value(apply_move(state,m,self.rules))) if legal_moves else None
