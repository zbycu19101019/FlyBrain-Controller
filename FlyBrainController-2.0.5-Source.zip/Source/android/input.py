"""Compatibility facade; the public controller also exposes tap/swipe directly."""
from .adb import AndroidController


class AndroidInput:
    def __init__(self, adb: AndroidController):
        self.tap = adb.tap
        self.swipe = adb.swipe
