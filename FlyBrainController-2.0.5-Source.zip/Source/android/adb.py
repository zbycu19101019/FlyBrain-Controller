"""Binary-safe ADB transport; all commands target one explicitly selected device."""
import logging
import re
import shutil
import subprocess
from pathlib import Path
import numpy as np
from .screenshot import decode_png, save_image

log = logging.getLogger(__name__)


class ADBError(RuntimeError):
    pass


class AndroidController:
    def __init__(self, adb_path: str = "adb", serial: str | None = None, timeout: float = 10):
        self.adb_path = adb_path
        self.serial = serial
        self.timeout = timeout

    def _run(self, args: list[str], device: bool = True) -> bytes:
        executable = shutil.which(self.adb_path)
        if executable is None:
            raise ADBError(f"ADB not found: {self.adb_path}. Install Android platform-tools.")
        if device and self.serial is None:
            self.check_connection()
        command = [executable] + (["-s", self.serial] if device else []) + args
        try:
            # This module is called repeatedly by the GUI preview monitor. On
            # Windows, hide each short-lived adb.exe console window.
            result = subprocess.run(
                command,
                capture_output=True,
                timeout=self.timeout,
                shell=False,
                creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
            )
        except subprocess.TimeoutExpired as exc:
            raise ADBError(f"ADB timeout ({self.timeout}s): {args}") from exc
        except OSError as exc:
            raise ADBError(f"Cannot run ADB: {exc}") from exc
        if result.returncode:
            raise ADBError(f"ADB exit {result.returncode}: {result.stderr.decode(errors='replace').strip()}")
        log.debug("ADB completed: %s", args)
        return result.stdout

    def devices(self) -> dict[str, str]:
        """Include unauthorized and offline entries for useful diagnostics."""
        lines = self._run(["devices"], device=False).decode(errors="replace").splitlines()
        return {p[0]: p[1] for line in lines if len(p := line.split()) >= 2
                and p[1] in {"device", "offline", "unauthorized", "recovery", "sideload"}}

    def check_connection(self) -> bool:
        devices = self.devices()
        if self.serial is None:
            ready = [serial for serial, state in devices.items() if state == "device"]
            if len(ready) != 1:
                raise ADBError(f"Select device_serial; expected one ready device, got {devices}")
            self.serial = ready[0]
        if devices.get(self.serial) != "device":
            raise ADBError(f"Device {self.serial}: {devices.get(self.serial, 'disconnected')}")
        return True

    def get_device_size(self) -> tuple[int, int]:
        output = self._run(["shell", "wm", "size"]).decode(errors="replace")
        sizes = re.findall(r"(?:Physical|Override) size:\s*(\d+)x(\d+)", output)
        if not sizes:
            raise ADBError(f"Cannot parse wm size: {output}")
        return tuple(map(int, sizes[-1]))

    def screenshot(self) -> np.ndarray:
        return decode_png(self._run(["exec-out", "screencap", "-p"]))

    def save_debug_screenshot(self, path: str | Path) -> Path:
        return save_image(path, self.screenshot())

    @staticmethod
    def _coordinates(*values: int) -> list[str]:
        if any(type(v) is not int or v < 0 for v in values):
            raise ValueError("Coordinates must be nonnegative integers")
        return [str(v) for v in values]

    def tap(self, x: int, y: int) -> None:
        self._run(["shell", "input", "tap", *self._coordinates(x, y)])

    def swipe(self, x1: int, y1: int, x2: int, y2: int, duration_ms: int = 350) -> None:
        if type(duration_ms) is not int or not 1 <= duration_ms <= 10000:
            raise ValueError("duration_ms must be in 1..10000")
        self._run(["shell", "input", "swipe", *self._coordinates(x1, y1, x2, y2), str(duration_ms)])

    def execute(self, move, cfg: dict) -> None:
        """Translate a validated Move to calibrated screen coordinates."""
        self.swipe(*cfg["slots"][move.slot_id], *cfg["board_cells"][move.target_cell_id])


ADBController = AndroidController
