"""OCR, local Hexa planning and optional LIF advice behind existing gesture checks."""
from dataclasses import asdict
import json
from pathlib import Path
import time
from agents.hexa_mcts import HexaMCTS
from game.hexa_board import HexaBoard,HexaRules,HiddenPrior
from vision.digit_reader import DigitReader
from settings import load_config

DEFAULTS=dict(mode='shadow',rules_verified=False,clear_size=10,flow='toward_placed',
              clear_mode='whole_run',iterations=1500,budget_ms=300,horizon=8,lif_enabled=False,
              hidden_probability=.5,hidden_groups=2,hidden_max_count=4,ocr_threshold=.76,ocr_margin=.035)


def smoke_check(folder):
    """Exercise packaged OCR, engine, search and LIF without contacting ADB."""
    import numpy as np
    from game.hexa_board import HexaStack
    from flybrain.phone_value import PhoneLIFValue
    from phone_live import Observation
    reader=DigitReader()
    digit,_=reader.classify((reader.templates[-1]*255).astype(np.uint8))
    if digit!=int(reader.labels[-1]): raise RuntimeError('Bundled digit model failed smoke test')
    board=HexaBoard({0:HexaStack(('red',)*8),1:None,2:None},{0:HexaStack(('red',)*2)},
                    {0:(1,),1:(0,),2:()})
    result=HexaMCTS(iterations=100,budget_ms=1000).search(board)
    if result.move!=(0,1) or board.apply(result.move).score!=10: raise RuntimeError('Hexa smoke test failed')
    obs=Observation({0:'red',1:'empty'},{0:'red'},{0:8},{0:2})
    value=PhoneLIFValue(load_config(Path(folder)/'config.yaml'),dict(smoke=True),minimum_samples=1)
    value.learn(obs,Observation({0:'empty',1:'empty'},{0:None}),(0,1),{0:[1],1:[0]},verified=True)
    if not value.predict(obs,[(0,1)],{0:[1],1:[0]}): raise RuntimeError('Phone LIF smoke test failed')
    return dict(ocr='ok',hexa='ok',mcts='ok',lif='ok')


def load_options(folder):
    path=Path(folder)/'phone_intelligence.json'
    options=dict(DEFAULTS)
    if path.exists(): options.update(json.loads(path.read_text(encoding='utf-8')))
    if options['mode'] not in {'colors','shadow','mcts'}: raise ValueError('Unknown phone planner mode')
    if type(options['rules_verified']) is not bool or type(options['lif_enabled']) is not bool:
        raise ValueError('Planner confirmation flags must be booleans')
    return options


class PhoneIntelligence:
    def __init__(self,folder,profile):
        self.folder=Path(folder); self.options=load_options(folder); self.summary={}; self.lif=None
        self.reader=DigitReader(threshold=float(self.options['ocr_threshold']),margin=float(self.options['ocr_margin']))
        self.rules=HexaRules(int(self.options['clear_size']),self.options['flow'],self.options['clear_mode'])
        self.profile=profile
        if self.options['lif_enabled']:
            from flybrain.phone_value import PhoneLIFValue
            cfg=load_config(self.folder/'config.yaml')
            context=dict(rules=asdict(self.rules),cells=profile['cells'],neighbors=profile['neighbors'],palette=profile['palette'])
            self.lif=PhoneLIFValue(cfg,context)

    def enrich(self,frame,obs,cells,slots):
        scale=frame.shape[1]/720.
        confidence={}
        for kind,colors,points,target in [('board',obs.board,cells,obs.board_counts),('slot',obs.slots,slots,obs.slot_counts)]:
            for ident,color in colors.items():
                if color is None or color in {'empty','blocked','locked','unknown'}: continue
                reading=self.reader.read(frame,points[ident],kind,scale,self.profile.get('ocr_'+kind+'_roi'))
                if reading.value is not None: target[ident]=reading.value
                confidence[f'{kind}:{ident}']=dict(confidence=reading.confidence,reason=reading.reason)
        obs.ocr_confidence.update(confidence)
        return obs

    def choose(self,obs,neighbors,fallback):
        self.summary=dict(mode=self.options['mode'],used='colors',lif_samples=len(self.lif.x) if self.lif else 0)
        if self.options['mode']=='colors': return fallback
        if self.options['mode']=='mcts' and not self.options['rules_verified']:
            raise ValueError('Potwierdź reguły w ustawieniach inteligencji albo użyj trybu analizy.')
        try:
            board=HexaBoard.from_observation(obs,neighbors)
        except ValueError as exc:
            self.summary['fallback_reason']=str(exc)
            return fallback
        started=time.perf_counter()
        priors=self.lif.predict(obs,board.legal_moves(),neighbors) if self.lif else {}
        planner=HexaMCTS(self.rules,int(self.options['iterations']),int(self.options['budget_ms']),
                         int(self.options['horizon']),prior=HiddenPrior(float(self.options['hidden_probability']),
                         int(self.options['hidden_groups']),int(self.options['hidden_max_count']),
                         tuple(p['name'] for p in self.profile['palette'] if p['name'] not in {'empty','obstacle','unknown'})))
        result=planner.search(board,priors)
        self.summary.update(search=asdict(result),rules=asdict(self.rules),rules_verified=self.options['rules_verified'],
                            prior='assumed_hidden_layers',lif_used=bool(priors),elapsed_ms=(time.perf_counter()-started)*1000)
        if self.options['mode']=='shadow' or result.move is None: return fallback
        sid,cid=result.move
        self.summary['used']='mcts_lif' if priors else 'mcts'
        return sid,cid,sum(obs.board.get(n)==obs.slots[sid] for n in neighbors.get(cid,()))

    def learn(self,before,after,move,neighbors,verified):
        if self.lif: self.lif.learn(before,after,move,neighbors,verified=verified)
