"""Whole-board transition evidence. Empty alone is never a successful gesture."""
from dataclasses import dataclass
from game.hexa_board import HexaBoard, HexaStack


@dataclass(frozen=True)
class Verdict:
    accepted: bool
    kind: str
    detail: str
    trainable: bool = False


def predict_visible(before, move, neighbors, rules, rules_verified=False):
    """Keep hidden layers unknown instead of sampling a fictitious expected board.

    Unique sentinels stop the hypothesis at each newly exposed unknown color.
    None means 'unknown newly exposed layer', not a predicted empty cell.
    """
    if not rules_verified: return None
    try:
        board=HexaBoard.from_observation(before,neighbors)
        def encode(stack, label):
            return HexaStack((f"__hidden_{label}",)+stack.colors) if stack else None
        exact=HexaBoard({i:encode(s,f"b{i}") for i,s in board.cells.items()},
                        {i:encode(s,f"s{i}") for i,s in board.slots.items()},board.neighbors,board.blocked)
        result=exact.apply(move,rules)
        colors={i:(before.board[i] if i in board.blocked else
                   "empty" if s is None else None if s.top.startswith("__hidden_") else s.top)
                for i,s in result.cells.items()}
        counts={i:s.top_count for i,s in result.cells.items()
                if s is not None and not s.top.startswith("__hidden_")}
        return dict(board=colors,counts=counts,cleared=result.score,hidden_layers_unknown=True)
    except (ValueError,RuntimeError):
        return None


def verify_transition(before,after,sid,cid,neighbors,source_changed,target_seen=False,expected=None):
    if before.board.keys()!=after.board.keys() or cid not in after.board:
        return Verdict(False,"layout_changed","Zmieniono identyfikatory planszy.")
    color=before.slots.get(sid)
    if not source_changed:
        return Verdict(False,"unconfirmed","Slot źródłowy nie zmienił się.")
    actual=after.board[cid]
    if actual in {"blocked","locked","unknown"}:
        return Verdict(False,"unconfirmed","Cel jest nieczytelny lub zablokowany.")
    if actual==color:
        return Verdict(True,"placement",f"Cel zachował kolor {color}; źródło się zmieniło.",True)
    if target_seen:
        return Verdict(True,"cascade_observed",f"Zaobserwowano kolor {color} na celu podczas animacji; teraz: {actual}.",True)
    if actual!="empty":
        return Verdict(False,"unconfirmed",f"Cel ma kolor {actual}, bez potwierdzenia oczekiwanego koloru {color}.")
    changed={i for i in before.board if before.board[i]!=after.board[i]}
    consumed=after.slots.get(sid)!=color
    # Disappearance of a matching neighboring run supports a merge/clear.
    cleared_neighbor=any(before.board.get(n)==color and after.board.get(n)=="empty"
                         for n in neighbors.get(cid,()))
    wrong_destination=any(before.board[i]=="empty" and after.board[i]==color for i in changed if i!=cid)
    expected_match=bool(expected and expected["cleared"]>0 and
        all(v is None or after.board.get(i)==v for i,v in expected["board"].items()) and
        all(after.board_counts.get(i)==n for i,n in expected["counts"].items()))
    if consumed and changed and not wrong_destination and (cleared_neighbor or expected_match):
        return Verdict(True,"cascade_inferred",
            "Cel pusty, źródło zużyte, a pozostała plansza potwierdza reakcję zgodną z kaskadą. "
            "Aktualizuję stan; nie traktuję tego wnioskowania jako pewnej próbki treningowej.")
    return Verdict(False,"unconfirmed","Pusty cel bez wystarczających dowodów kaskady. Gest nie będzie powtórzony.")
