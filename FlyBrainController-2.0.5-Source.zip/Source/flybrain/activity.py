import hashlib
import json
from pathlib import Path
import time
import numpy as np


def extract_features(activity: dict) -> np.ndarray:
    return np.concatenate([activity["rates_hz"].ravel()/100.,activity["final_voltage"]])


class FeatureService:
    """State-independent candidate reset makes cache reuse and action order valid."""
    def __init__(self, backend, encoder, duration_ms: float, cache: Path):
        self.backend,self.encoder,self.duration,self.cache=backend,encoder,duration_ms,Path(cache)
        self.cache.mkdir(parents=True,exist_ok=True)
        self.manifest=dict(version=1,network=backend.connectome.fingerprint(),dt=backend.dt,
            neuron_parameters=vars(backend.p),duration=duration_ms,groups=backend.groups,bins=backend.bins,
            encoder_version=encoder.version,encoder_seed=encoder.seed,colors=encoder.colors,reset_per_candidate=True)
        self.fingerprint=hashlib.sha256(json.dumps(self.manifest,sort_keys=True).encode()).hexdigest()
        self.simulation_seconds=0.
        self.cache_hits=0

    def features(self,state,move) -> np.ndarray:
        key=hashlib.sha256((self.fingerprint+state.canonical()+repr(move)).encode()).hexdigest()
        path=self.cache/f"{key}.npy"
        if path.exists():
            self.cache_hits+=1
            return np.load(path,allow_pickle=False)
        start=time.perf_counter()
        self.backend.reset()
        self.backend.stimulate(self.encoder.encode(state,move),self.duration)
        features=extract_features(self.backend.get_activity())
        self.simulation_seconds+=time.perf_counter()-start
        temp=path.with_suffix(".tmp")
        with temp.open("wb") as stream: np.save(stream,features,allow_pickle=False)
        temp.replace(path)
        return features
