from dataclasses import dataclass
import math


@dataclass(frozen=True)
class LIFParameters:
    """Dimensionless voltage/current; milliseconds for all time parameters."""
    tau_ms: float = 10
    rest: float = 0
    threshold: float = 1
    reset: float = 0
    resistance: float = 1
    refractory_ms: float = 2

    def __post_init__(self):
        if not all(math.isfinite(v) for v in vars(self).values()): raise ValueError("Nonfinite LIF parameter")
        if self.tau_ms <= 0 or self.refractory_ms < 0 or self.resistance <= 0 or not self.reset < self.threshold:
            raise ValueError("Invalid LIF parameters")
