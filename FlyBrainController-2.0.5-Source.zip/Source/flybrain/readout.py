import json
from pathlib import Path
import numpy as np


class LinearReadout:
    """Ridge regression. Targets are teacher heuristic values, not calibrated Q values."""
    def fit(self,x,y,alpha: float = 1.):
        self.mean=x.mean(axis=0); self.scale=x.std(axis=0)
        self.scale[self.scale < 1e-8]=1.
        z=np.column_stack([(x-self.mean)/self.scale,np.ones(len(x))])
        penalty=np.eye(z.shape[1])*alpha; penalty[-1,-1]=0
        self.weights=np.linalg.solve(z.T@z+penalty,z.T@y)
        return self

    def predict(self,x):
        z=(np.asarray(x)-self.mean)/self.scale
        return z@self.weights[:-1]+self.weights[-1]

    def save(self,path,metadata):
        path=Path(path); path.parent.mkdir(parents=True,exist_ok=True)
        np.savez_compressed(path,mean=self.mean,scale=self.scale,weights=self.weights,metadata=json.dumps(metadata))

    @classmethod
    def load(cls,path,expected_fingerprint=None):
        with np.load(path,allow_pickle=False) as data:
            metadata=json.loads(str(data["metadata"]))
            if expected_fingerprint and metadata["feature_fingerprint"] != expected_fingerprint:
                raise ValueError("Model/backend/encoder mismatch; retrain readout")
            obj=cls()
            for key in ("mean","scale","weights"): setattr(obj,key,data[key].copy())
        return obj,metadata


class MLPReadout:
    """Optional small NumPy tanh regressor. Linear readout is the shipped default."""
    def fit(self,x,y,hidden=24,epochs=300,rate=.005,seed=0):
        self.mean=x.mean(0); self.scale=np.maximum(x.std(0),1e-6)
        z=(x-self.mean)/self.scale
        self.ymean=y.mean(); self.yscale=max(float(y.std()),1.)
        target=(y-self.ymean)/self.yscale
        rng=np.random.default_rng(seed)
        self.w1=rng.normal(0,1/np.sqrt(z.shape[1]),(z.shape[1],hidden)); self.b1=np.zeros(hidden)
        self.w2=rng.normal(0,1/np.sqrt(hidden),hidden); self.b2=0.
        for _ in range(epochs):
            h=np.tanh(z@self.w1+self.b1)
            error=2*(h@self.w2+self.b2-target)/len(z)
            dh=error[:,None]*self.w2*(1-h*h)
            self.w2-=rate*h.T@error; self.b2-=rate*error.sum()
            self.w1-=rate*z.T@dh; self.b1-=rate*dh.sum(0)
        return self

    def predict(self,x):
        return (np.tanh((x-self.mean)/self.scale@self.w1+self.b1)@self.w2+self.b2)*self.yscale+self.ymean
