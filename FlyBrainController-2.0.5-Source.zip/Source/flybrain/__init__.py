"""Synthetic or imported sparse reservoir, not a digital organism."""
