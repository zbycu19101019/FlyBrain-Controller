from typing import Protocol
import numpy as np
from .neurons import LIFParameters
from .connectome import Connectome


class NeuralBackend(Protocol):
    def reset(self) -> None: ...
    def stimulate(self, inputs: np.ndarray, duration_ms: float) -> None: ...
    def get_activity(self) -> dict: ...


class LIFBackend:
    """Euler LIF with one-step synaptic pulses. Sparse matvec, no dense N x N matrix."""
    def __init__(self, connectome: Connectome, dt_ms: float = 1, parameters: LIFParameters = LIFParameters(),
                 groups: int = 10, bins: int = 4):
        self.connectome,self.dt,self.p=connectome,dt_ms,parameters
        self.n=connectome.weights.shape[0]
        if not 0 < dt_ms <= parameters.tau_ms/2: raise ValueError("dt must be in (0,tau/2]")
        if not 1 <= groups <= self.n or bins < 1: raise ValueError("Invalid feature groups/bins")
        self.groups,self.bins=groups,bins
        self.group_ids=np.arange(self.n)%groups
        self.group_sizes=np.bincount(self.group_ids,minlength=groups)
        self.reset()

    def reset(self) -> None:
        self.voltage=np.full(self.n,self.p.rest,dtype=float)
        self.refractory=np.zeros(self.n)
        self.spikes=np.zeros(self.n)
        self.activity=None

    def stimulate(self, inputs: np.ndarray, duration_ms: float) -> None:
        if inputs.shape != (self.n,) or not np.all(np.isfinite(inputs)): raise ValueError("Invalid stimulus")
        steps=round(duration_ms/self.dt)
        if steps < self.bins or not np.isclose(steps*self.dt,duration_ms):
            raise ValueError("Duration must be a multiple of dt, at least bins*dt")
        counts=np.zeros((self.groups,self.bins))
        bin_steps=np.zeros(self.bins)
        for step in range(steps):
            active=self.refractory <= 0
            current=inputs+self.connectome.weights@self.spikes
            self.voltage[active]+=self.dt/self.p.tau_ms * (-(self.voltage[active]-self.p.rest)+self.p.resistance*current[active])
            fired=active & (self.voltage >= self.p.threshold)
            self.refractory=np.maximum(0,self.refractory-self.dt)
            self.refractory[fired]=self.p.refractory_ms
            self.voltage[fired]=self.p.reset
            self.spikes=fired.astype(float)
            b=min(self.bins-1,step*self.bins//steps)
            counts[:,b]+=np.bincount(self.group_ids,weights=self.spikes,minlength=self.groups)
            bin_steps[b]+=1
        self.activity=dict(rates_hz=counts/self.group_sizes[:,None]/(bin_steps[None,:]*self.dt/1000),
            final_voltage=np.bincount(self.group_ids,weights=self.voltage,minlength=self.groups)/self.group_sizes)

    def get_activity(self) -> dict:
        if self.activity is None: raise RuntimeError("Stimulate before reading activity")
        return {k:v.copy() for k,v in self.activity.items()}
