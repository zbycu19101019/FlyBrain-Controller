"""LIF candidate features and a separate readout trained on verified phone outcomes.

The toy offline readout is deliberately not treated as a model of this game.
Only the reservoir architecture is shared; phone targets are observable proxies.
"""
import hashlib
import json
from pathlib import Path
import numpy as np
from factory import make_features
from flybrain.activity import extract_features
from flybrain.readout import LinearReadout


class PhoneLIFValue:
    def __init__(self,cfg,context,minimum_samples=12):
        service=make_features(cfg)
        self.backend,self.duration=service.backend,service.duration
        self.fingerprint=hashlib.sha256(json.dumps(dict(phone_encoder=1,backend=service.manifest,context=context),sort_keys=True).encode()).hexdigest()
        self.path=Path(cfg['_root'])/'data/models/phone_lif_replay.npz'
        self.minimum_samples=minimum_samples; self.x=[]; self.y=[]; self.model=None; self.cache={}
        if self.path.exists():
            try:
                with np.load(self.path,allow_pickle=False) as data:
                    if str(data['fingerprint'])==self.fingerprint:
                        self.x=list(data['x']); self.y=list(data['y'])
                self.fit()
            except (ValueError,KeyError,OSError): self.x=[]; self.y=[]; self.model=None

    def features(self,obs,move,neighbors):
        tokens=[]
        for kind,colors,counts in [('board',obs.board,obs.board_counts),('slot',obs.slots,obs.slot_counts)]:
            for ident,color in sorted(colors.items()):
                tokens.extend([f'{kind}:{ident}:{color}',f'{kind}:{ident}:count:{counts.get(ident,"unknown")}'])
        for cid,adjacent in sorted(neighbors.items()): tokens.append(f'edge:{cid}:{sorted(adjacent)}')
        tokens.extend([f'action:{move[0]}:{move[1]}']*4)
        key=tuple(tokens)
        if key in self.cache: return self.cache[key]
        current=np.full(self.backend.n,.35)
        for token in tokens:
            seed=int.from_bytes(hashlib.sha256(token.encode()).digest()[:8],'little')
            indices=np.random.default_rng(seed).choice(self.backend.n,min(self.backend.n,max(3,self.backend.n//10)),replace=False)
            current[indices]+=1.3/np.sqrt(max(1,len(tokens)/8))
        self.backend.reset(); self.backend.stimulate(current,self.duration)
        features=extract_features(self.backend.get_activity())
        if len(self.cache)>=512: self.cache.clear()
        self.cache[key]=features
        return features

    def fit(self):
        self.model=LinearReadout().fit(np.asarray(self.x),np.asarray(self.y),alpha=5.) if len(self.x)>=self.minimum_samples else None

    def predict(self,obs,moves,neighbors):
        if self.model is None: return {}
        x=np.asarray([self.features(obs,m,neighbors) for m in moves])
        if not len(x): return {}
        values=self.model.predict(x)
        if not np.all(np.isfinite(values)): return {}
        return {m:float(np.clip(v,-1,1)) for m,v in zip(moves,values)}

    @staticmethod
    def outcome_proxy(before,after):
        free_before=sum(c=='empty' for c in before.board.values())
        free_after=sum(c=='empty' for c in after.board.values())
        return float(np.tanh((free_after-free_before+1)/3.))

    def learn(self,before,after,move,neighbors,verified=False):
        if not verified: return False
        self.x.append(self.features(before,move,neighbors)); self.y.append(self.outcome_proxy(before,after))
        self.x=self.x[-2000:]; self.y=self.y[-2000:]; self.fit()
        self.path.parent.mkdir(parents=True,exist_ok=True)
        temporary=self.path.with_suffix('.tmp')
        with temporary.open('wb') as stream:
            np.savez_compressed(stream,x=np.asarray(self.x),y=np.asarray(self.y),fingerprint=self.fingerprint,
                target='visible_free_cell_delta_after_verified_phone_move_v1')
        temporary.replace(self.path)
        return True
