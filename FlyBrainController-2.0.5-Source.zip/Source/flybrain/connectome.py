from dataclasses import dataclass
import csv
import hashlib
import json
from pathlib import Path
import numpy as np
from scipy import sparse


@dataclass
class Connectome:
    weights: sparse.csr_matrix
    neuron_ids: list[str]
    metadata: dict

    def fingerprint(self) -> str:
        h=hashlib.sha256()
        for a in (self.weights.data,self.weights.indices,self.weights.indptr): h.update(a.tobytes())
        h.update(json.dumps([self.neuron_ids,self.metadata],sort_keys=True).encode())
        return h.hexdigest()


def synthetic(neurons: int = 100, seed: int = 17) -> Connectome:
    if neurons < 10: raise ValueError("Use at least 10 neurons")
    rng=np.random.default_rng(seed)
    source=np.repeat(np.arange(neurons),8)
    target=rng.integers(0,neurons,len(source))
    values=rng.uniform(.02,.09,len(source))*rng.choice([-1,1],len(source),p=[.2,.8])
    weights=sparse.csr_matrix((values,(target,source)),shape=(neurons,neurons))
    weights.sum_duplicates(); weights.sort_indices()
    return Connectome(weights,[str(i) for i in range(neurons)],
                      dict(kind="synthetic_random_NOT_fly_connectome",seed=seed,version=1))


def import_csv(path: str | Path, unknown_sign_policy: str = "error", gain: float = .02) -> Connectome:
    """CSR[target,source]. Unknown signs are rejected or explicitly omitted, never invented."""
    if unknown_sign_policy not in {"error","omit"}: raise ValueError("Policy must be error or omit")
    if not np.isfinite(gain) or gain <= 0: raise ValueError("gain must be finite and positive")
    ids, sources, targets, values = {}, [], [], []
    unknown=0
    attributes=[]
    digest=hashlib.sha256()
    with Path(path).open("rb") as binary:
        for block in iter(lambda:binary.read(1024*1024),b""): digest.update(block)
    with Path(path).open(encoding="utf-8-sig",newline="") as stream:
        reader=csv.DictReader(stream)
        required={"source_neuron_id","target_neuron_id","synapse_count"}
        if not required.issubset(reader.fieldnames or []): raise ValueError(f"Required columns: {required}")
        for row in reader:
            source,target=row["source_neuron_id"].strip(),row["target_neuron_id"].strip()
            if not source or not target: raise ValueError("Empty neuron ID")
            for ident in (source,target):
                if ident not in ids: ids[ident]=len(ids)
            count=float(row["synapse_count"])
            if not np.isfinite(count) or count <= 0 or count != int(count): raise ValueError("Invalid synapse_count")
            raw=(row.get("sign") or "unknown").strip().lower()
            sign={"+1":1,"1":1,"-1":-1}.get(raw)
            attributes.append(dict(source_neuron_id=source,target_neuron_id=target,synapse_count=int(count),
                sign=sign if sign is not None else "unknown",neurotransmitter=row.get("neurotransmitter") or "unknown",
                region=row.get("region") or "unknown"))
            if sign is None:
                unknown+=1
                if unknown_sign_policy == "error": raise ValueError("Missing sign; provide sign or explicitly choose omit policy")
                continue
            sources.append(ids[source]); targets.append(ids[target]); values.append(sign*count*gain)
    if not ids or not values: raise ValueError("No usable signed connections")
    matrix=sparse.csr_matrix((values,(targets,sources)),shape=(len(ids),len(ids)))
    matrix.sum_duplicates(); matrix.sort_indices()
    return Connectome(matrix,list(ids),dict(kind="imported",source_sha256=digest.hexdigest(),
        unknown_sign_policy=unknown_sign_policy,omitted_edges=unknown,gain=gain,edges=attributes))
