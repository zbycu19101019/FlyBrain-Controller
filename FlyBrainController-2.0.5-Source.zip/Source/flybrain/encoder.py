import hashlib
import numpy as np
from game.state import GameState
from game.moves import Move


class PopulationEncoder:
    """Stable hash-based conjunctive population code; collisions are possible and documented."""
    version=1

    def __init__(self, neurons: int, colors: list[str], seed: int = 17):
        self.neurons,self.colors,self.seed=neurons,tuple(colors),seed

    def encode(self, state: GameState, move: Move) -> np.ndarray:
        tokens=[]
        for i,cell in sorted(state.board.items()):
            if cell.blocked:
                tokens.append(f"board:{i}:obstacle")
            elif cell.stack is None:
                tokens.append(f"board:{i}:empty")
            else:
                for layer,color in enumerate(cell.stack.colors):
                    if color not in self.colors: raise ValueError(f"Encoder does not know color {color}")
                    tokens.append(f"board:{i}:layer:{layer}:color:{color}")
        for kind,stacks in (("slot",state.slots),):
            for ident,stack in sorted(stacks.items()):
                if stack is None: tokens.append(f"{kind}:{ident}:empty")
                else:
                    for layer,color in enumerate(stack.colors):
                        if color not in self.colors: raise ValueError(f"Encoder does not know color {color}")
                        tokens.append(f"{kind}:{ident}:layer:{layer}:color:{color}")
        tokens.extend([f"action:slot:{move.slot_id}"]*3+[f"action:target:{move.target_cell_id}"]*3)
        current=np.full(self.neurons,.35)
        for token in tokens:
            seed=int.from_bytes(hashlib.sha256(f"{self.seed}:{token}".encode()).digest()[:8],"little")
            indices=np.random.default_rng(seed).choice(self.neurons,max(3,self.neurons//10),replace=False)
            current[indices]+=1.3/np.sqrt(max(1,len(tokens)/8))
        return current
