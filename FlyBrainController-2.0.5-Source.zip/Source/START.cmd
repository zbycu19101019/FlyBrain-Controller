@echo off
cd /d "%~dp0"
if not exist ".venv\Scripts\pythonw.exe" (
  echo Najpierw uruchom SETUP.cmd.
  pause
  exit /b 1
)
start "FlyBrain Controller" ".venv\Scripts\pythonw.exe" desktop.py
