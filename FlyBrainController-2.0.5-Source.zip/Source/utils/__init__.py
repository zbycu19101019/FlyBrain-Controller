"""Desktop utilities."""
