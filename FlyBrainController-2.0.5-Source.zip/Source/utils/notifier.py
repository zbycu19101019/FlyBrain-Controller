"""Native Windows notifications; no network image, event loop or blocking toast dialog."""
import logging
import sys
import threading
import time

APP_ID="FlyBrain.Controller"
_threads=[]
_sent={}
_lock=threading.Lock()


def _deliver(title,body,scenario):
    from win11toast import notify
    # Avoid the library's default http: launch action and invalid 'System' scenario.
    xml='<toast scenario="{scenario}"><visual><binding template="ToastGeneric"/></visual></toast>'
    notify(title,body,app_id=APP_ID,scenario=scenario,xml=xml,
           audio="ms-winsoundevent:Notification.Default",tag="flybrain-status",group="controller")


def send_windows_push(title,body,scenario="default",enabled=True,cooldown=30):
    if not enabled or sys.platform!="win32": return None
    scenario=scenario if scenario in {"default","alarm","reminder","incomingCall"} else "default"
    key=(title,body)
    with _lock:
        now=time.monotonic()
        if now-_sent.get(key,-float("inf"))<cooldown: return None
        _sent[key]=now
    def run():
        try: _deliver(str(title),str(body)[:600],scenario)
        except Exception: logging.getLogger(__name__).exception("Nie wysłano powiadomienia Windows")
    thread=threading.Thread(target=run,name="FlyBrain-toast",daemon=True)
    with _lock:
        _threads[:]=[t for t in _threads if t.is_alive()]
        _threads.append(thread)
    thread.start()
    return thread


def flush_notifications(timeout=2):
    deadline=time.monotonic()+timeout
    for thread in list(_threads):
        thread.join(max(0,deadline-time.monotonic()))
