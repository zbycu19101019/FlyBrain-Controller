# FlyBrain Controller 2.0.1 — poprawka weryfikacji gestu

Poprawiono zatrzymanie „Układ zmienił się podczas weryfikacji gestu”, zgłoszone 5 października 2026 o 21:34:19.

- Po geście slot może zniknąć, zmienić wysokość lub zostać ponownie wykryty. Taka zmiana resetuje licznik stabilności i wymaga kolejnych zgodnych klatek, zamiast natychmiast kończyć serię.
- Współrzędne pól planszy nadal muszą być identyczne. Ich zmiana, niedopasowanie wzorca ekranu i timeout nadal zatrzymują automat. Sprawdzenie świeżości przed gestem pozostało ścisłe.
- Zmiana obrazu źródłowego slotu jest mierzona w miejscu, z którego wysłano gest, nawet gdy detektor później przesunie środek stosu.
- Jeden błąd daje jeden komunikat UI. Szczegółowy traceback pozostaje w logu technicznym.

77 testów przeszło, w tym 5 nowych testów przesunięcia slotu, dodania slotu, rzeczywistej zmiany planszy, porównania źródła gestu i pojedynczego zdarzenia błędu. Nie wykonywano ruchów na telefonie podczas przygotowania poprawki. Testy nie zastępują sprawdzenia kolejnej rozgrywki.

Zamknij wszystkie okna FlyBrain przed aktualizacją. Instalator zachowuje katalog Data i ustawienia z wersji 2.0.0. OCR, tryby MCTS oraz opcjonalny LIF działają jak w 2.0.0; domyślny MCTS pozostaje analizą shadow do potwierdzenia reguł.

---

# FlyBrain Controller 2.0.0 — Hexa Color 3D

Dodano odczyt liczby widocznych klocków, lokalny silnik Hexa, wyszukiwanie MCTS oraz opcjonalny model LIF uczony z potwierdzonych ruchów telefonu. Zachowano kontrole przed gestem, stabilizację, sprawdzanie wyniku i brak automatycznych powtórek niepotwierdzonych gestów. Pakiet 1.9.2 i dane zainstalowanej aplikacji pozostawiono bez zmian.

## Co działa

**OCR.** Lokalny czytnik cyfr korzysta z szablonów i OpenCV, bez Tesseract, pobierania modeli czy wysyłania obrazów do sieci. Liczba jest zapisywana obok koloru w obserwacji i historii. Odczyt niepewny pozostaje nieznany — nie jest zastępowany jedynką. Wartość confidence opisuje podobieństwo szablonu, nie prawdopodobieństwo poprawnego odczytu. Stabilizacja wymaga również zgodności kolejnych odczytów liczb. Rozpoznawane są dodatnie liczby 1–99; dotychczasowe realne wycinki testowe zawierają cyfry 1–6.

**HexaBoard.** Niezależny silnik w `Source/game/hexa_board.py` operuje na warstwach kolorów, grafie sąsiadów, przeszkodach i slotach. Gest przenosi cały stos na puste pole. Przenoszone są zgodne górne grupy kolorów; po czyszczeniu mogą odsłonić kolejną grupę i uruchomić kaskadę. Próg, kierunek i sposób czyszczenia są konfigurowalne. Silnik nie wykonuje ADB. Testy obejmują 8+2→10, kaskadę dwóch kolorów, resztę po odjęciu progu oraz zachowanie liczby klocków.

**MCTS.** Wyszukiwanie UCT buduje drzewo sekwencji ruchów i wykonuje losowe dokończenia. Każda iteracja losuje nowy możliwy układ ukrytych warstw; nie traktuje jednego losowania jako odczytanego faktu. Budżet domyślny: do 1500 iteracji i 300 ms, głębokość do 8. Dostępne są tylko widoczne sloty: silnik nie zgaduje przyszłego uzupełniania tacki ani progów odblokowania reklam/kłódek. Raport zawiera wizyty i średnią użyteczność, nie obietnicę procentu wygranych. Budżet ogranicza wyszukiwanie; przygotowanie cech LIF i OCR jest mierzone osobno/łącznie w raporcie decyzji, a pojedyncza kończona symulacja może nieznacznie przekroczyć limit.

**LIF.** Rzeczywisty reservoir LIF koduje stan telefonu, liczby, graf i kandydat ruchu. Osobny readout telefonu zaczyna doradzać po 12 potwierdzonych przykładach; jego ocena stanowi niewielką wskazówkę w MCTS i nie dodaje nielegalnych ruchów. Target to zmiana dostępnych pustych pól po potwierdzonym geście, nie punkty gry ani gwarantowana wygrana. Niepotwierdzone próby nie trenują readoutu. Replay jest zapisywany atomowo i sprawdza zgodność konfiguracji sieci, profilu oraz reguł. Model z laboratoryjnej gry demonstracyjnej nie jest importowany jako wiedza o Hexa Color 3D.

## Uruchomienie

1. Zamknij FlyBrain i uruchom instalator 2.0.0. Instalator zachowuje osobny katalog `Data`.
2. Otwórz Telefon. Istniejący profil zostaje zachowany; nowy profil przygotujesz przez Kalibracja. Graf `neighbors` musi być skalibrowany i symetryczny, aby MCTS mogło analizować sąsiedztwo. Przy pustym grafie pozostaje decyzja kolorystyczna z jawnym powodem w logu.
3. Otwórz **Inteligencja**. Domyślny `shadow` oblicza MCTS, pokazuje jego propozycję i zapisuje analizę, ale ruch nadal wybiera dotychczasowa polityka. `colors` pomija MCTS. `mcts` używa wyniku wyszukiwania i wymaga potwierdzenia reguł w tym samym oknie.
4. Jeśli chcesz zbierać przykłady dla reservoir, zaznacz **LIF: ucz z potwierdzonych ruchów i wspieraj MCTS**. Opcja jest domyślnie wyłączona. Po 12 potwierdzonych przykładach model może doradzać MCTS; log podaje faktyczną liczbę próbek i `lif_used`.
5. Sprawdź najpierw propozycję bez ruchu, a potem pojedynczy gest. Ustawienia obowiązują od nowej serii.

Wartości kierunku: `toward_placed` przenosi zgodne grupy w stronę pola umieszczenia według odległości w grafie, z identyfikatorem pola jako rozstrzygnięciem remisu. `toward_largest` wybiera większą zgodną górną grupę, z tym samym rozstrzygnięciem remisu. Są to jawne modele kolejności, które mogą różnić się od aplikacji gry. `whole_run` usuwa całą zgodną grupę po osiągnięciu progu, a `exact_threshold` usuwa dokładnie wartość progu i pozostawia nadwyżkę. Sąsiadujące zgodne grupy są przetwarzane w deterministycznej kolejności zapisanej w silniku.

## Co pozostaje do potwierdzenia w grze

Użytkownik podał nazwę **Hexa Color 3D**, ale nie potwierdził progu 10 ani reguł kierunku i kolejności transferów. Próg 10 jest więc ustawieniem eksperymentalnym, nie zweryfikowanym faktem o grze. Nie potwierdzono jeszcze tych reguł na nagraniu całej kaskady. Nie należy zaznaczać potwierdzenia tylko po to, by pominąć blokadę.

OCR odczytuje widoczną górną grupę. Nie rozpoznaje całego zasłoniętego stosu. Domyślne założenie ukrytych warstw (prawdopodobieństwo .5, maksymalnie 2 dodatkowe grupy po 1–4 klocki, kolory z palety) nie zostało wyuczone z gry. Wynik MCTS zależy od tych założeń. Gdy na zajętym polu lub w slocie brakuje wiarygodnej liczby, decyzja wraca do polityki kolorystycznej i zapisuje powód.

Nie zmieniano działającej instalacji ani profilu użytkownika i nie wykonano gestów na telefonie podczas przygotowania wydania. Nie przeprowadzono pełnej rozgrywki. Wzrost skuteczności gry nie został zmierzony.

## Wyniki sprawdzenia

- **72 testy przeszły**: dotychczasowe regresje oraz OCR, silnik, kaskady, blokady, MCTS, budżet czasu, ukryte warstwy, tryby shadow/mcts i uczenie/powtórne wczytanie LIF.
- OCR: **19/19 oznaczonych wycinków** z dwóch osobnych zapisanych zrzutów. Wycinki przedstawiają tę samą szatę graficzną i podobne stany; wynik nie jest miarą ogólnej skuteczności na innych rozdzielczościach, czcionkach lub animacjach.
- Pełny zapisany ekran `test3-after4.png`: **11 liczb**, około **29 ms** na odczyt kolorów i OCR; **1500 iteracji MCTS w około 276 ms**. Jednorazowy pomiar na komputerze wykonującym test.
- Kontrolny przykład ze znanymi regułami: 5000 iteracji w około 150 ms; wybrano ruch czyszczący 8+2. To mała plansza testowa, a nie benchmark całej gry.
- Szczegóły: `WERYFIKACJA.json`; obraz z odczytami: `OCR-podglad.png`.

## Pliki i konfiguracja

`Data/phone_intelligence.json` — ustawienia planowania. `Data/logs/phone_planning.jsonl` — odczyt, propozycja MCTS, budżet, użycie LIF i powód ewentualnego powrotu do kolorów. `Data/data/models/phone_lif_replay.npz` — wyłącznie przykłady z telefonu. `phone_profile.json` może dodatkowo zawierać `ocr_board_roi` i `ocr_slot_roi` jako `[dx1,dy1,dx2,dy2]` w skali referencyjnej 720 px szerokości; czytnik skaluje je do aktualnego obrazu. Sam profil pól wymaga ponownej kalibracji po zmianie rozdzielczości.

Źródła: `vision/digit_reader.py`, `game/hexa_board.py`, `agents/hexa_mcts.py`, `flybrain/phone_value.py`, `phone_intelligence.py` oraz integracja w `phone_live.py` i `studio.py`. Szablony cyfr i metadane pochodzenia znajdują się w `data/models/digits.*`. Dołączone wycinki testowe nie zawierają pełnych ekranów telefonu.


---

## Dokumentacja wcześniejszych wydań (historyczna)

# Wydanie 1.9.2 — poprawki po audycie

W Studio otwórz **Kalibracja**: zaznacz środki pól i slotów (c/s), zapisz q, zbierz empty i używane kolory, następnie zaznacz stały wzorzec ekranu. Profil telefonu powstaje automatycznie po ukończeniu tych etapów. Nowe punkty unieważniają stary profil, anulowanie okna zachowuje poprzednie dane. Najpierw sprawdź propozycję bez ruchu. Dla planowania sąsiedztwa uzupełnij graf neighbors w konfiguracji i ponownie zapisz wzorzec ekranu; domyślny pusty graf nie odtwarza topologii.

Każda klatka stabilizacji przechodzi kontrolę ekranu. Różnica jest liczona osobno dla każdego obszaru; ruch jednego pola nie znika w średniej całej planszy. Zmiana współrzędnych przed gestem lub podczas jego weryfikacji zatrzymuje serię. Ręczne blokady nie są usuwane przez automatyczną zmianę układu. Stare profile zachowują dotychczasowy offset próbkowania.

Historia zawiera wpis planned przed gestem oraz verified, missed_or_unconfirmed albo execution_unknown po próbie. Sam planned bez wyniku oznacza przerwanie procesu i wymaga sprawdzenia telefonu. Nie jest potwierdzeniem ruchu ani przykładem treningowym. Nie ma automatycznych powtórek gestu.

Replay samodzielnego treningu wymaga zgodności reguł, nagród, gamma i cech. Stary replay bez tej metadanej nie jest mieszany z nowym treningiem; plik jest zastępowany po zakończeniu nowej serii. Model offline nadal nie steruje telefonem.

Zweryfikowano 54 testy automatyczne. Nie przeprowadzono pełnej rozgrywki na fizycznym telefonie. Poniżej znajduje się wcześniejsza dokumentacja projektu; opis pięciu stabilnych klatek oznacza wartość domyślną suwaka dokładności, a liczba klatek pozostaje regulowana.

---

# FlyBrain Game Controller — działający prototyp badawczy

Projekt zawiera symulator offline, trzech agentów bazowych, mały reservoir LIF, trening readoutu, benchmark oraz integrację z telefonem Android przez ADB. Gotowy model demonstracyjny znajduje się w `data/models/readout.npz`.

**Telefon z systemem Android.** Nie wpisujemy jego rozdzielczości na sztywno. Odczytujemy `wm size` oraz rozmiar faktycznego screenshotu. Kalibrację trzeba powtórzyć po zmianie rozdzielczości, orientacji, układu gry lub skalowania.

**Zweryfikowano działanie offline i integrację z atrapą Androida. Nie wykonano testu na fizycznym telefonie:** środowisko wykonania nie zawierało ADB. Nie dostarczono screenshotów ani potwierdzonych zasad konkretnej gry. Współrzędne i paleta celowo pozostają puste.

## Architektura

```text
Android → ADB screenshot → kontrola ekranu → odczyt warstw → GameState
                                                           ↓
                                                generator legalnych ruchów
                                                           ↓
                                           Random / Greedy / Search / FlyBrain
                                                           ↓
Android ← ADB swipe ← kalibracja współrzędnych ← Move(slot, cell)
   ↓
stabilizacja obrazu → sprawdzenie rzeczywistego skutku → log JSONL

FlyBrain: (stan, kandydat) → population coding → sparse LIF
           → aktywność grup w oknach czasu → trenowany readout → ocena kandydata
```

## Instalacja na Windows

Python 3.11 lub nowszy; testy wykonano na Pythonie 3.12. W PowerShell, w katalogu projektu:

```powershell
py -3.12 -m venv .venv
.\.venv\Scripts\python -m pip install -r requirements-dev.txt
.\.venv\Scripts\python -m pytest -q
.\.venv\Scripts\python main.py --agent greedy
.\.venv\Scripts\python main.py --agent flybrain --seed 10042
```

Można użyć `python -m venv .venv`, jeśli polecenie `py -3.12` nie jest dostępne. Nie trzeba aktywować venv ani zmieniać polityki wykonywania skryptów. W kolejnych poleceniach `python` oznacza interpreter z tego venv. Na Linuxie odpowiednikiem jest `.venv/bin/python`; do narzędzia kalibracji potrzebna jest sesja graficzna.

`requirements-lock.txt` zapisuje dokładne wersje sprawdzone w tym wykonaniu. `requirements.txt` określa zakresy zależności. Nie są wymagane PyTorch, MuJoCo ani CUDA.

## Android: przygotowanie i pierwsze uruchomienie

1. Zainstaluj [Android SDK Platform-Tools](https://developer.android.com/tools/releases/platform-tools). Dodaj katalog do PATH albo wpisz pełną ścieżkę do `adb.exe` w `config.yaml` (`adb_path`).
2. Włącz opcje programistyczne i debugowanie USB, podłącz telefon kablem przesyłającym dane. Odblokuj ekran i zaakceptuj klucz RSA komputera na telefonie.
3. Uruchom `adb devices`. Stan musi być `device`; `unauthorized` wymaga akceptacji na telefonie. Przy kilku urządzeniach wpisz `device_serial` w konfiguracji.
4. Otwórz grę na planszy i utrzymuj tę samą orientację podczas kalibracji i działania.

```powershell
python main.py --test-device
python main.py --test-device --no-preview
python -m vision.calibration
```

Test urządzenia zapisuje PNG w `data/screenshots/` oraz pokazuje podgląd, chyba że podano `--no-preview`. Pobieranie obrazu stosuje binarne `adb exec-out screencap -p`, zgodnie z [dokumentacją ADB](https://developer.android.com/tools/adb). Każda komenda sprawdza kod wyjścia i timeout. Po wybraniu telefonu komendy są kierowane przez `-s SERIAL`.

## Kalibracja

W oknie: **c** — środki pól planszy, **s** — środki dolnych slotów, **u** — cofnij ostatni punkt aktywnej grupy, **q** — zapisz, **Esc** — anuluj. Zaznacz wszystkie pola i sloty, także puste. Nowa kalibracja zastępuje poprzednie punkty, zeruje screen guards i wymaga ponownego potwierdzenia zasad. Nie pozostawia starych identyfikatorów.

Współrzędne są przeliczane według faktycznych wymiarów obrazu po zmianie skali, z uwzględnieniem zaokrągleń. Można kalibrować zapisany obraz bez telefonu:

```powershell
python -m vision.calibration --image data/screenshots/twoj_obraz.png
python -m vision.calibration --neighbor-distance 150
```

`--neighbor-distance` podaj dopiero po zmierzeniu odległości pomiędzy sąsiednimi polami w rzeczywistych pikselach. Wygenerowany graf jest propozycją; sprawdź go. Można również ręcznie edytować symetryczny graf `neighbors` w YAML. Domyślnie graf ma puste listy sąsiadów.

Test jednego swipe, niezależny od CV:

```powershell
python main.py --test-swipe 0 0
python main.py --test-swipe 0 0 --execute
```

Pierwsze polecenie tylko wypisuje punkty. Drugie wykonuje jeden ruch z dolnego slotu 0 do pola 0. Użyj identyfikatorów z własnej kalibracji i otwartej planszy.

### Paleta i warstwy

Zbierz każdy rzeczywisty kolor, klikając jednolity fragment klocka. Kliknięcie wybiera wzorzec; **q** zapisuje. Obowiązkowo zbierz również wzorzec pustego pola pod nazwą `empty`:

```powershell
python -m vision.calibration --color red
python -m vision.calibration --color blue
python -m vision.calibration --color green
python -m vision.calibration --color yellow
python -m vision.calibration --color empty
```

Edytuj tolerancje HSV po sprawdzeniu zapisanych obrazów. `confidence` jest wskaźnikiem dopasowania, nie skalibrowanym prawdopodobieństwem poprawności.

`sample_offsets` definiuje widoczne warstwy **od dołu do góry**, względem zaznaczonego punktu. Domyślne `[[0, 0]]` odczytuje jedną warstwę. Przykładowe `[[0, 0], [0, -12], [0, -24]]` jest poprawne wyłącznie wtedy, gdy taki rozstaw rzeczywiście odpowiada warstwom konkretnej gry. Nie kopiuj go bez pomiaru. Promień każdego próbkowanego wycinka to `patch_radius`.

Próbkowanie nie odtwarza zasłoniętych elementów i nie wyznacza niezawodnie liczby klocków z dowolnego renderingu 3D. Jeżeli gra nie pokazuje wszystkich potrzebnych warstw albo tło pustego slotu różni się od pustego pola, trzeba dostosować `StackReader` i klasyfikację do zebranych screenshotów. `unknown` pozostaje błędem obserwacji; nie jest usuwane jak tło.

```powershell
python main.py --test-vision
```

To polecenie tylko odczytuje ekran i wypisuje stan. Sprawdź kolory, kolejność warstw i identyfikatory na kilku rzeczywistych obrazach.

### Identyfikacja ekranu i stabilizacja

Zaznacz stabilny element interfejsu, który identyfikuje planszę, np. jej niezmienny narożnik. Możesz dodać kilka obszarów:

```powershell
python -m vision.calibration --guard
```

`screen_guards` zapisują wzorce i tolerancję różnicy obrazu. Zmienny licznik punktów, numer poziomu lub animowany element nie nadaje się na wzorzec; wybieraj wyłącznie stały fragment ekranu gry. Niepewny kolor pola jest traktowany jako pole zajęte/niedostępne, nigdy jako wolne miejsce. Ustaw `board_roi: [x1, y1, x2, y2]`, obejmując planszę i sloty, ale pomijając stale animowane elementy. Po kalibracji domyślnie jest to cały ekran.

## Przeszkody i samouczenie

Offline'owy stan planszy obsługuje osobne pola zablokowane (`blocked`). W podglądzie telefonu niepewne pola oraz kolor-prototyp `obstacle` są wyłączone z celów ruchu. W konfiguracji symulatora zablokowane identyfikatory można podać w `blocked_cells`; przy ręcznej kalibracji koloru użyj nazwy `obstacle`.

Przycisk „Ucz samodzielnie z przeszkodami” domyślnie rozgrywa 120 epizodów epsilon-greedy Monte Carlo na zróżnicowanych planszach: ścieżce, pierścieniu, rozgałęzieniu i układzie heksagonalnym, o rozmiarze 7–19 pól. Liczba przeszkód, slotów tacki i długość stosów zmienia się między partiami. Przykłady z kolejnych treningów są zachowywane w replay bufferze, a raport sumuje liczbę gier. To nadal uproszczone środowisko demonstracyjne, nie odtworzenie nieznanych reguł gry z telefonu. Wyuczony model zapisuje się osobno w `data/models/self_play.npz` i można wybrać agenta `selfplay` w laboratorium. Rzeczywista gra wymaga osobnego profilu i zweryfikowanych reguł.

Kontrola wzorca nie gwarantuje wykrycia każdej nakładki: okno może ominąć wszystkie wybrane obszary i miejsca próbkowania. Dobierz kilka wzorców i sprawdź negatywne przykłady. Nie ma automatycznego klikania reklam ani nieznanych okien.

Stabilność wymaga pięciu kolejnych klatek poniżej progu różnicy w rozszerzonych obszarach wokół środków pól (29×29 px) i slotów. Timeout zatrzymuje pętlę; nie ma ślepego czekania `sleep(3)` jako jedynego mechanizmu. Sterowanie telefonem potwierdza zmianę konkretnego slotu źródłowego oraz oczekiwany kolor pola docelowego. Oczekiwany kolor jest śledzony również w kolejnych klatkach animacji, aby odnotować późniejsze usunięcie/zmianę przy kaskadzie. Jeśli oczekiwanego koloru nie zaobserwowano, seria zatrzymuje się bez ponawiania gestu. Podgląd analizuje zrzuty w tle i korzysta ze zrzutów zadania telefonu podczas sterowania, bez konkurencyjnego odpytywania ADB. Karta treningu pokazuje osobno liczbę obserwacji ruchów z telefonu; te dane nie trenują automatycznie agenta offline.

## Zasady symulatora: jawnie uproszczone

Domyślny adapter `single_token_match` przenosi **jeden górny element** ze slotu na puste pole lub stos z takim samym górnym kolorem. Pojemność wynosi 4. Jednokolorowy stos o rozmiarze 4 znika, a wynik wzrasta o liczbę usuniętych elementów. Zapas dolnych slotów jest skończony; sukces oznacza zużycie całego zapasu. Brak legalnego ruchu przed jego zużyciem oznacza porażkę.

Alternatywa `whole_stack_empty` przenosi cały stos na puste pole. Żaden z tych adapterów nie implementuje automatycznych kaskad i wszystkich zasad Hexa Sort/Hexa Master 3D. Graf sąsiedztwa służy obecnie heurystyce, a nie kaskadom. Nowy adapter wymaga zgodnych zmian w `game/rules.py`, `game/simulator.py` i testach.

**Zanim włączysz sterowanie grą, sprawdź, co naprawdę przenosi swipe oraz jak następuje łączenie, usuwanie i uzupełnianie stosów.** Jeśli ruchy nie odpowiadają adapterowi, dostosuj go na podstawie obserwacji. `rules_verified: true` jest deklaracją użytkownika, nie wynikiem automatycznej weryfikacji. Nie ustawiaj tego tylko po to, żeby ominąć komunikat.

Agenci nigdy nie zwracają współrzędnych; wybierają `Move` z legalnej listy. Search maksymalizuje ocenę na każdym poziomie, ponieważ nie ma przeciwnika. Brak ruchów zwraca `None`.

## Integracja Android

```powershell
python main.py --device android --agent greedy --dry-run --debug
python main.py --device android --agent greedy --execute --max-moves 1
python main.py --device android --agent flybrain --execute --max-moves 20
```

Bez `--execute` program nie steruje telefonem. Domyślnym urządzeniem CLI jest symulator; dla telefonu trzeba podać `--device android`. Najpierw wykonaj dry-run, sprawdź `logs/latest_debug.png`, potem pojedynczy ruch. Readout z paczki wytrenowano na małej planszy syntetycznej — dla rzeczywistej gry potrzebny będzie nowy dataset i trening.

Przed komendą pętla ponownie odczytuje planszę. Po komendzie porównuje obserwowany stan z przewidywaniem symulatora. Zmiana rozdzielczości, niedopasowanie wzorca, niski confidence, brak rozpoznanego slotu, utrata ADB lub różnica przejścia zatrzymują pętlę. Diagnostyka trafia do `logs/stop_*/`, wraz z dostępnym screenshotem. Nie ma automatycznych powtórek nieudanego swipe. Ctrl+C kończy działanie.

W wersji desktopowej polityka telefonu (`phone_live.PhonePolicy`) planuje kolejność do trzech widocznych slotów, przeglądając kilka sekwencji bezpiecznych umieszczeń. Ocenia dopasowania sąsiednich kolorów, dostępne puste pole oraz zapisane, potwierdzone wyniki wcześniejszych ruchów. Plan używa wyłącznie rozpoznanych kolorów i pól. Nie odczytuje jeszcze cyfr ani postępu punktowego klatek i nie symuluje niezweryfikowanych kaskad; jeśli nie ma pewnego pustego celu, zatrzymuje sterowanie.

Stabilizator pobiera limit czasu i próg różnicy z konfiguracji, a budżet czasu wydłuża proporcjonalnie do zmierzonego czasu zrzutu ADB (maksymalnie do 30 s). Komunikat zatrzymania podaje liczbę uzyskanych stabilnych klatek i ostatnią różnicę obrazu.

Ruchy są zapisywane w `logs/moves.jsonl`. Wynik punktowy z telefonu nie jest odczytywany, więc rzeczywista nagroda pozostaje `null`, zamiast być zgadywana.

## Nagrywanie demonstracji

```powershell
python main.py --record --max-moves 10
```

Program zapisuje stan przed ruchem, pyta o `slot_id target_cell_id`, czeka na ręczne wykonanie ruchu na telefonie i Enter, następnie zapisuje stan po ruchu oraz oba obrazy. To ręczna anotacja, a nie automatyczne śledzenie dotknięć. Dane znajdują się w `data/recordings/`. Ten tryb nie wysyła dotknięć do telefonu.

## Reservoir, trening i konektom

Pierwszy backend to **syntetyczna sieć 1000 neuronów**, ze stałym seedem i rzadką macierzą. Nie jest to prawdziwy konektom muchy. LIF używa umownych jednostek napięcia i prądu, milisekund czasu, okresu refrakcji i impulsów synaptycznych opóźnionych o jeden krok. Parametry są uproszczeniem, nie dopasowaniem biologicznym.

Koder tworzy deterministyczne populacje dla kombinacji pozycja–warstwa–kolor oraz dla kandydata ruchu. Haszowane populacje mogą się częściowo pokrywać. Każdy kandydat zaczyna od identycznego stanu reservoir; dzięki temu kolejność oceniania ruchów nie wpływa na wynik. Wyjście obejmuje częstości wyładowań grup w przedziałach czasu oraz średnie końcowe napięcia.

```powershell
python -m training.train_readout --episodes 80 --seed 0
python -m training.evaluate --games 100 --seed 10000
```

Trening to **supervised imitation** jednego kroku heurystyki, nie reinforcement learning. Uczy się wyłącznie liniowy readout. Podział train/validation odbywa się po całych epizodach; regularizacja ridge jest dobierana na validation. Benchmark ma rozłączne seedy i odrzuca ich nakładanie. Wynik nie gwarantuje przewagi nad baseline.

Replay JSONL zapisuje stan, ruch, nagrodę, następny stan, done, cechy neuronalne i cel nauczyciela. `data/cache/` przechowuje cechy par stan–ruch. Klucz uwzględnia również sieć, parametry LIF, seed i wersję kodera, czas symulacji oraz definicję cech. Ponowne dopasowanie na zapisanym zbiorze nie wymaga symulowania sieci:

```powershell
python -m training.train_readout --dataset data/recordings/NAZWA_ZBIORU.jsonl
```

Opcjonalny `MLPReadout` udostępnia API NumPy `fit/predict` i test uczenia; domyślne CLI, zapis modelu i benchmark używają `LinearReadout`.

Importer CSV oczekuje kolumn `source_neuron_id,target_neuron_id,synapse_count` oraz opcjonalnych `sign,neurotransmitter,region`. Identyfikatory są tekstowe, co zapobiega utracie precyzji dużych ID. `sign` ma wartość `1` albo `-1`. Braki są oznaczane jako `unknown`. Domyślna polityka odrzuca brak znaku; jawne `unknown_sign_policy: omit` pomija takie połączenia w dynamice i rejestruje tę decyzję. Nie wyprowadza znaku synapsy automatycznie z nazwy neuroprzekaźnika.

`data/connectome/example.csv` to mały **fikcyjny** przykład formatu, nie dane biologiczne. Dla własnych danych ustaw:

```yaml
brain_backend: connectome
connectome_csv: data/connectome/twoje_polaczenia.csv
unknown_sign_policy: error
```

Po zmianie backendu lub kodera ponownie trenuj readout. Sieć jest przechowywana jako CSR `[target, source]`; nie powstaje macierz NxN. Większe backendy testuj kolejno: 100, 1000, 10000 neuronów. Koszt przejścia zależy od liczby krawędzi, czasu symulacji i liczby kandydatów; nie deklarujemy wydajności pełnego konektomu.

Ten projekt nie jest cyfrową kopią świadomości ani zachowania muchy. Sama topologia nie ustala pełnej dynamiki, receptorów ani neuromodulacji. Interpretację ograniczeń wspiera praca [The fly connectome reveals a path to the effectome](https://pmc.ncbi.nlm.nih.gov/articles/PMC11446844/). Po imporcie odpowiednich danych można mówić o systemie wykorzystującym topologię konektomu jako reservoir; nie o biologicznej muszce, która nauczyła się grać.

## Testy i problemy

```powershell
python -m pytest -q
python -m compileall -q android vision game agents flybrain training main.py
```

- `ADB not found`: popraw PATH lub `adb_path`.
- `unauthorized`: zaakceptuj klucz RSA na telefonie; odłącz i podłącz kabel, jeżeli monit nie jest widoczny.
- Kilka urządzeń: ustaw konkretny `device_serial`.
- Pusta konfiguracja: uruchom kalibrację punktów i palety.
- `unknown` lub niski confidence: sprawdź ROI, faktyczne kolory i rozstaw widocznych warstw.
- Timeout stabilności: usuń stale animowane elementy z `board_roi`, nie zwiększaj progów bez obejrzenia klatek.
- Zmieniona orientacja/rozdzielczość: ponów kalibrację i wzorce ekranowe.
- `Actual transition differs`: sprawdź zasady i odczyt stosów, nie uruchamiaj pętli z niezweryfikowanym adapterem.
- Model niezgodny z backendem: odtwórz trening dla obecnej konfiguracji.
- Brak okna OpenCV: użyj środowiska graficznego i pakietu `opencv-python`, nie wariantu headless.

Pełna analiza poprawek i stan etapów: `ANALIZA_I_POPRAWKI.md`. Rzeczywiste wyniki weryfikacji: `WYNIKI.md`.
