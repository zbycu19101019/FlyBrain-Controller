"""Offline demo is the default. Physical phone actions require --execute."""
import argparse
from datetime import datetime
import json
import logging
from pathlib import Path
import cv2
from android.adb import AndroidController
from android.screenshot import save_image
from factory import make_agent
from game.rules import Rules, get_legal_moves, outcome
from game.simulator import GameSimulator
from game.moves import Move
from runtime import GameLoop
from settings import ROOT, load_config, resolve
from vision.board_detector import BoardDetector


def main(argv=None):
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config",type=Path,default=ROOT/"config.yaml")
    parser.add_argument("--agent",choices=["random","greedy","search","flybrain","selfplay"])
    parser.add_argument("--device",choices=["simulator","android"],default="simulator")
    actions=parser.add_mutually_exclusive_group()
    actions.add_argument("--test-device",action="store_true")
    actions.add_argument("--test-swipe",nargs=2,type=int,metavar=("SLOT","CELL"))
    actions.add_argument("--calibrate",action="store_true")
    actions.add_argument("--test-vision",action="store_true")
    actions.add_argument("--record",action="store_true")
    modes=parser.add_mutually_exclusive_group()
    modes.add_argument("--execute",action="store_true")
    modes.add_argument("--dry-run",action="store_true")
    parser.add_argument("--debug",action="store_true")
    parser.add_argument("--no-preview",action="store_true")
    parser.add_argument("--max-moves",type=int,default=20)
    parser.add_argument("--seed",type=int,default=42)
    args=parser.parse_args(argv)
    cfg=load_config(args.config)
    logging.basicConfig(level=cfg["log_level"],format="%(levelname)s: %(message)s")
    if args.max_moves < 1: parser.error("--max-moves must be positive")
    try:
        if args.calibrate:
            from vision.calibration import run
            run(args.config); return 0
        android=AndroidController(cfg["adb_path"],cfg.get("device_serial"),cfg["adb_timeout"])
        if args.test_device:
            android.check_connection()
            image=android.screenshot()
            print(f"Device: {android.serial}; wm size: {android.get_device_size()}; screenshot: {image.shape[1]}x{image.shape[0]}")
            path=save_image(resolve(cfg,"data/screenshots")/f"device_{datetime.now():%Y%m%d_%H%M%S}.png",image)
            print(path)
            if not args.no_preview:
                cv2.imshow("Device screenshot",cv2.resize(image,None,fx=cfg["preview_scale"],fy=cfg["preview_scale"]))
                cv2.waitKey(0); cv2.destroyAllWindows()
            return 0
        if args.test_swipe:
            move=Move(*args.test_swipe)
            if move.slot_id not in cfg["slots"] or move.target_cell_id not in cfg["board_cells"]:
                raise ValueError("Select calibrated slot and cell IDs")
            print(f"Test swipe: {cfg['slots'][move.slot_id]} -> {cfg['board_cells'][move.target_cell_id]}")
            if args.execute:
                android.check_connection()
                image=android.screenshot()
                if list(image.shape[1::-1]) != cfg["screen_size"]: raise ValueError("Recalibrate changed resolution")
                android.execute(move,cfg)
            else: print("Dry-run; add --execute to perform this one test swipe")
            return 0
        rules=Rules(**cfg["rules"])
        agent_name=args.agent or cfg["agent"]
        agent=make_agent(agent_name,cfg,args.seed)
        if args.device == "android" or args.test_vision or args.record:
            vision=BoardDetector(cfg)
            if args.test_vision:
                state=vision.read_state(android.screenshot(),require_guard=False)
                print(json.dumps(state.to_dict(),indent=2))
                return 0 if state.confident else 2
            loop=GameLoop(android,vision,agent,rules,cfg)
            if args.record: loop.record(args.max_moves); return 0
            return loop.run(args.execute,args.max_moves,args.debug)
        sim=GameSimulator(rules,cfg["reward_weights"],
            board_size=7 if agent_name=="selfplay" else 3,
            obstacle_count=2 if agent_name=="selfplay" else 0)
        state=sim.reset(args.seed)
        for step in range(args.max_moves):
            moves=get_legal_moves(state,rules)
            if not moves: break
            move=agent.select_move(state,moves)
            state,reward,done=sim.step(move)
            print(f"step={step+1} move={move} reward={reward} score={state.score}")
            if done: break
        print(f"Outcome: {outcome(state,rules) or 'move_limit'}")
        return 0
    except (OSError,RuntimeError,ValueError,KeyError) as exc:
        logging.error("STOP: %s",exc)
        return 2
    except KeyboardInterrupt:
        logging.warning("Stopped by user")
        return 130


if __name__ == "__main__": raise SystemExit(main())
