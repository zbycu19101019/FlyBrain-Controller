"""Local, explicit Hexa rule adapter. Hidden layers must be sampled before simulation.

This is a configurable hypothesis, not a claim that every Hexa game uses these rules.
The entire tray stack is placed on an empty cell. Equal top runs transfer along
edges. Direction, processing order and clearing semantics are part of the rules.
"""
from dataclasses import dataclass, field
import random


@dataclass(frozen=True)
class HexaRules:
    clear_size: int = 10
    flow: str = "toward_placed"
    clear_mode: str = "whole_run"

    def __post_init__(self):
        if type(self.clear_size) is not int or not 2<=self.clear_size<=99:
            raise ValueError("clear_size must be an integer in 2..99")
        if self.flow not in {"toward_placed","toward_largest"}:
            raise ValueError("Unknown transfer direction")
        if self.clear_mode not in {"whole_run","exact_threshold"}:
            raise ValueError("Unknown clear mode")


@dataclass(frozen=True)
class HexaStack:
    colors: tuple[str,...]
    unknown_below: bool = False

    def __post_init__(self):
        if not self.colors or any(not isinstance(c,str) or not c for c in self.colors):
            raise ValueError("A stack requires known nonempty color names")

    @property
    def top(self): return self.colors[-1]

    @property
    def top_count(self):
        return next((i for i,c in enumerate(reversed(self.colors)) if c!=self.top),len(self.colors))


@dataclass(frozen=True)
class HiddenPrior:
    """Uninformed scenario prior; these probabilities are assumptions, not measured."""
    hidden_probability: float = .5
    max_groups: int = 2
    max_count: int = 4
    palette: tuple[str,...] = ()

    def __post_init__(self):
        if not 0<=self.hidden_probability<=1 or not 0<=self.max_groups<=4 or not 1<=self.max_count<=10:
            raise ValueError("Invalid hidden-layer prior")

    def sample(self,stack,palette,rng):
        if stack is None or not stack.unknown_below: return stack
        colors=list(stack.colors)
        for _ in range(self.max_groups):
            if rng.random()>=self.hidden_probability: break
            alternatives=[c for c in palette if c!=colors[0]]
            if not alternatives: break
            colors=[rng.choice(alternatives)]*rng.randint(1,self.max_count)+colors
        return HexaStack(tuple(colors))


@dataclass
class HexaBoard:
    cells: dict[int,HexaStack|None]
    slots: dict[int,HexaStack|None]
    neighbors: dict[int,tuple[int,...]]
    blocked: frozenset[int] = field(default_factory=frozenset)
    score: int = 0

    def __post_init__(self):
        if not self.blocked<=self.cells.keys(): raise ValueError("Unknown blocked cell")
        for cid in self.cells:
            adjacent=self.neighbors.get(cid,())
            if len(set(adjacent))!=len(adjacent): raise ValueError("Duplicate neighbor")
            for other in adjacent:
                if other==cid or other not in self.cells or cid not in self.neighbors.get(other,()):
                    raise ValueError("Neighbors must be symmetric and refer to board cells")
        if any(self.cells[c] is not None for c in self.blocked): raise ValueError("Blocked cell holds a stack")

    @property
    def free(self): return sum(s is None and c not in self.blocked for c,s in self.cells.items())

    @property
    def uncertain(self):
        return any(s and s.unknown_below for s in (*self.cells.values(),*self.slots.values()))

    def legal_moves(self):
        return [(sid,cid) for sid,s in sorted(self.slots.items()) if s is not None
                for cid,t in sorted(self.cells.items()) if t is None and cid not in self.blocked]

    def determinize(self,rng,prior=HiddenPrior()):
        palette=list(prior.palette) or sorted({c for s in (*self.cells.values(),*self.slots.values()) if s for c in s.colors})
        return HexaBoard({i:prior.sample(s,palette,rng) for i,s in self.cells.items()},
                         {i:prior.sample(s,palette,rng) for i,s in self.slots.items()},self.neighbors,self.blocked,self.score)

    def apply(self,move,rules=HexaRules()):
        if self.uncertain: raise ValueError("Hidden layers require determinization; exact state is unknown")
        if move not in self.legal_moves(): raise ValueError("Illegal Hexa move")
        sid,placed=move
        cells={i:list(s.colors) if s else [] for i,s in self.cells.items()}
        cells[placed]=list(self.slots[sid].colors)
        slots=dict(self.slots); slots[sid]=None
        score=self.score
        # Strict destination order prevents cyclic back-and-forth transfers.
        distance={placed:0}; queue=[placed]
        for cid in queue:
            for n in sorted(self.neighbors.get(cid,())):
                if n not in distance: distance[n]=distance[cid]+1; queue.append(n)
        priority=lambda cid:(distance.get(cid,len(cells)+1),cid)
        order=sorted(cells,key=priority)
        def run(cid):
            colors=cells[cid]
            return next((i for i,c in enumerate(reversed(colors)) if c!=colors[-1]),len(colors)) if colors else 0
        # Each transfer removes one top color run; clearing removes tokens.
        # Bound follows the total initial token count and number of cells.
        limit=1+sum(map(len,cells.values()))*max(1,len(cells))*2
        for _ in range(limit):
            changed=False
            for cid in order:
                count=run(cid)
                if count>=rules.clear_size:
                    removed=count if rules.clear_mode=="whole_run" else rules.clear_size
                    del cells[cid][-removed:]; score+=removed; changed=True
            pair=None
            for a in order:
                if not cells[a]: continue
                for b in sorted(self.neighbors.get(a,())):
                    if a>=b or not cells[b] or cells[a][-1]!=cells[b][-1]: continue
                    if rules.flow=="toward_largest":
                        dest,src=sorted((a,b),key=lambda c:(-run(c),priority(c)))
                    else:
                        dest,src=sorted((a,b),key=priority)
                    pair=(src,dest); break
                if pair: break
            if pair:
                src,dest=pair; count=run(src)
                cells[dest].extend(cells[src][-count:]); del cells[src][-count:]
                changed=True
            if not changed: break
        else: raise RuntimeError("Cascade did not converge under selected rules")
        return HexaBoard({c:HexaStack(tuple(s)) if s else None for c,s in cells.items()},slots,self.neighbors,self.blocked,score)

    @classmethod
    def from_observation(cls,observation,neighbors):
        def stack(color,count):
            if count is None or not 1<=count<=99: raise ValueError("OCR count missing; exact top run unavailable")
            return HexaStack((color,)*count,unknown_below=True)
        blocked=frozenset(c for c,color in observation.board.items() if color in {"blocked","locked","unknown"})
        cells={c:None if color=="empty" or c in blocked else stack(color,observation.board_counts.get(c))
               for c,color in observation.board.items()}
        slots={s:stack(color,observation.slot_counts.get(s)) if color else None for s,color in observation.slots.items()}
        if len(cells)>1 and not any(neighbors.values()): raise ValueError("No calibrated neighbor graph")
        return cls(cells,slots,{c:tuple(neighbors.get(c,())) for c in cells},blocked)
