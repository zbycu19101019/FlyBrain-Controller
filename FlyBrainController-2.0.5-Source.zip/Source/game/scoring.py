from .rules import Rules, outcome
from .state import GameState

DEFAULT_WEIGHTS = dict(score=1., free=2., adjacent=1., runs=1., fragmentation=-1., dead_end=-100.)


def evaluate_state(state: GameState, weights: dict | None = None, rules: Rules = Rules()) -> float:
    w = DEFAULT_WEIGHTS | (weights or {})
    free = sum(c.stack is None and not c.blocked for c in state.board.values())
    runs = sum(sum(a == b for a,b in zip(c.stack.colors,c.stack.colors[1:]))
               for c in state.board.values() if c.stack)
    tops = {i:c.stack.colors[-1] for i,c in state.board.items() if c.stack}
    edges = sum(tops.get(i) == tops.get(j) for i in tops
                for j in state.neighbors.get(i,[]) if j in tops and j > i)
    # Connected components of equal top colors.
    remaining = set(tops)
    components = 0
    while remaining:
        root = remaining.pop()
        components += 1
        todo = [root]
        while todo:
            i = todo.pop()
            for j in state.neighbors.get(i, []):
                if j in remaining and tops[j] == tops[i]:
                    remaining.remove(j)
                    todo.append(j)
    return (w["score"]*state.score + w["free"]*free + w["runs"]*runs + w["adjacent"]*edges
            + w["fragmentation"]*components + w["dead_end"]*(outcome(state, rules) == "failure"))
