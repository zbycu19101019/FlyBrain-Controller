from copy import deepcopy
import random
from .state import GameState, Stack, BoardCell
from .moves import Move
from .rules import Rules, get_legal_moves, outcome


def apply_move(state: GameState, move: Move, rules: Rules = Rules()) -> GameState:
    """Pure transition; reject invalid IDs, negative IDs and illegal destinations."""
    if move not in get_legal_moves(state, rules):
        raise ValueError(f"Illegal move: {move}")
    result = deepcopy(state)
    source = result.slots[move.slot_id]
    target = result.board[move.target_cell_id]
    if target.stack is None: target.stack = Stack([])
    if rules.mode == "single_token_match":
        target.stack.colors.append(source.colors.pop())
    else:
        target.stack.colors.extend(source.colors)
        source.colors.clear()
    if not source.colors: result.slots[move.slot_id] = None
    if len(target.stack.colors) >= rules.clear_size and len(set(target.stack.colors)) == 1:
        result.score += len(target.stack.colors)
        target.stack = None
    return result


class GameSimulator:
    """Finite deterministic benchmark; no hidden or randomly replenished search nodes."""
    def __init__(self, rules: Rules = Rules(), reward_weights: dict | None = None,
                 board_size: int = 3, obstacle_count: int = 0):
        if board_size < 1 or not 0 <= obstacle_count < board_size:
            raise ValueError("Require board_size >= 1 and 0 <= obstacle_count < board_size")
        self.rules = rules
        self.weights = reward_weights or dict(valid_move=1, cleared=20, success=100, failure=-100)
        self.board_size,self.obstacle_count=board_size,obstacle_count
        self.state = None

    def reset(self, seed: int = 0, *, topology: str | None = None,
              board_size: int | None = None, obstacle_count: int | None = None,
              slot_count: int = 3, stack_depth: int = 4) -> GameState:
        rng = random.Random(seed)
        palette = ["red", "blue", "green", "yellow"]
        topology = topology or "path"
        board_size = self.board_size if board_size is None else board_size
        obstacle_count = self.obstacle_count if obstacle_count is None else obstacle_count
        if topology not in {"path", "ring", "branch", "hex"}:
            raise ValueError(f"Unknown topology: {topology}")
        if board_size < 1 or not 0 <= obstacle_count < board_size:
            raise ValueError("Require board_size >= 1 and 0 <= obstacle_count < board_size")
        if slot_count < 1 or stack_depth < 1:
            raise ValueError("slot_count and stack_depth must be positive")
        blocked=set(rng.sample(range(board_size),obstacle_count))
        neighbors={i:set() for i in range(board_size)}
        if topology in {"path", "ring"}:
            for i in range(board_size - 1):
                neighbors[i].add(i+1); neighbors[i+1].add(i)
            if topology == "ring" and board_size > 2:
                neighbors[0].add(board_size-1); neighbors[board_size-1].add(0)
        elif topology == "branch":
            for i in range(1, board_size):
                parent=(i-1)//2
                neighbors[i].add(parent); neighbors[parent].add(i)
        else:
            coords=[]
            radius=0
            while len(coords) < board_size:
                radius += 1
                coords=[(q,r) for q in range(-radius,radius+1)
                        for r in range(-radius,radius+1)
                        if max(abs(q),abs(r),abs(q+r)) <= radius]
            coords=coords[:board_size]
            lookup={coord:i for i,coord in enumerate(coords)}
            for i,(q,r) in enumerate(coords):
                for delta in ((1,0),(-1,0),(0,1),(0,-1),(1,-1),(-1,1)):
                    j=lookup.get((q+delta[0],r+delta[1]))
                    if j is not None: neighbors[i].add(j)
        self.state = GameState({i: BoardCell(i,blocked=i in blocked) for i in range(board_size)},
            {i: Stack([rng.choice(palette) for _ in range(stack_depth)]) for i in range(slot_count)},
            neighbors={i:sorted(adjacent) for i,adjacent in neighbors.items()})
        return deepcopy(self.state)

    def step(self, move: Move) -> tuple[GameState, float, bool]:
        old = self.state
        self.state = apply_move(old, move, self.rules)
        result = outcome(self.state, self.rules)
        reward = self.weights["valid_move"] + self.weights["cleared"] * (self.state.score-old.score)
        if result: reward += self.weights[result]
        return deepcopy(self.state), float(reward), result is not None
