from dataclasses import dataclass


@dataclass(frozen=True, order=True)
class Move:
    slot_id: int
    target_cell_id: int
