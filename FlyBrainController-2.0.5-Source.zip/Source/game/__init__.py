"""Image-independent state and explicitly simplified puzzle rules."""
