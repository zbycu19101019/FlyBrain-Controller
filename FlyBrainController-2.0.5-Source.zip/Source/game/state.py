from dataclasses import dataclass, field, asdict
import json


@dataclass
class Stack:
    """Colors ordered bottom to top; empty stacks normalize to None."""
    colors: list[str]


@dataclass
class BoardCell:
    id: int
    stack: Stack | None = None
    blocked: bool = False

    def __post_init__(self):
        if self.blocked and self.stack is not None:
            raise ValueError("Blocked cells cannot contain a stack")


@dataclass
class GameState:
    board: dict[int, BoardCell]
    slots: dict[int, Stack | None]
    score: int = 0
    confident: bool = True
    confidence: float = 1.0
    neighbors: dict[int, list[int]] = field(default_factory=dict)

    def __post_init__(self):
        if any(i != cell.id for i, cell in self.board.items()):
            raise ValueError("Board keys must match cell IDs")
        for cell in self.board.values():
            if cell.stack is not None and not cell.stack.colors: cell.stack = None
        for i, stack in self.slots.items():
            if stack is not None and not stack.colors: self.slots[i] = None
        for i, adjacent in self.neighbors.items():
            if i not in self.board or len(set(adjacent)) != len(adjacent):
                raise ValueError("Invalid adjacency")
            for j in adjacent:
                if j == i or j not in self.board or i not in self.neighbors.get(j, []):
                    raise ValueError("Adjacency must be symmetric and refer to board IDs")

    def to_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict) -> "GameState":
        def stack(value): return Stack(list(value["colors"])) if value else None
        return cls({int(i): BoardCell(int(i), stack(c["stack"]), bool(c.get("blocked", False))) for i,c in data["board"].items()},
                   {int(i): stack(s) for i,s in data["slots"].items()},
                   data.get("score", 0), data.get("confident", True), data.get("confidence", 1.),
                   {int(i): list(n) for i,n in data.get("neighbors", {}).items()})

    def canonical(self) -> str:
        return json.dumps(self.to_dict(), sort_keys=True, separators=(",", ":"), allow_nan=False)
