from dataclasses import dataclass
from .state import GameState
from .moves import Move


@dataclass(frozen=True)
class Rules:
    """Toy adapters, NOT a reverse-engineered Hexa Sort rule set."""
    mode: str = "single_token_match"
    capacity: int = 4
    clear_size: int = 4

    def __post_init__(self):
        if self.mode not in {"single_token_match", "whole_stack_empty"}:
            raise ValueError("Unknown rule mode")
        if not 1 <= self.clear_size <= self.capacity:
            raise ValueError("Require 1 <= clear_size <= capacity")


def get_legal_moves(state: GameState, rules: Rules = Rules()) -> list[Move]:
    moves = []
    for sid, source in sorted(state.slots.items()):
        if source is None: continue
        for cid, cell in sorted(state.board.items()):
            if cell.blocked: continue
            target = cell.stack
            if rules.mode == "whole_stack_empty":
                legal = target is None and len(source.colors) <= rules.capacity
            else:
                legal = target is None or (len(target.colors) < rules.capacity and target.colors[-1] == source.colors[-1])
            if legal: moves.append(Move(sid, cid))
    return moves


def outcome(state: GameState, rules: Rules = Rules()) -> str | None:
    # Offline objective is explicitly to consume the finite tray supply.
    if all(s is None for s in state.slots.values()): return "success"
    if not get_legal_moves(state, rules): return "failure"
    return None
