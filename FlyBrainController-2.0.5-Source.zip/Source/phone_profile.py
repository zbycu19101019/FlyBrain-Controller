"""Export the supported calibration workflow to the desktop phone profile."""
import json
from pathlib import Path
from settings import load_config


def export_profile(config: Path) -> bool:
    cfg=load_config(config)
    target=Path(config).parent/"phone_profile.json"
    palette=cfg.get("color_prototypes",[])
    names={item["name"] for item in palette}
    ready=bool(cfg.get("screen_size") and cfg.get("board_cells") and cfg.get("slots")
               and cfg.get("screen_guards") and "empty" in names
               and names-{"empty","obstacle","unknown"})
    if not ready:
        target.unlink(missing_ok=True)
        return False
    profile=dict(screen_size=cfg["screen_size"],cells=cfg["board_cells"],slots=cfg["slots"],
                 neighbors=cfg["neighbors"],palette=palette,guards=cfg["screen_guards"],
                 blocked_cells=cfg.get("blocked_cells",[]),
                 sample_offset=cfg.get("sample_offsets",[[0,0]])[-1])
    for key in ("ocr_board_roi","ocr_slot_roi"):
        if key in cfg: profile[key]=cfg[key]
    temporary=target.with_suffix(".tmp")
    temporary.write_text(json.dumps(profile,ensure_ascii=False,indent=2),encoding="utf-8")
    temporary.replace(target)
    return True
