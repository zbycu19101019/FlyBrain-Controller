import json
from pathlib import Path
import numpy as np


def load_features(path: Path,fingerprint: str):
    """Read persisted features without rerunning the reservoir."""
    x,y,episodes=[],[],[]
    with Path(path).open(encoding="utf-8") as stream:
        for line in stream:
            row=json.loads(line)
            if row["feature_fingerprint"] != fingerprint: raise ValueError("Dataset fingerprint mismatch")
            x.append(row["neural_features"]); y.append(row["target"]); episodes.append(row["episode_seed"])
    if not x: raise ValueError("Dataset is empty")
    return np.asarray(x),np.asarray(y),np.asarray(episodes)
