"""Compare all four agents on identical, held-out finite toy puzzles."""
import argparse
import json
from pathlib import Path
import statistics
import time
from factory import make_agent
from flybrain.readout import LinearReadout
from game.simulator import GameSimulator
from game.rules import Rules, get_legal_moves, outcome
from settings import ROOT, load_config, resolve


def evaluate(cfg,games=100,seed=10000):
    if games < 1: raise ValueError("games must be positive")
    _,metadata=LinearReadout.load(resolve(cfg,cfg["readout_model"]))
    if set(range(seed,seed+games)) & set(metadata["episode_seeds"]):
        raise ValueError("Evaluation seeds overlap training/validation data")
    rules=Rules(**cfg["rules"])
    report=dict(environment="finite_supply_toy_v1; success = consume tray supply",games=games,
                first_seed=seed,rules=cfg["rules"],brain=cfg["brain_backend"],agents={})
    rows=[]
    for name in ("random","greedy","search","flybrain"):
        agent=make_agent(name,cfg,seed)
        scores,steps,times,successes=[],[],[],0
        features=getattr(agent,"features",None)
        for episode in range(games):
            sim=GameSimulator(rules,cfg["reward_weights"])
            state=sim.reset(seed+episode)
            count=0
            while moves:=get_legal_moves(state,rules):
                start=time.perf_counter()
                move=agent.select_move(state,moves)
                times.append(time.perf_counter()-start)
                state,_,done=sim.step(move)
                count+=1
                if done: break
            result=outcome(state,rules)
            scores.append(state.score); steps.append(count); successes+=result == "success"
            rows.append(dict(agent=name,seed=seed+episode,score=state.score,moves=count,outcome=result))
        report["agents"][name]=dict(mean_score=statistics.mean(scores),median_score=statistics.median(scores),
            mean_moves=statistics.mean(steps),success_percent=100*successes/games,
            mean_decision_ms=1000*statistics.mean(times),neural_simulation_seconds=features.simulation_seconds if features else 0.,
            cache_hits=features.cache_hits if features else 0)
        print(name,json.dumps(report["agents"][name]),flush=True)
    folder=resolve(cfg,"data/benchmark"); folder.mkdir(parents=True,exist_ok=True)
    (folder/"report.json").write_text(json.dumps(report,indent=2),encoding="utf-8")
    (folder/"episodes.jsonl").write_text("".join(json.dumps(row)+"\n" for row in rows),encoding="utf-8")
    return report


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config",type=Path,default=ROOT/"config.yaml")
    parser.add_argument("--games",type=int,default=100)
    parser.add_argument("--seed",type=int,default=10000)
    args=parser.parse_args()
    evaluate(load_config(args.config),args.games,args.seed)


if __name__ == "__main__": main()
