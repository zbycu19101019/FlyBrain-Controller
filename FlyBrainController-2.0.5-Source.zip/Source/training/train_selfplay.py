"""Learn an obstacle-aware readout by repeated play in the offline toy simulator."""
import argparse
import json
from pathlib import Path
import time
import numpy as np
from factory import make_features
from flybrain.readout import LinearReadout
from game.rules import Rules, get_legal_moves, outcome
from game.simulator import GameSimulator
from settings import ROOT, load_config, resolve


def train(cfg, episodes=None, seed=20000, gamma=.96):
    episodes=int(episodes or cfg.get("self_play_episodes",120))
    if episodes < 10: raise ValueError("Use at least 10 self-play episodes")
    features=make_features(cfg); rules=Rules(**cfg["rules"])
    sim=GameSimulator(rules,cfg["reward_weights"],board_size=7,obstacle_count=1)
    rng=np.random.default_rng(seed); readout=None; all_x=[]; all_y=[]; scores=[]; outcomes=[]
    model_path=resolve(cfg,cfg.get("self_play_model","data/models/self_play.npz"))
    replay_path=model_path.with_name("self_play_replay.npz")
    replay_context=dict(feature_fingerprint=features.fingerprint,rules=cfg["rules"],
                        reward_weights=cfg["reward_weights"],gamma=gamma,environment="selfplay_varied_v1")
    if replay_path.exists():
        with np.load(replay_path,allow_pickle=False) as replay:
            if "context" in replay and json.loads(str(replay["context"])) == replay_context:
                all_x.extend(replay["x"])
                all_y.extend(replay["y"])
    if model_path.exists():
        try:
            readout,metadata=LinearReadout.load(model_path,features.fingerprint)
            if metadata.get("replay_context") != replay_context: readout=None
        except (ValueError,KeyError): readout=None

    topology_names=("path", "ring", "branch", "hex")
    scenario_counts={"topologies":{},"board_sizes":{},"obstacle_counts":{},"slot_counts":{},"stack_depths":{}}
    for episode in range(episodes):
        topology=topology_names[episode % len(topology_names)]
        board_size=(7, 9, 13, 19)[(episode // len(topology_names)) % 4]
        obstacle_count=int(rng.integers(0,max(1,min(board_size//3,5))+1))
        slot_count=int(rng.integers(2,5)); stack_depth=int(rng.integers(1,rules.capacity+1))
        scenario_counts["topologies"][topology]=scenario_counts["topologies"].get(topology,0)+1
        for key,value in (("board_sizes",board_size),("obstacle_counts",obstacle_count),
                          ("slot_counts",slot_count),("stack_depths",stack_depth)):
            scenario_counts[key][str(value)]=scenario_counts[key].get(str(value),0)+1
        state=sim.reset(seed+episode,topology=topology,board_size=board_size,
                        obstacle_count=obstacle_count,slot_count=slot_count,stack_depth=stack_depth)
        trajectory=[]; steps=0
        while moves:=get_legal_moves(state,rules):
            candidates=np.asarray([features.features(state,move) for move in moves])
            epsilon=max(.05,.35*(1-episode/max(1,episodes)))
            if readout is None or rng.random() < epsilon:
                index=int(rng.integers(len(moves)))
            else:
                values=readout.predict(candidates)
                index=int(np.argmax(values))
            move=moves[index]; chosen=candidates[index].copy()
            state,reward,done=sim.step(move); trajectory.append((chosen,reward)); steps+=1
            if done or steps>=60: break
        result=outcome(state,rules) or "cutoff"
        returns=[]; value=0.
        for _,reward in reversed(trajectory):
            value=float(reward)+gamma*value; returns.append(value)
        all_x.extend(x for x,_ in trajectory); all_y.extend(reversed(returns))
        scores.append(state.score); outcomes.append(result)
        if len(all_x)>=20 and (episode+1)%5==0:
            readout=LinearReadout().fit(np.asarray(all_x),np.asarray(all_y),alpha=1.)
        if (episode+1)%5==0:
            print(f"Self-play: {episode+1}/{episodes} episodes; epsilon={epsilon:.3f}; mean score={np.mean(scores):.2f}; map={topology}/{board_size}; obstacles={obstacle_count}; tray={slot_count}x{stack_depth}",flush=True)

    if len(all_x)<20: raise RuntimeError("Self-play did not generate enough state-action samples")
    readout=LinearReadout().fit(np.asarray(all_x),np.asarray(all_y),alpha=1.)
    replay_path.parent.mkdir(parents=True,exist_ok=True)
    np.savez_compressed(replay_path,x=np.asarray(all_x),y=np.asarray(all_y),
                        feature_fingerprint=np.asarray(features.fingerprint),context=json.dumps(replay_context))
    previous_episodes=0
    report_path=resolve(cfg,"data/models/self_play_report.json")
    try:
        previous_report=json.loads(report_path.read_text(encoding="utf-8"))
        if previous_report.get("replay_context")==replay_context:
            previous_episodes=int(previous_report.get("total_episodes",0))
    except (OSError,ValueError,TypeError): pass
    metadata=dict(replay_context=replay_context,feature_fingerprint=features.fingerprint,rules=cfg["rules"],
        heuristic_weights=cfg["heuristic_weights"],training="epsilon-greedy Monte Carlo self-play; offline toy simulator only",
        episodes=episodes,total_episodes=previous_episodes+episodes,scenario_counts=scenario_counts,
        curriculum="path, ring, branching and hex-like graphs; varied cells, obstacles, tray slots and stack depths",
        first_seed=seed,obstacles_per_map=max(map(int,scenario_counts["obstacle_counts"])),
        board_cells=max(map(int,scenario_counts["board_sizes"])),board_cell_range=[7,19],
        gamma=gamma,samples=len(all_x),mean_score=float(np.mean(scores)),
        success_percent=100.*sum(x=="success" for x in outcomes)/episodes,
        feature_manifest=features.manifest,created_at=time.strftime("%Y-%m-%dT%H:%M:%SZ",time.gmtime()))
    readout.save(model_path,metadata)
    report=resolve(cfg,"data/models/self_play_report.json"); report.parent.mkdir(parents=True,exist_ok=True)
    report.write_text(json.dumps(metadata,indent=2),encoding="utf-8")
    print(json.dumps({k:v for k,v in metadata.items() if k!="feature_manifest"},indent=2),flush=True)
    return metadata


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config",type=Path,default=ROOT/"config.yaml")
    parser.add_argument("--episodes",type=int)
    parser.add_argument("--seed",type=int,default=20000)
    args=parser.parse_args(); train(load_config(args.config),args.episodes,args.seed)


if __name__=="__main__": main()
