"""Offline teacher imitation and reproducible held-out evaluation."""
