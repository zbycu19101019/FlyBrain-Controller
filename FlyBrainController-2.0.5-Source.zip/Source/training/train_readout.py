"""Imitate a one-step heuristic teacher; this is supervised learning, not online RL."""
import argparse
from dataclasses import asdict
import json
from pathlib import Path
import time
import numpy as np
from agents import RandomAgent, GreedyAgent
from factory import make_features
from flybrain.readout import LinearReadout
from game.rules import Rules, get_legal_moves, outcome
from game.simulator import GameSimulator, apply_move
from game.scoring import evaluate_state
from settings import ROOT, load_config, resolve
from .replay_buffer import ReplayBuffer
from .dataset import load_features


def train(cfg,episodes=80,seed=0,dataset=None):
    if episodes < 5: raise ValueError("Use at least 5 episodes for an episode-level validation split")
    features=make_features(cfg)
    rules=Rules(**cfg["rules"])
    dataset=Path(dataset) if dataset else resolve(cfg,f"data/recordings/train_{time.time_ns()}.jsonl")
    context=dict(rules=cfg["rules"],heuristic_weights=cfg["heuristic_weights"],reward_weights=cfg["reward_weights"],
                 feature_fingerprint=features.fingerprint,environment="finite_supply_toy_v1")
    sidecar=dataset.with_suffix(".metadata.json")
    if dataset.exists():
        if not sidecar.exists() or json.loads(sidecar.read_text(encoding="utf-8")) != context:
            raise ValueError("Dataset teacher/rules/reward metadata differs or is missing; collect a new dataset")
    if not dataset.exists():
        dataset.parent.mkdir(parents=True,exist_ok=True)
        sidecar.write_text(json.dumps(context,indent=2),encoding="utf-8")
        replay=ReplayBuffer(dataset)
        teacher=GreedyAgent(rules,cfg["heuristic_weights"])
        explorer=RandomAgent(seed)
        sim=GameSimulator(rules,cfg["reward_weights"])
        for episode in range(episodes):
            state=sim.reset(seed+episode)
            while moves:=get_legal_moves(state,rules):
                for move in moves:
                    following=apply_move(state,move,rules)
                    result=outcome(following,rules)
                    weights=cfg["reward_weights"]
                    reward=weights["valid_move"]+weights["cleared"]*(following.score-state.score)+(weights[result] if result else 0)
                    replay.add(dict(state=state.to_dict(),move=asdict(move),reward=reward,next_state=following.to_dict(),
                        done=result is not None,neural_features=features.features(state,move),
                        target=evaluate_state(following,cfg["heuristic_weights"],rules),
                        feature_fingerprint=features.fingerprint,episode_seed=seed+episode))
                move=(explorer if episode%3 == 0 else teacher).select_move(state,moves)
                state,_,done=sim.step(move)
                if done: break
            if (episode+1)%10 == 0: print(f"Training data: {episode+1}/{episodes} episodes",flush=True)
    x,y,episode_ids=load_features(dataset,features.fingerprint)
    validation=episode_ids%5 == 0
    if not validation.any() or validation.all(): raise ValueError("Dataset needs both train and held-out episodes")
    candidates=[]
    for alpha in (.1,1.,10.,100.):
        readout=LinearReadout().fit(x[~validation],y[~validation],alpha)
        mse=float(np.mean((readout.predict(x[validation])-y[validation])**2))
        candidates.append((mse,alpha,readout))
    mse,alpha,readout=min(candidates,key=lambda item:item[0])
    seeds=sorted(set(int(i) for i in episode_ids))
    metadata=dict(feature_fingerprint=features.fingerprint,rules=cfg["rules"],heuristic_weights=cfg["heuristic_weights"],
        training="supervised one-step heuristic imitation; NOT reinforcement learning",
        dataset=str(dataset.name),episode_seeds=seeds,validation_mse=mse,ridge_alpha=alpha,
        samples=len(x),training_samples=int((~validation).sum()),validation_samples=int(validation.sum()),
        simulation_seconds=features.simulation_seconds,feature_manifest=features.manifest)
    readout.save(resolve(cfg,cfg["readout_model"]),metadata)
    report=resolve(cfg,"data/models/training_report.json")
    report.write_text(json.dumps(metadata,indent=2),encoding="utf-8")
    print(json.dumps({k:v for k,v in metadata.items() if k not in {"feature_manifest","episode_seeds"}},indent=2))
    return metadata


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config",type=Path,default=ROOT/"config.yaml")
    parser.add_argument("--episodes",type=int,default=80)
    parser.add_argument("--seed",type=int,default=0)
    parser.add_argument("--dataset",type=Path,help="Reuse a saved dataset without neural simulation")
    args=parser.parse_args()
    train(load_config(args.config),args.episodes,args.seed,args.dataset)


if __name__ == "__main__": main()
