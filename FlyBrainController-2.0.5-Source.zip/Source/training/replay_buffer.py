from collections import deque
from pathlib import Path
import json
import numpy as np
from runtime import append_jsonl


class ReplayBuffer:
    """Bounded RAM view with append-only JSONL persistence including neural features."""
    def __init__(self,path: Path,capacity: int = 100000):
        if capacity < 1: raise ValueError("capacity must be positive")
        self.path=Path(path)
        self.items=deque(maxlen=capacity)
        if self.path.exists():
            with self.path.open(encoding="utf-8") as stream:
                for line in stream: self.items.append(json.loads(line))

    def add(self,experience: dict) -> None:
        item=dict(experience)
        if isinstance(item["neural_features"],np.ndarray): item["neural_features"]=item["neural_features"].tolist()
        append_jsonl(self.path,item)
        self.items.append(item)

    def sample(self,count: int,seed: int = 0) -> list[dict]:
        indices=np.random.default_rng(seed).choice(len(self.items),min(count,len(self.items)),replace=False)
        return [self.items[int(i)] for i in indices]
